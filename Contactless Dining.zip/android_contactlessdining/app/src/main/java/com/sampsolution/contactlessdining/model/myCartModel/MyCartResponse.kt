package com.sampsolution.contactlessdining.model.myCartModel

import com.google.gson.annotations.SerializedName

data class MyCartResponse (
    @SerializedName("success"        ) var success       : Boolean?        = null,
    @SerializedName("message"        ) var message       : String?         = null,
    @SerializedName("data"           ) var data          : ArrayList<MyCartData> = arrayListOf(),
    @SerializedName("item_total"     ) var itemTotal     : String?         = null,
    @SerializedName("variations"     ) var variations    : String?         = null,
    @SerializedName("total_discount" ) var totalDiscount : String?         = null,
    @SerializedName("sub_total"      ) var subTotal      : String?         = null,
    @SerializedName("taxes"          ) var taxes         : String?         = null,
    @SerializedName("total_amount"   ) var totalAmount   : String?         = null
)