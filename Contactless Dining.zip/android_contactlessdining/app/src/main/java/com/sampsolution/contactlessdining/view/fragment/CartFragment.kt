package com.sampsolution.contactlessdining.view.fragment

import android.annotation.SuppressLint
import android.app.ProgressDialog
import android.content.Intent
import android.os.Bundle
import android.text.InputType
import android.util.ArrayMap
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.view.inputmethod.EditorInfo
import android.widget.TextView.OnEditorActionListener
import androidx.appcompat.app.AppCompatActivity
import androidx.appcompat.widget.AppCompatEditText
import com.sampsolution.contactlessdining.R
import com.sampsolution.contactlessdining.databinding.FragmentCartBinding
import com.sampsolution.contactlessdining.model.HomeInterFace
import com.sampsolution.contactlessdining.model.myCartModel.MyCartData
import com.sampsolution.contactlessdining.utils.Constant
import com.sampsolution.contactlessdining.view.activity.DigitalPaymentActivity
import com.sampsolution.contactlessdining.view.adapter.MyCartAdapter
import com.sampsolution.contactlessdining.view.dialog.FailedCheckOutDialog
import com.sampsolution.contactlessdining.view.dialog.SuccessCheckOutDialog

open class CartFragment : BaseFragment,
    MyCartAdapter.OnClick {

    private var binding: FragmentCartBinding? = null
    var list: ArrayList<MyCartData> = arrayListOf()
    var isSelected = true
    private var isSelected1 = true
    private var key = "cash"
    private var payKey: String? = null
    private var total: String? = null
    var listener: HomeInterFace? = null

    constructor() : super()

    constructor(listener: HomeInterFace, payKey: String?) {
        this.listener = listener
        this.payKey = payKey
    }

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        binding = FragmentCartBinding.inflate(inflater, container, false)

        key = payKey.toString()

        if (key == "digital") {
            binding!!.ivDigital.visibility = View.VISIBLE
            binding!!.ivOpenNow.visibility = View.GONE
        } else {
            binding!!.ivOpenNow.visibility = View.VISIBLE
            binding!!.ivDigital.visibility = View.GONE
        }

        binding!!.btnProceed.setOnClickListener {
            if (key == "digital") {
                val intent = Intent(requireActivity(), DigitalPaymentActivity::class.java)
                intent.putExtra("Instruction", binding!!.tvInsrtuction.text.toString())
                intent.putExtra("ListSize", list.size)
                intent.putExtra("totalAmount", binding!!.txtRs.text.toString())
                intent.putExtra("totalAmount1", total)
                startActivity(intent)
            } else {
                conformation(binding!!.tvInsrtuction.text.toString())
            }
        }

        binding!!.tvInsrtuction.setMultiLineCapSentencesAndDoneAction()

        binding!!.tvInsrtuction.onFocusChangeListener = View.OnFocusChangeListener { v, hasFocus ->
            if (hasFocus) {
                binding!!.tvInsrtuction.hint = "\n"
                binding!!.tvInsrtuction.isCursorVisible = true
            }
        }

        binding!!.tvInsrtuction.setOnClickListener {
            binding!!.tvInsrtuction.hint = "\n"
            binding!!.tvInsrtuction.isCursorVisible = true
        }

        binding!!.tvInsrtuction.setOnEditorActionListener(OnEditorActionListener { v, actionId, event ->
            if (actionId == EditorInfo.IME_ACTION_DONE) {
                binding!!.tvInsrtuction.hint =
                    getString(
                        R.string.speacial_insrtuction_i_e_extra_slice_of_shaken_not_stirred
                    )
                binding!!.tvInsrtuction.isCursorVisible = false
                // do something, e.g. set your TextView here via .setText()
//                val imm =
//                    v.context.getSystemService<Any>(Context.INPUT_METHOD_SERVICE) as InputMethodManager
//                imm.hideSoftInputFromWindow(v.windowToken, 0)
            }
            return@OnEditorActionListener false

        })

        binding!!.relCashPayment.setOnClickListener {
            if (isSelected) {
                binding!!.ivOpenNow.visibility = View.VISIBLE
                binding!!.ivDigital.visibility = View.GONE
                key = "cash"
                isSelected = true
            } else {
                binding!!.ivOpenNow.visibility = View.GONE
                binding!!.ivDigital.visibility = View.VISIBLE
                key = "digital"
                isSelected = false
            }
        }

        binding!!.relDigitalPayment.setOnClickListener {
            if (isSelected1) {
                binding!!.ivDigital.visibility = View.VISIBLE
                binding!!.ivOpenNow.visibility = View.GONE
                key = "digital"
                isSelected1 = true
            } else {
                binding!!.ivDigital.visibility = View.GONE
                binding!!.ivOpenNow.visibility = View.VISIBLE
                key = "cash"
                isSelected1 = false
            }
        }


        return binding?.root
    }


    private fun AppCompatEditText.setMultiLineCapSentencesAndDoneAction() {
        imeOptions = EditorInfo.IME_ACTION_DONE
        setRawInputType(InputType.TYPE_TEXT_FLAG_CAP_SENTENCES or InputType.TYPE_TEXT_FLAG_MULTI_LINE)
    }

    @SuppressLint("SetTextI18n")
    private fun apiData() {
//        val dialog = ProgressDialog(requireActivity())
//        dialog.show()

        list.clear()
        context?.let {
            Constant.getData(it, Constant.USERID)?.let {
                contactlessService?.myCartApi(it)?.observeForever {
                    it?.let { it1 ->
                        //                    dialog.dismiss()
                        if (it1.data.size != 0) {
                            list.addAll(it1.data)
                            context?.let { it2 ->
                                Constant.intSaveData(
                                    it2,
                                    Constant.ADDCARTCOUNt, list.size
                                )
                            }

                            //count update
                            if (context?.let { it2 ->
                                    Constant.intGetData(
                                        it2,
                                        Constant.ADDCARTCOUNt
                                    )
                                } == 0
                            ) {
                                //                            (activity as HomeActivity)?.let {
                                //                                it.goneTextCount()
                                //                            }
                                listener?.goneTextCount()
                            } else {
                                //                            (activity as HomeActivity)?.let {
                                //                                it.visibleTextCount()
                                //                            }
                                listener?.visibleTextCount()
                            }

                            binding?.scroll?.visibility = View.VISIBLE
                            binding?.relNoData?.visibility = View.GONE

                            if (it1.subTotal != null) {
                                binding!!.tvItemTotal.text = "$${it1.itemTotal}"
                            } else {
                                binding!!.tvItemTotal.text = "$0.0"
                            }

                            if (it1.totalDiscount != null) {
                                binding!!.tvDiscount.text = "$${it1.totalDiscount}"
                            } else {
                                binding!!.tvDiscount.text = "$0.0"
                            }

                            if (it1.taxes != null) {
                                binding!!.tvTaxes.text = "$${it1.taxes}"
                            } else {
                                binding!!.tvTaxes.text = "$0.0"
                            }

                            if (it1.subTotal != null) {
                                binding!!.tvSubTotal.text = "$${it1.subTotal}"
                            } else {
                                binding!!.tvSubTotal.text = "$0.0"
                            }

                            if (it1.totalAmount != null) {
                                binding!!.tvTaxesCharges.text = "$${it1.totalAmount}"
                                binding!!.txtRs.text = "$${it1.totalAmount}"
                            } else {
                                binding!!.tvTaxesCharges.text = "$0.0"
                                binding!!.txtRs.text = "$0.0"
                            }

                            if (it1.variations != null) {
                                binding!!.tvVariationTotal.text = "$${it1.variations}"
                            } else {
                                binding!!.tvVariationTotal.text = "$0.0"
                            }

                            total = it1.totalAmount

                            binding!!.rvListBar.adapter =
                                MyCartAdapter(requireContext(), it1.data, this)
                            binding!!.rvListBar.isNestedScrollingEnabled = false

                        } else {
                            binding?.scroll?.visibility = View.GONE
                            binding?.relNoData?.visibility = View.VISIBLE
                            context?.let { it2 ->
                                Constant.intSaveData(
                                    it2,
                                    Constant.ADDCARTCOUNt, 0
                                )
                            }

                            //count update
                            if (context?.let { it2 ->
                                    Constant.intGetData(
                                        it2,
                                        Constant.ADDCARTCOUNt
                                    )
                                } == 0
                            ) {
                                //                            (activity as HomeActivity)?.let {
                                //                                it.goneTextCount()
                                //                            }
                                listener?.goneTextCount()
                            } else {
                                //                            (activity as HomeActivity)?.let {
                                //                                it.visibleTextCount()
                                //                            }
                                listener?.visibleTextCount()
                            }
                        }
                    }
                }
            }
        }
    }

    override fun onResume() {
        super.onResume()
        apiData()
    }

    override fun onClick(itemId: Int?, count: Int) {
        val map: ArrayMap<String?, Any?> = ArrayMap<String?, Any?>()
        map["user_id"] = context?.let { Constant.getData(it, Constant.USERID) }
        map["item_id"] = itemId
        map["item_qty"] = count

        context?.let {
            contactlessService?.updateCartApi(it, map)?.observeForever {
                it?.let { it1 ->
                    apiData()
                }
            }
        }
    }


    private fun conformation(instructions: String) {

        val dialog = ProgressDialog(requireActivity())
        dialog.show()
        val map: ArrayMap<String?, Any?> = ArrayMap<String?, Any?>()
        map["user_id"] = context?.let { Constant.getData(it, Constant.USERID) }
        map["order_instructions"] = instructions
        map["gateway_name"] = "COD"

        contactlessService?.checkOutApi(map)?.observeForever {
            dialog.dismiss()
            it?.let { it1 ->
                if (it1.success == true) {
                    if (list.size != 0) {
                        if (context?.let { it2 ->
                                Constant.intGetData(
                                    it2,
                                    Constant.ADDCARTCOUNt
                                )
                            } != 0) {
                            context?.let { it2 ->
                                Constant.intSaveData(
                                    it2,
                                    Constant.ADDCARTCOUNt,
                                    (Constant.intGetData(
                                        requireActivity(),
                                        Constant.ADDCARTCOUNt
                                    ) - list.size)
                                )
                            }
                        }

                    }
//                    context?.let { it2 -> Constant.saveData(it2, Constant.QRCODE, null) }
//                    val intent = Intent(requireActivity(), OrderDetailsActivity::class.java)
//                    intent.putExtra("Order id", it1.orderNumber)
//                    startActivity(intent)
                    SuccessCheckOutDialog(context as AppCompatActivity, it1.orderNumber).show()
                } else {
                    FailedCheckOutDialog(context as AppCompatActivity, "", "").show()
                }
            }
        }

    }


}

