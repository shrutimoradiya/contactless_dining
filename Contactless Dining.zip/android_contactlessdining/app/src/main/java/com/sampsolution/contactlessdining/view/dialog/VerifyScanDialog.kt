package com.sampsolution.contactlessdining.view.dialog

import android.app.Dialog
import android.graphics.Color
import android.graphics.drawable.ColorDrawable
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.WindowManager
import androidx.appcompat.app.AppCompatActivity
import androidx.appcompat.widget.AppCompatEditText
import com.google.android.material.bottomsheet.BottomSheetDialog
import com.sampsolution.contactlessdining.R
import com.sampsolution.contactlessdining.databinding.DialogVerifyScanBinding

data class VerifyScanDialog(
    val context: AppCompatActivity,
    val listener: OnOptionSelected
) : Dialog(context) {
    private var dialogbinding: DialogVerifyScanBinding? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        dialogbinding = DialogVerifyScanBinding.inflate(LayoutInflater.from(context))

        dialogbinding?.let { binding ->
            setContentView(binding.root)

            dialogbinding!!.btnSubmit.setOnClickListener {
                listener.onItemClick(binding.edtNo)
            }

            binding.btnClose.setOnClickListener { dismiss() }


        }

        setCanceledOnTouchOutside(true)
        val layoutParams = WindowManager.LayoutParams()
        layoutParams.copyFrom(window?.attributes)
        layoutParams.width = WindowManager.LayoutParams.MATCH_PARENT
        layoutParams.height = WindowManager.LayoutParams.MATCH_PARENT
        window?.attributes = layoutParams
        window?.setBackgroundDrawable(context.getDrawable(R.drawable.img_background))
        (dialogbinding!!.root.parent as View).setBackgroundColor(
            context.resources.getColor(android.R.color.transparent)
        )
    }

    interface OnOptionSelected {
        fun onItemClick(edtNo: AppCompatEditText)
    }

}

