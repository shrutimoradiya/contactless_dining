package com.sampsolution.contactlessdining.model.razorpayErrorModel

import com.google.gson.annotations.SerializedName


data class RazorpayErrorResponse (

  @SerializedName("error" ) var error : Error? = Error()

)