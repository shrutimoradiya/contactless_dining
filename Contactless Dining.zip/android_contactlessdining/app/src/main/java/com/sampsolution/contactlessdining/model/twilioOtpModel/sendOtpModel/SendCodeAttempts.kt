package com.sampsolution.contactlessdining.model.twilioOtpModel.sendOtpModel

import com.google.gson.annotations.SerializedName


data class SendCodeAttempts (

  @SerializedName("attempt_sid" ) var attemptSid : String? = null,
  @SerializedName("channel"     ) var channel    : String? = null,
  @SerializedName("time"        ) var time       : String? = null

)