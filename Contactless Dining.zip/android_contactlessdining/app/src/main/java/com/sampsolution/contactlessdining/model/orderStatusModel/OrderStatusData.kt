package com.sampsolution.contactlessdining.model.orderStatusModel

import com.google.gson.annotations.SerializedName

data class OrderStatusData(
    @SerializedName("order_number"     ) var orderNumber     : String? = null,
    @SerializedName("item_name"        ) var itemName        : String? = null,
    @SerializedName("item_description" ) var itemDescription : String? = null,
    @SerializedName("item_image"       ) var itemImage       : String? = null,
    @SerializedName("time"             ) var time            : String? = null,
    @SerializedName("order_status"     ) var orderStatus     : String? = null
)
