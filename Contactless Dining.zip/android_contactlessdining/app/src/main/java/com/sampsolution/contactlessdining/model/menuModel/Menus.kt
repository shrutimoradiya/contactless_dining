package com.sampsolution.contactlessdining.model.menuModel

import com.google.gson.annotations.SerializedName

data class Menus(
    @SerializedName("item_id"          ) var itemId          : Int?                  = null,
    @SerializedName("item_name"        ) var itemName        : String?               = null,
    @SerializedName("item_description" ) var itemDescription : String?               = null,
    @SerializedName("item_price"       ) var itemPrice       : String?               = null,
    @SerializedName("item_type"        ) var itemType        : String?               = null,
    @SerializedName("item_image"       ) var itemImage       : String?               = null,
    @SerializedName("variations"       ) var variations      : ArrayList<Variations> = arrayListOf()
)
