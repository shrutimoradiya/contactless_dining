package com.sampsolution.contactlessdining.service.teleSignService

import android.util.ArrayMap
import android.widget.Toast
import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import com.google.gson.GsonBuilder
import com.sampsolution.contactlessdining.R
import com.sampsolution.contactlessdining.app.ServiceApp
import com.sampsolution.contactlessdining.model.otp2factorModel.BaseResponse
import com.sampsolution.contactlessdining.model.otp2factorModel.VerifyResponse
import com.sampsolution.contactlessdining.model.teleSignOtpModel.sendTeleSign.SendTeleSignResponse
import com.sampsolution.contactlessdining.model.teleSignOtpModel.verifyTeleSign.TeleSignVerifyResponse
import com.sampsolution.contactlessdining.utils.Constant
import okhttp3.Credentials
import okhttp3.Interceptor
import okhttp3.OkHttpClient
import okhttp3.logging.HttpLoggingInterceptor
import java.util.concurrent.TimeUnit
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response
import retrofit2.Retrofit
import retrofit2.converter.gson.GsonConverterFactory


class TeleSignServiceRepository {
    private var hotVideoService: TeleSignServiceAPI? = null

    //    private var hotVideoService2: FleetServiceAPI? = null
    private val context = ServiceApp.context

    companion object {
        private var VPNRepository: TeleSignServiceRepository? = null

        @Synchronized
        fun getInstance(): TeleSignServiceRepository? {
            if (VPNRepository == null) {
                VPNRepository = TeleSignServiceRepository()
            }
            return VPNRepository
        }
    }

    init {
        val okHttp = OkHttpClient.Builder()
            .connectTimeout(2, TimeUnit.MINUTES)
//            .writeTimeout(10, TimeUnit.SECONDS)
//            .readTimeout(30, TimeUnit.SECONDS)
            .cache(null)

        okHttp.addInterceptor(Interceptor {
            val newRequest = it.request().newBuilder()
                .build()
            return@Interceptor it.proceed(newRequest)
        })

        val logging = HttpLoggingInterceptor()
        logging.level = HttpLoggingInterceptor.Level.BODY
        okHttp.addInterceptor(logging)

        val okHttpClient = okHttp.build()
        val gson = GsonBuilder()
            .setLenient()
            .create()
//        var basic = Credentials.basic("YOUR_USERNAME", "YOUR_PASSWORD")

        val retrofit = Retrofit.Builder()
            .addConverterFactory(GsonConverterFactory.create(gson))
            .client(okHttpClient)
            .baseUrl(TeleSignServiceAPI.API_BASE_URL)
            .build()

        hotVideoService = retrofit.create(TeleSignServiceAPI::class.java)


//        val retrofit2 = Retrofit.Builder()
//            .baseUrl(FleetServiceAPI.API_BASE_URL)
//            .addConverterFactory(ScalarsConverterFactory.create())
////            .client(okHttpClient)
//            .build()
//
//        hotVideoService2 = retrofit2.create(FleetServiceAPI::class.java)

    }



    fun getTeleSignOtpApi(map: ArrayMap<String?, Any?>): LiveData<SendTeleSignResponse?> {
        val data: MutableLiveData<SendTeleSignResponse?> = MutableLiveData()
        val basic = Credentials.basic(Constant.TELESIGN_USERNAME, Constant.TELESIGN_PASSWORD)
        hotVideoService?.getSendTelesignOtpOtp(basic,map)
            ?.enqueue(object : Callback<SendTeleSignResponse?> {
                override fun onResponse(
                    call: Call<SendTeleSignResponse?>,
                    response: Response<SendTeleSignResponse?>
                ) {
                    response.body()?.let {
                        data.value = it
                    } ?: run {
                        data.value = null
                        Toast.makeText(
                            context,
                            context?.resources?.getString(R.string.somthing_wrong),
                            Toast.LENGTH_SHORT
                        ).show()
                    }
                }

                override fun onFailure(call: Call<SendTeleSignResponse?>, t: Throwable) {
                    t.printStackTrace()
                    data.value = null
                }
            })
        return data
    }

    fun getTeleSignVerifyOtpApi(verify_code: String,reference_id: String): LiveData<TeleSignVerifyResponse?> {
        val data: MutableLiveData<TeleSignVerifyResponse?> = MutableLiveData()
        val basic = Credentials.basic(Constant.TELESIGN_USERNAME, Constant.TELESIGN_PASSWORD)

        hotVideoService?.getVerifyTeleSignVerifyOtp(basic,reference_id,verify_code)
            ?.enqueue(object : Callback<TeleSignVerifyResponse?> {
                override fun onResponse(
                    call: Call<TeleSignVerifyResponse?>,
                    response: Response<TeleSignVerifyResponse?>
                ) {
                    response.body()?.let {
                        data.value = it
                    } ?: run {
                        data.value = null
                        Toast.makeText(
                            context,
                            context?.resources?.getString(R.string.somthing_wrong),
                            Toast.LENGTH_SHORT
                        ).show()
                    }
                }

                override fun onFailure(call: Call<TeleSignVerifyResponse?>, t: Throwable) {
                    t.printStackTrace()
                    data.value = null
                }
            })
        return data
    }

}