package com.sampsolution.contactlessdining.model.checkOutModel

import com.google.gson.annotations.SerializedName

data class CheckOutResponse(
    @SerializedName("success"      ) var success     : Boolean? = null,
    @SerializedName("message"      ) var message     : String?  = null,
    @SerializedName("user_id"      ) var userId      : String?  = null,
    @SerializedName("order_number" ) var orderNumber : String?  = null
)
