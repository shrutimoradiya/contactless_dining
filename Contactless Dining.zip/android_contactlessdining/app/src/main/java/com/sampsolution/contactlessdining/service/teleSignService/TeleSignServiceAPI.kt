package com.sampsolution.contactlessdining.service.teleSignService

import android.util.ArrayMap
import com.sampsolution.contactlessdining.model.otp2factorModel.BaseResponse
import com.sampsolution.contactlessdining.model.otp2factorModel.VerifyResponse
import com.sampsolution.contactlessdining.model.teleSignOtpModel.sendTeleSign.SendTeleSignResponse
import com.sampsolution.contactlessdining.model.teleSignOtpModel.verifyTeleSign.TeleSignVerifyResponse
import retrofit2.Call
import retrofit2.http.*

interface TeleSignServiceAPI {

    companion object {
        private const val BASE_URL = "https://rest-ww.telesign.com/"
        const val API_BASE_URL = "${BASE_URL}v1/"
    }


    @POST("verify/sms")
    @FormUrlEncoded
    fun getSendTelesignOtpOtp(
        @Header("Authorization") h1: String,
        @FieldMap params: ArrayMap<String?, Any?>
    ): Call<SendTeleSignResponse?>?


    @GET("verify/{reference_id}")
    fun getVerifyTeleSignVerifyOtp(
        @Header("Authorization") h1: String,
        @Path("reference_id") referenceId: String,
        @Query("verify_code") verifyCode: String
    ): Call<TeleSignVerifyResponse?>?


}