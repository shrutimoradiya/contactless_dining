package com.sampsolution.contactlessdining.view.activity

import android.os.Bundle
import android.util.ArrayMap
import android.widget.Toast
import com.bumptech.glide.Glide
import com.google.gson.Gson
import com.sampsolution.contactlessdining.R
import com.sampsolution.contactlessdining.databinding.ActivityProfileBinding
import com.sampsolution.contactlessdining.model.loginModel.UserData
import com.sampsolution.contactlessdining.utils.Constant
import com.sampsolution.contactlessdining.utils.SharedPref
import com.sampsolution.contactlessdining.view.dialog.PhotoOptionsDialog
import okhttp3.MediaType
import okhttp3.MediaType.Companion.toMediaTypeOrNull
import okhttp3.MultipartBody
import okhttp3.RequestBody
import java.io.File

class ProfileActivity : CameraActivity(), PhotoOptionsDialog.onOptionSelected {

    private val binding: ActivityProfileBinding by lazy {
        ActivityProfileBinding.inflate(
            layoutInflater
        )
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(binding.root)

        binding.ivBack.setOnClickListener { onBackPressed() }

        SharedPref(this).userInfo?.let {
            try {
                Gson().fromJson(it, UserData::class.java)?.let { it1 ->
                    binding.edtFirstName.text = it1.firstName
                    binding.edtLastName.text = it1.lastName
                    binding.edtPhoneNo.text = "${it1.countryCode} ${it1.mobileNumber}"
                    binding.edtEmail.text = it1.email
                    Glide.with(this).load(it1.userImages).error(R.drawable.profile).into(binding.ivProfileImage)
                }
            } catch (exp: Exception) {

            }
        }

        binding.flPhoto.setOnClickListener {
            PhotoOptionsDialog(this, this).show()
        }

        binding.tvChangePhoto.setOnClickListener {
            binding.flPhoto.performClick()
        }
    }

    override fun showPhotos() {
        Glide.with(this).load(photoData?.uri).error(R.drawable.profile).into(binding.ivProfileImage)

        val id = Constant.getData(this, Constant.USERID)

        id?.let {
            photoData?.photoFile?.let { it1 ->
                contactlessService?.profileImageUploadApi(this, it, it1)?.observeForever {
                    it?.let { it1 ->
                        SharedPref(this).userInfo?.let {
                            Gson().fromJson(it, UserData::class.java)?.let { data ->
                                try {
                                    data.userImages = it1.image
                                    SharedPref(this).userInfo = Gson().toJson(data)
                                } catch (exp: Exception) {

                                }
                            }

                        }
                        Toast.makeText(this, it1.message, Toast.LENGTH_SHORT).show()
                    }
                }
            }
        }
    }

    override fun onCameraClick() {
        dispatchTakePictureIntent()
    }

    override fun onGalleryClick() {
        dispatchPickUpPictureIntent()
    }
}