package com.sampsolution.contactlessdining.model.otp2factorModel

import com.google.gson.annotations.SerializedName

data class BaseResponse(
    @SerializedName("Status"  ) var Status  : String? = null,
    @SerializedName("Details" ) var Details : String? = null,
    @SerializedName("OTP"     ) var OTP     : String? = null
)
