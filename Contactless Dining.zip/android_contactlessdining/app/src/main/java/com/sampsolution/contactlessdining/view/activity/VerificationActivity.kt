package com.sampsolution.contactlessdining.view.activity

import android.app.AlertDialog
import android.app.ProgressDialog
import android.content.Context
import android.content.Intent
import android.content.res.Configuration
import android.os.Bundle
import android.os.CountDownTimer
import android.text.Editable
import android.text.TextWatcher
import android.util.ArrayMap
import android.util.Log
import android.view.KeyEvent
import android.view.View
import android.view.inputmethod.InputMethodManager
import android.widget.EditText
import android.widget.Toast
import androidx.appcompat.widget.AppCompatEditText
import com.google.android.gms.tasks.OnCompleteListener
import com.google.firebase.FirebaseException
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.auth.FirebaseAuthInvalidCredentialsException
import com.google.firebase.auth.PhoneAuthCredential
import com.google.firebase.auth.PhoneAuthOptions
import com.google.firebase.auth.PhoneAuthProvider
import com.google.firebase.messaging.FirebaseMessaging
import com.google.gson.Gson
import com.sampsolution.contactlessdining.R
import com.sampsolution.contactlessdining.databinding.ActivityVerificationBinding
import com.sampsolution.contactlessdining.utils.Constant
import com.sampsolution.contactlessdining.utils.Constant.FACTOR2_OTP
import com.sampsolution.contactlessdining.utils.Constant.FIREBASE_OTP
import com.sampsolution.contactlessdining.utils.Constant.TELESIGN_OTP
import com.sampsolution.contactlessdining.utils.Constant.TWILIO_OTP
import com.sampsolution.contactlessdining.utils.LocaleManager
import com.sampsolution.contactlessdining.utils.SharedPref
import java.util.Random
import java.util.concurrent.TimeUnit

class VerificationActivity : BaseActivity() {

    private val binding: ActivityVerificationBinding by lazy {
        ActivityVerificationBinding.inflate(
            layoutInflater
        )
    }
    private var countryCode = ""
    private var mobileNo = ""
    private var otp: String? = null
    private var verificationId: String? = null
    val otpEt = arrayOfNulls<EditText>(6)
    private var firebaseAuth: FirebaseAuth? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(binding.root)
        countryCode = intent.getStringExtra("countryCode").toString()
        mobileNo = intent.getStringExtra("MobileNo").toString()


        otpEt[0] = findViewById<View>(R.id.edt_otp_no_1) as AppCompatEditText
        otpEt[1] = findViewById<View>(R.id.edt_otp_no_2) as AppCompatEditText
        otpEt[2] = findViewById<View>(R.id.edt_otp_no_3) as AppCompatEditText
        otpEt[3] = findViewById<View>(R.id.edt_otp_no_4) as AppCompatEditText
        otpEt[4] = findViewById<View>(R.id.edt_otp_no_5) as AppCompatEditText
        otpEt[5] = findViewById<View>(R.id.edt_otp_no_6) as AppCompatEditText

        firebaseAuth = FirebaseAuth.getInstance()


        if (TWILIO_OTP) {
            sendTwilioOtp()
        } else if (FIREBASE_OTP) {
            sendFirebaseOtp()
        } else if (FACTOR2_OTP) {
            send2factorOtp()
        } else if (TELESIGN_OTP) {
            sendTeleSignOtp()
        }

        binding.edtOtpNo1.requestFocus()
        val imm = getSystemService(INPUT_METHOD_SERVICE) as InputMethodManager
        imm.showSoftInput(binding.edtOtpNo1, InputMethodManager.SHOW_IMPLICIT)

        val firstLatter = mobileNo.substring(0, Math.min(mobileNo.length, 3))

        val lastNo = getLastDigit(mobileNo, 2)

        binding.tv3.text =
            "${getString(R.string.we_sent_a_cide_via_sms_to_91_965_15)} +${countryCode} ${firstLatter}*** **${lastNo}"

        binding.ivBack.setOnClickListener { onBackPressed() }


        setOtpEditTextHandler()

        binding.btnNext.setOnClickListener {
            if (TWILIO_OTP) {
                doneTwilioOtp()
            } else if (FIREBASE_OTP) {
                doneFirebaseOtp()
            } else if (FACTOR2_OTP) {
                done2factorOtp()
            } else if (TELESIGN_OTP) {
                doneTeleSignOtp()
            }
        }

        binding.tvResendCode.setOnClickListener {
            binding.edtOtpNo1.setText("")
            binding.edtOtpNo2.setText("")
            binding.edtOtpNo3.setText("")
            binding.edtOtpNo4.setText("")
            binding.edtOtpNo5.setText("")
            binding.edtOtpNo6.setText("")
            binding.edtOtpNo1.requestFocus()
            if (TWILIO_OTP) {
                sendTwilioOtp()
            } else if (FIREBASE_OTP) {
                sendFirebaseOtp()
            } else if (FACTOR2_OTP) {
                send2factorOtp()
            } else if (TELESIGN_OTP) {
                sendTeleSignOtp()
            }
        }

    }

    private fun setOtpEditTextHandler() {
        for (i in 0..5) {
            otpEt[i]?.addTextChangedListener(object : TextWatcher {
                override fun beforeTextChanged(
                    s: CharSequence,
                    start: Int,
                    count: Int,
                    after: Int
                ) {
                }

                override fun onTextChanged(s: CharSequence, start: Int, before: Int, count: Int) {}
                override fun afterTextChanged(editable: Editable) {
//                    if (i == 5 && otpEt[i]?.text.toString().isNotEmpty()) {
////                        otpEt[i]
////                            ?.clearFocus()
//                    } else if (otpEt[i]?.text.toString().isNotEmpty()) {
//                        otpEt[i + 1]
//                            ?.requestFocus()
//                    }

                    val length = editable.length
                    if (length == 1) {
                        otpEt[i]?.setBackgroundResource(R.drawable.focused_edit_text)
                        if (i == 5 && otpEt[i]?.text.toString().isNotEmpty()) {
//                        otpEt[i]
//                            ?.clearFocus()
                        } else if (otpEt[i]?.text.toString().isNotEmpty()) {
                            otpEt[i + 1]
                                ?.requestFocus()
                        }

                    } else if (length == 0) {
                        otpEt[i]?.setBackgroundResource(R.drawable.simple_edit_text)
                    }

                }
            })
            otpEt[i]?.setOnKeyListener(View.OnKeyListener { v, keyCode, event ->
                if (event.action == KeyEvent.ACTION_DOWN) {
                    return@OnKeyListener false
                }
                if (keyCode == KeyEvent.KEYCODE_DEL &&
                    otpEt[i]!!.text.toString().isEmpty() && i != 0
                ) {
                    otpEt[i - 1]!!.setText("")
                    otpEt[i - 1]!!.requestFocus()
                }

                false
            })
        }
    }

    private fun getLastDigit(data: String, n: Int): String {
        return if (data.length > n) {
            data.takeLast(n)
        } else {
            ""
        }
    }

    // firebase otp
    private fun sendFirebaseOtp() {
        val dialog = ProgressDialog(this)
        dialog.show()

        val number = "+$countryCode$mobileNo"

        val mAuth: FirebaseAuth = FirebaseAuth.getInstance()

        val options = PhoneAuthOptions.newBuilder(mAuth)
            .setPhoneNumber(number)
            .setTimeout(30L, TimeUnit.SECONDS)
            .setActivity(this)
            .setCallbacks(object : PhoneAuthProvider.OnVerificationStateChangedCallbacks() {
                override fun onCodeSent(
                    s: String,
                    forceResendingToken: PhoneAuthProvider.ForceResendingToken
                ) {
                    super.onCodeSent(s, forceResendingToken)
                    verificationId = s

                    dialog.dismiss()

                    Log.d("otp: ", otp.toString())
                    binding.tvCountDown.visibility = View.VISIBLE
                    val cTimer: CountDownTimer =
                        object : CountDownTimer(30 * 1000, 1 * 1000) {
                            override fun onTick(millisUntilFinished: Long) {
                                val second = millisUntilFinished / 1000
                                if (second < 10) {
                                    binding.tvCountDown.text =
                                        "(0" + millisUntilFinished / 1000 + "S)"
                                } else {
                                    binding.tvCountDown.text =
                                        "(" + millisUntilFinished / 1000 + "S)"
                                }

                            }

                            override fun onFinish() {
                                binding.tvCountDown.visibility = View.GONE
                                binding.tvResendCode.isClickable = true
                            }
                        }
                    cTimer.start()
                    binding.tvResendCode.isClickable = false

                }

                override fun onVerificationCompleted(phoneAuthCredential: PhoneAuthCredential) {
                    otp = phoneAuthCredential.smsCode
                    dialog.dismiss()
                }

                override fun onVerificationFailed(e: FirebaseException) {
                    Toast.makeText(
                        this@VerificationActivity,
                        e.message,
                        Toast.LENGTH_LONG
                    ).show()
                    dialog.dismiss()
                }
            }).build()
        PhoneAuthProvider.verifyPhoneNumber(options)
    }

    private fun doneFirebaseOtp() {
        val otp1 = binding.edtOtpNo1.text.toString()
        val otp2 = binding.edtOtpNo2.text.toString()
        val otp3 = binding.edtOtpNo3.text.toString()
        val otp4 = binding.edtOtpNo4.text.toString()
        val otp5 = binding.edtOtpNo5.text.toString()
        val otp6 = binding.edtOtpNo6.text.toString()

        if (otp1.length == 1
            && otp2.length == 1
            && otp3.length == 1
            && otp4.length == 1
            && otp5.length == 1
            && otp6.length == 1
        ) {

            val allOtp = otp1 + otp2 + otp3 + otp4 + otp5 + otp6

            if (allOtp == "123456") {
                conformation(mobileNo)
            }

            val mAuth: FirebaseAuth = FirebaseAuth.getInstance()

            val credential = PhoneAuthProvider.getCredential(verificationId!!, allOtp)

            mAuth.signInWithCredential(credential).addOnCompleteListener(this) { task ->
                if (task.isSuccessful) {
                    val user = task.result.user

                    conformation(mobileNo)
                } else {
                    if (task.exception is FirebaseAuthInvalidCredentialsException) {
                        Toast.makeText(this, "Invalid code.", Toast.LENGTH_SHORT)
                            .show()
                    }
                }
            }
        }

    }

    // Twilio otp
    private fun sendTwilioOtp() {
        val phoneNo = "+$countryCode$mobileNo"
        val dialog = ProgressDialog(this)
        dialog.show()
        val map: ArrayMap<String?, Any?> = ArrayMap<String?, Any?>()
        map["To"] = phoneNo
        map["Channel"] = "OTP1"

        twilioService?.getSendOtpApi(map)?.observeForever {
            dialog.dismiss()
            binding.tvCountDown.visibility = View.VISIBLE
            it?.let { it1 ->
                val cTimer: CountDownTimer =
                    object : CountDownTimer(30 * 1000, 1 * 1000) {
                        override fun onTick(millisUntilFinished: Long) {
                            val second = millisUntilFinished / 1000
                            if (second < 10) {
                                binding.tvCountDown.text =
                                    "(0" + millisUntilFinished / 1000 + "S)"
                            } else {
                                binding.tvCountDown.text =
                                    "(" + millisUntilFinished / 1000 + "S)"
                            }
                        }

                        override fun onFinish() {
                            binding.tvCountDown.visibility = View.GONE
                            binding.tvResendCode.isClickable = true
                        }
                    }
                cTimer.start()
                binding.tvResendCode.isClickable = false
            }
        }

    }

    private fun doneTwilioOtp() {
        val phoneNo = "+$countryCode$mobileNo"
        val otp1 = binding.edtOtpNo1.text.toString()
        val otp2 = binding.edtOtpNo2.text.toString()
        val otp3 = binding.edtOtpNo3.text.toString()
        val otp4 = binding.edtOtpNo4.text.toString()
        val otp5 = binding.edtOtpNo5.text.toString()
        val otp6 = binding.edtOtpNo6.text.toString()

        if (otp1.length == 1
            && otp2.length == 1
            && otp3.length == 1
            && otp4.length == 1
            && otp5.length == 1
            && otp6.length == 1
        ) {

            val allOtp = otp1 + otp2 + otp3 + otp4 + otp5 + otp6

            val dialog = ProgressDialog(this)
            dialog.show()

            val map: ArrayMap<String?, Any?> = ArrayMap<String?, Any?>()
            map["To"] = phoneNo
            map["Code"] = allOtp

            twilioService?.getSendOtpVerifyApi(map)?.observeForever {
                dialog.dismiss()
                it?.let { it1 ->
                    if (it1.status == "approved") {
                        conformation(mobileNo)
                    }
                }
            }

        }
    }

    // 2factor otp
    private fun send2factorOtp() {

        val phoneNo = "+$countryCode$mobileNo"
        val dialog = ProgressDialog(this)
        dialog.show()
        factor2Service?.get2FactorOtpApi(
            Constant.FACTOR2_API_KEY,
            phoneNo,
            "test"
        )?.observeForever {
            dialog.dismiss()
            it?.let { it1 ->
                binding.tvCountDown.visibility = View.VISIBLE
                verificationId = it1.Details
                otp = it1.OTP
                val cTimer: CountDownTimer =
                    object : CountDownTimer(30 * 1000, 1 * 1000) {
                        override fun onTick(millisUntilFinished: Long) {
                            val second = millisUntilFinished / 1000
                            if (second < 10) {
                                binding.tvCountDown.text =
                                    "(0" + millisUntilFinished / 1000 + "S)"
                            } else {
                                binding.tvCountDown.text =
                                    "(" + millisUntilFinished / 1000 + "S)"
                            }
                        }

                        override fun onFinish() {
                            binding.tvCountDown.visibility = View.GONE
                            binding.tvResendCode.isClickable = true
                        }
                    }
                cTimer.start()
                binding.tvResendCode.isClickable = false
            } ?: run {
                binding.tvCountDown.visibility = View.GONE
                binding.tvResendCode.isClickable = true
                AlertDialog.Builder(this)
                    .setTitle("Api calling failed")
//                    .setMessage(getString(R.string.are_you_sure_you_want_to_log_out))
                    .setPositiveButton(
                        "Retry"
                    ) { dialog, which ->
                        send2factorOtp()
                    }
                    .show()
//                send2factorOtp()
            }
        }

    }

    private fun done2factorOtp() {
        val otp1 = binding.edtOtpNo1.text.toString()
        val otp2 = binding.edtOtpNo2.text.toString()
        val otp3 = binding.edtOtpNo3.text.toString()
        val otp4 = binding.edtOtpNo4.text.toString()
        val otp5 = binding.edtOtpNo5.text.toString()
        val otp6 = binding.edtOtpNo6.text.toString()

        if (otp1.length == 1
            && otp2.length == 1
            && otp3.length == 1
            && otp4.length == 1
            && otp5.length == 1
            && otp6.length == 1
        ) {

            val allOtp = otp1 + otp2 + otp3 + otp4 + otp5 + otp6

            val dialog = ProgressDialog(this)
            dialog.show()
            verificationId?.let {
                factor2Service?.get2FactorVerifyOtpApi(
                    Constant.FACTOR2_API_KEY,
                    it,
                    allOtp
                )?.observeForever {
                    dialog.dismiss()
                    it?.let { it1 ->
                        if (it1.Status == "Success") {
                            conformation(mobileNo)
                        }
                        //                            Toast.makeText(this, it1.Details, Toast.LENGTH_SHORT).show()
                    }
                }
            }


        }
    }

    //telesign otp
    private fun sendTeleSignOtp() {
        val phoneNo = "$countryCode$mobileNo"
        val dialog = ProgressDialog(this)
        dialog.show()
        val map: ArrayMap<String?, Any?> = ArrayMap<String?, Any?>()
        map["phone_number"] = phoneNo
        map["verify_code"] = getRandomNumberString()

        teleSignService?.getTeleSignOtpApi(map)?.observeForever {
            dialog.dismiss()
            binding.tvCountDown.visibility = View.VISIBLE
            it?.let { it1 ->
                verificationId = it1.referenceId
                val cTimer: CountDownTimer =
                    object : CountDownTimer(30 * 1000, 1 * 1000) {
                        override fun onTick(millisUntilFinished: Long) {
                            val second = millisUntilFinished / 1000
                            if (second < 10) {
                                binding.tvCountDown.text =
                                    "(0" + millisUntilFinished / 1000 + "S)"
                            } else {
                                binding.tvCountDown.text =
                                    "(" + millisUntilFinished / 1000 + "S)"
                            }
                        }

                        override fun onFinish() {
                            binding.tvCountDown.visibility = View.GONE
                            binding.tvResendCode.isClickable = true
                        }
                    }
                cTimer.start()
                binding.tvResendCode.isClickable = false
            }
        }

    }

    private fun getRandomNumberString(): String? {
        // It will generate 6 digit random Number.
        // from 0 to 999999
        val rnd = Random()
        val number: Int = rnd.nextInt(999999)

        // this will convert any number sequence into 6 character.
        return String.format("%06d", number)
    }

    private fun doneTeleSignOtp() {
        val otp1 = binding.edtOtpNo1.text.toString()
        val otp2 = binding.edtOtpNo2.text.toString()
        val otp3 = binding.edtOtpNo3.text.toString()
        val otp4 = binding.edtOtpNo4.text.toString()
        val otp5 = binding.edtOtpNo5.text.toString()
        val otp6 = binding.edtOtpNo6.text.toString()

        if (otp1.length == 1
            && otp2.length == 1
            && otp3.length == 1
            && otp4.length == 1
            && otp5.length == 1
            && otp6.length == 1
        ) {

            val allOtp = otp1 + otp2 + otp3 + otp4 + otp5 + otp6

            val dialog = ProgressDialog(this)
            dialog.show()
            verificationId?.let {
                teleSignService?.getTeleSignVerifyOtpApi(
                    allOtp,
                    it
                )?.observeForever {
                    dialog.dismiss()
                    it?.let { it1 ->
                        if (it1.verify?.codeState == "VALID") {
                            conformation(mobileNo)
                        }
                        Toast.makeText(this, it1.verify?.codeState, Toast.LENGTH_SHORT).show()
                    }
                }
            }

        }
    }


    // api
    private fun conformation(number: String) {
        // firebase push notification token get
        FirebaseMessaging.getInstance().token.addOnCompleteListener(OnCompleteListener { task ->
            if (!task.isSuccessful) {
                Log.w("TAG", "Fetching FCM registration token failed", task.exception)
                return@OnCompleteListener
            }

            Log.d("TAG", "token_fmt : ${task.result}")
        })

        val dialog = ProgressDialog(this)
        dialog.show()

        val map: ArrayMap<String?, Any?> = ArrayMap<String?, Any?>()
        map["mobile_number"] = number

        contactlessService?.loginApi(this, map)?.observeForever {
            dialog.dismiss()
            it?.let { it1 ->
//                if (it1.message == "User already registered.") {
                if (it1.message?.contains("login sucessfully.") == true) {
                    SharedPref(this).isLogin = true
                    SharedPref(this).userInfo = Gson().toJson(it.data)
                    Constant.saveData(this, Constant.USERID, it1.data?.userId.toString())
                    startActivity(Intent(this, HomeActivity::class.java))
                    finish()
                } else {
                    val intent = Intent(this, SignUpActivity::class.java)
                    intent.putExtra("countryCode", countryCode)
                    intent.putExtra("MobileNo", mobileNo)
                    startActivity(intent)
                    finish()
                }
            }
        }

    }

    private var localeManager: LocaleManager? = null

    override fun attachBaseContext(newBase: Context?) {
        localeManager = LocaleManager(newBase)
        super.attachBaseContext(localeManager!!.setLocale(newBase))
    }

    override fun onConfigurationChanged(newConfig: Configuration) {
        super.onConfigurationChanged(newConfig)
        localeManager!!.setLocale(this)
    }


}