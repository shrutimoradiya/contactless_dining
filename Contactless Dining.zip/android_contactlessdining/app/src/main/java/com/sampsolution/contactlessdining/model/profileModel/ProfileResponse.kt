package com.sampsolution.contactlessdining.model.profileModel

import com.google.gson.annotations.SerializedName

data class ProfileResponse(
    @SerializedName("success" ) var success : Boolean? = null,
    @SerializedName("message" ) var message : String?  = null,
    @SerializedName("user_id" ) var userId  : Int?     = null,
    @SerializedName("image"   ) var image   : String?  = null
)
