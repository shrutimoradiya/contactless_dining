package com.sampsolution.contactlessdining.service.twilioOtpService

import android.util.ArrayMap
import android.widget.Toast
import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import com.google.gson.GsonBuilder
import com.sampsolution.contactlessdining.R
import com.sampsolution.contactlessdining.app.ServiceApp
import com.sampsolution.contactlessdining.model.twilioOtpModel.sendOtpModel.SendOtpResponse
import com.sampsolution.contactlessdining.model.twilioOtpModel.verifyOtpModel.VerifyOtpResponse
import com.sampsolution.contactlessdining.utils.Constant.TWILIO_PASSWORD
import com.sampsolution.contactlessdining.utils.Constant.TWILIO_USERNAME
import okhttp3.Credentials
import okhttp3.Interceptor
import okhttp3.OkHttpClient
import okhttp3.logging.HttpLoggingInterceptor
import java.util.concurrent.TimeUnit
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response
import retrofit2.Retrofit
import retrofit2.converter.gson.GsonConverterFactory


class TwillioOtpServiceRepository {
    private var hotVideoService: TwillioOtpServiceAPI? = null

    //    private var hotVideoService2: FleetServiceAPI? = null
    private val context = ServiceApp.context

    companion object {
        private var VPNRepository: TwillioOtpServiceRepository? = null

        @Synchronized
        fun getInstance(): TwillioOtpServiceRepository? {
            if (VPNRepository == null) {
                VPNRepository = TwillioOtpServiceRepository()
            }
            return VPNRepository
        }
    }

    init {
        val okHttp = OkHttpClient.Builder()
            .connectTimeout(2, TimeUnit.MINUTES)
//            .writeTimeout(10, TimeUnit.SECONDS)
//            .readTimeout(30, TimeUnit.SECONDS)
            .cache(null)

        okHttp.addInterceptor(Interceptor {
            val newRequest = it.request().newBuilder()
                .build()
            return@Interceptor it.proceed(newRequest)
        })

        val logging = HttpLoggingInterceptor()
        logging.level = HttpLoggingInterceptor.Level.BODY
        okHttp.addInterceptor(logging)

        val okHttpClient = okHttp.build()
        val gson = GsonBuilder()
            .setLenient()
            .create()

        val retrofit = Retrofit.Builder()
            .addConverterFactory(GsonConverterFactory.create(gson))
            .client(okHttpClient)
            .baseUrl(TwillioOtpServiceAPI.API_BASE_URL)
            .build()

        hotVideoService = retrofit.create(TwillioOtpServiceAPI::class.java)


//        val retrofit2 = Retrofit.Builder()
//            .baseUrl(FleetServiceAPI.API_BASE_URL)
//            .addConverterFactory(ScalarsConverterFactory.create())
////            .client(okHttpClient)
//            .build()
//
//        hotVideoService2 = retrofit2.create(FleetServiceAPI::class.java)

    }


    fun getSendOtpApi(map: ArrayMap<String?, Any?>): LiveData<SendOtpResponse?> {
        val data: MutableLiveData<SendOtpResponse?> = MutableLiveData()
        val basic = Credentials.basic(TWILIO_USERNAME, TWILIO_PASSWORD)

        hotVideoService?.getSendOtp(basic, map)
            ?.enqueue(object : Callback<SendOtpResponse?> {
                override fun onResponse(
                    call: Call<SendOtpResponse?>,
                    response: Response<SendOtpResponse?>
                ) {
                    response.body()?.let {
                        data.value = it
                    } ?: run {
                        data.value = null
                        Toast.makeText(
                            context,
                            context?.resources?.getString(R.string.somthing_wrong),
                            Toast.LENGTH_SHORT
                        ).show()
                    }
                }

                override fun onFailure(call: Call<SendOtpResponse?>, t: Throwable) {
                    t.printStackTrace()
                    data.value = null
                }
            })
        return data
    }

    fun getSendOtpVerifyApi(map: ArrayMap<String?, Any?>): LiveData<VerifyOtpResponse?> {
        val data: MutableLiveData<VerifyOtpResponse?> = MutableLiveData()
        val basic = Credentials.basic(TWILIO_USERNAME, TWILIO_PASSWORD)

        hotVideoService?.getVerifyOtp(basic, map)
            ?.enqueue(object : Callback<VerifyOtpResponse?> {
                override fun onResponse(
                    call: Call<VerifyOtpResponse?>,
                    response: Response<VerifyOtpResponse?>
                ) {
                    response.body()?.let {
                        data.value = it
                    } ?: run {
                        data.value = null
                        Toast.makeText(
                            context,
                            context?.resources?.getString(R.string.somthing_wrong),
                            Toast.LENGTH_SHORT
                        ).show()
                    }
                }

                override fun onFailure(call: Call<VerifyOtpResponse?>, t: Throwable) {
                    t.printStackTrace()
                    data.value = null
                }
            })
        return data
    }

}