package com.sampsolution.contactlessdining.view.activity

import android.content.Intent
import android.os.Bundle
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import com.sampsolution.contactlessdining.R
import com.sampsolution.contactlessdining.databinding.ActivityHomeBinding
import com.sampsolution.contactlessdining.databinding.ActivityMyCardBinding
import com.sampsolution.contactlessdining.view.adapter.MyCardAdapter
import com.sampsolution.contactlessdining.view.adapter.OrderDetailsAdapter

class MyCardActivity : BaseActivity() {

    private val binding: ActivityMyCardBinding by lazy {
        ActivityMyCardBinding.inflate(
            layoutInflater
        )
    }
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(binding.root)

        binding.ivBack.setOnClickListener { onBackPressed() }

        binding.btnNext.setOnClickListener {
            startActivity(Intent(this,AddCardActivity::class.java))
        }

        binding.rvCard.adapter = MyCardAdapter(this)
        binding.rvCard.isNestedScrollingEnabled = false
    }
}