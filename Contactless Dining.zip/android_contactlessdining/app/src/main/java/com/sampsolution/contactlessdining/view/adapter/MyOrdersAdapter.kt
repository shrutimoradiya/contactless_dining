package com.sampsolution.contactlessdining.view.adapter

import android.content.Context
import android.content.Intent
import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.RecyclerView
import com.bumptech.glide.Glide
import com.sampsolution.contactlessdining.R
import com.sampsolution.contactlessdining.databinding.ItemMyOrdersBinding
import com.sampsolution.contactlessdining.model.orderStatusModel.OrderStatusData
import com.sampsolution.contactlessdining.view.activity.MyOrderDetailsActivity

data class MyOrdersAdapter(
    var context: Context,
    val list: ArrayList<OrderStatusData>,
) :
    RecyclerView.Adapter<MyOrdersAdapter.TextModelViewHolder>() {

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): TextModelViewHolder {
        return TextModelViewHolder(
            ItemMyOrdersBinding.inflate(
                LayoutInflater.from(
                    context
                )
            )
        )
    }

    override fun onBindViewHolder(holder: TextModelViewHolder, position: Int) {
        try {
            val data = list[position]
            Glide.with(context).load(data.itemImage).into(holder.binding.img)

            holder.binding.tvName.text = "Order  #${data.orderNumber}"
            holder.binding.tvItemName.text = data.itemName
            holder.binding.tvDateTime.text = data.time
            holder.binding.tvOrderNow.text = data.orderStatus

            if (data.orderStatus == "Pending") {
                holder.binding.tvOrderNow.setTextColor(context.getColor(R.color.txt_pending))
            }
            if (data.orderStatus == "Processing") {
                holder.binding.tvOrderNow.setTextColor(context.getColor(R.color.orange))
            }
            if (data.orderStatus == "Completed") {
                holder.binding.tvOrderNow.setTextColor(context.getColor(R.color.green_main))
            }


            holder.itemView.setOnClickListener {
                val intent = Intent(context, MyOrderDetailsActivity::class.java)
                intent.putExtra("Order id", data.orderNumber)
                intent.putExtra("key", "myOrder")
                intent.putExtra("status", data.orderStatus)
                context.startActivity(intent)
            }


        } catch (e: Exception) {
            e.printStackTrace()
        }
    }

    override fun getItemCount(): Int {
        return list.size
    }

    data class TextModelViewHolder(val binding: ItemMyOrdersBinding) :
        RecyclerView.ViewHolder(binding.root)


}
