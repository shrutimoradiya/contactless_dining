package com.sampsolution.contactlessdining.model.razorpayErrorModel

import com.google.gson.annotations.SerializedName

data class Error (

  @SerializedName("code"        ) var code        : String? = null,
  @SerializedName("description" ) var description : String? = null,
  @SerializedName("source"      ) var source      : String? = null,
  @SerializedName("step"        ) var step        : String? = null,
  @SerializedName("reason"      ) var reason      : String? = null

)