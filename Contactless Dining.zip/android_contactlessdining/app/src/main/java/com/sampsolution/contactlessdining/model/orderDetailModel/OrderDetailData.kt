package com.sampsolution.contactlessdining.model.orderDetailModel

import com.google.gson.annotations.SerializedName

data class OrderDetailData(
    @SerializedName("order_instructions" ) var orderInstructions : String?          = null,
    @SerializedName("order_number"       ) var orderNumber       : String?          = null,
    @SerializedName("order_status"       ) var orderStatus       : String?          = null,
    @SerializedName("restaurant_name"    ) var restaurantName    : String?          = null,
    @SerializedName("restaurant_address" ) var restaurantAddress : String?          = null,
    @SerializedName("time"               ) var time              : String?          = null,
    @SerializedName("items"              ) var items             : ArrayList<Items> = arrayListOf(),
    @SerializedName("item_total"         ) var itemTotal         : String?          = null,
    @SerializedName("variations"         ) var variations        : String?          = null,
    @SerializedName("total_discount"     ) var totalDiscount     : String?          = null,
    @SerializedName("sub_total"          ) var subTotal          : String?          = null,
    @SerializedName("taxes"              ) var taxes             : String?          = null,
    @SerializedName("total_amount"       ) var totalAmount       : String?          = null,
    @SerializedName("transaction_id"     ) var transactionId     : String?          = null,
    @SerializedName("gateway_name"       ) var gatewayName       : String?          = null,
    @SerializedName("payment_status"     ) var paymentStatus     : Int?             = null,
    @SerializedName("payment_time"       ) var paymentTime       : String?          = null
)
