package com.sampsolution.contactlessdining.model.teleSignOtpModel.sendTeleSign

import com.google.gson.annotations.SerializedName

data class Status(
    @SerializedName("updated_on"  ) var updatedOn   : String? = null,
    @SerializedName("code"        ) var code        : Int?    = null,
    @SerializedName("description" ) var description : String? = null

)
