package com.sampsolution.contactlessdining.view.adapter

import android.content.Context
import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.sampsolution.contactlessdining.R
import com.sampsolution.contactlessdining.databinding.ItemNameBinding
import com.sampsolution.contactlessdining.model.menuCategoryModel.Categories

data class MenuNameAdapter(
    var context: Context,
    var list: ArrayList<Categories>,
    val listener: onClickListener

) :
    RecyclerView.Adapter<MenuNameAdapter.TextModelViewHolder>() {


    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): TextModelViewHolder {
        return TextModelViewHolder(
            ItemNameBinding.inflate(
                LayoutInflater.from(
                    context
                )
            )
        )
    }

    override fun onBindViewHolder(holder: TextModelViewHolder, position: Int) {
        try {
            val data = list[position]

            if (data.isSelected) {
                holder.binding.listtext.setBackgroundResource(R.drawable.shape_btn_10dp)
                holder.binding.listtext.setTextColor(context.getColor(R.color.white_common))
            } else {
                holder.binding.listtext.setBackgroundResource(R.drawable.shape_border_category)
                holder.binding.listtext.setTextColor(context.getColor(R.color.white))
            }

            holder.binding.listtext.setOnClickListener {
                listener.onClick(position, data)

                notifyDataSetChanged()
            }

            holder.binding.listtext.text = data.categoryName


        } catch (e: Exception) {
            e.printStackTrace()
        }
    }

    override fun getItemCount(): Int {
        return list.size
    }

    data class TextModelViewHolder(val binding: ItemNameBinding) :
        RecyclerView.ViewHolder(binding.root)

    interface onClickListener {
        fun onClick(position: Int, data: Categories)
    }


}

