package com.sampsolution.contactlessdining.utils

import android.content.Context
import android.net.Uri
import kotlin.Throws
import android.os.Environment
import java.io.File
import java.io.IOException

class PhotoData(private val context: Context) {

    var uri: Uri? = null
    var photoFile: File? = null

    @Throws(IOException::class)
    fun createImageFile(): File {
        val imageFileName = System.currentTimeMillis().toString()
        val storageDir =
            Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_PICTURES)
        return File.createTempFile(
            imageFileName,
            ".jpg",
            storageDir
        )
    }

    @Throws(IOException::class)
    fun createImageFilePng(): File {
        val imageFileName = System.currentTimeMillis().toString()
        val storageDir =
            Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_PICTURES)
        return File.createTempFile(
            imageFileName,
            ".png",
            storageDir
        )
    }
}