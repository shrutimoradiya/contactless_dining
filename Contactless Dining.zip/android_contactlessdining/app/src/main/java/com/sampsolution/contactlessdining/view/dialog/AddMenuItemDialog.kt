package com.sampsolution.contactlessdining.view.dialog

import android.os.Bundle
import android.text.TextUtils
import android.view.LayoutInflater
import android.view.View
import android.view.WindowManager
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.WindowInsetsControllerCompat
import com.bumptech.glide.Glide
import com.google.android.material.bottomsheet.BottomSheetBehavior
import com.google.android.material.bottomsheet.BottomSheetDialog
import com.sampsolution.contactlessdining.R
import com.sampsolution.contactlessdining.databinding.DialogScanMenuItemBinding
import com.sampsolution.contactlessdining.model.menuModel.Menus
import com.sampsolution.contactlessdining.model.menuModel.Options
import com.sampsolution.contactlessdining.view.adapter.SizeAdapter

data class AddMenuItemDialog(
    val context: AppCompatActivity,
    val data: Menus,
    val listener: OnOptionSelected
) : BottomSheetDialog(context) {
    private var dialogbinding: DialogScanMenuItemBinding? = null
    var totalPrize = 0.0
    var variationsId = 0
    var optionsId = ""
    var optionList: ArrayList<Int> = arrayListOf()
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        dialogbinding = DialogScanMenuItemBinding.inflate(LayoutInflater.from(context))

        dialogbinding?.let { binding ->
            setContentView(binding.root)

//            hideSystemUI()

            totalPrize = data.itemPrice?.toFloat()?.toDouble()!!

            binding.tvName.text = data.itemName
            binding.tvDescription.text = data.itemDescription
            binding.tvPrize.text = "$${data.itemPrice}"
            Glide.with(context).load(data.itemImage).into(binding.img)
            binding.txtTotalRs.text = "$${totalPrize}"
            if (data.itemType == "non veg") {
                binding.icVeg.setImageResource(R.drawable.ic_non_veg)
                binding.tvVeg.text = "Non Veg"
            } else {
                binding.tvVeg.text = "Veg"
                binding.icVeg.setImageResource(R.drawable.ic_veg)
            }

            var count = 1

            binding.btnAdd.setOnClickListener {
                count++
                binding.tvItemCount.text = count.toString()
                var prize = 0.0
                for (temp in data.variations) {
                    for (temp1 in temp.options) {
                        if (temp1.isSelected) {
                            temp1.optionPrice?.let {
                                prize += (it.toDouble())
                            }
                        }
                    }
                }
                val total = ((prize + totalPrize) * count)
                binding.txtTotalRs.text = "$$total"
            }

            binding.btnMinus.setOnClickListener {
                if (count != 1) {
                    count--
                }
                binding.tvItemCount.text = count.toString()
                var prize = 0.0
                for (temp in data.variations) {
                    for (temp1 in temp.options) {
                        if (temp1.isSelected) {
                            temp1.optionPrice?.let {
                                prize += (it.toDouble())

                            }
                        }
                    }
                }
                val total = ((prize + totalPrize) * count)
                binding.txtTotalRs.text = "$$total"
            }

            binding.rvData.adapter =
                SizeAdapter(context, data.variations, object :
                    SizeAdapter.OnClickListener {
                    override fun onCheckClick(options: Options) {
                        optionList.clear()
                        var prize1 = 0.0
                        for (temp in data.variations) {
                            for (temp1 in temp.options) {
                                if (temp1.isSelected) {
                                    temp1.optionPrice?.let {
                                        prize1 += (it.toDouble())
                                    }
                                    temp1.optionId?.let { optionList.add(it) }
                                    optionsId = TextUtils.join(",", optionList)

//                                    options_id= temp1.optionId!!
                                    variationsId = temp.variationId!!
                                }
                            }
                        }
                        val total = ((prize1 + totalPrize) * count)
                        binding.txtTotalRs.text = "$$total"
                    }
                })

            binding.rvData.isNestedScrollingEnabled = false

            binding.btnAddItem.setOnClickListener {
                listener.onItemClick(
                    data.itemId,
                    count,
                    variationsId,
                    optionsId
                )
                dismiss()
            }

        }

        setCanceledOnTouchOutside(true)
        val layoutParams = WindowManager.LayoutParams()
        layoutParams.copyFrom(window?.attributes)
        layoutParams.width = WindowManager.LayoutParams.MATCH_PARENT
        layoutParams.height = WindowManager.LayoutParams.WRAP_CONTENT
        behavior.state = BottomSheetBehavior.STATE_EXPANDED
        window?.attributes = layoutParams
//        window?.setBackgroundDrawable(ColorDrawable(android.graphics.Color.TRANSPARENT))
        (dialogbinding!!.root.parent as View).setBackgroundColor(
            context.resources.getColor(android.R.color.transparent)
        )
    }

//

    interface OnOptionSelected {
        fun onItemClick(
            id: Int?,
            count: Int,
            variationsId: Int,
            optionsId: String,
        )
    }

    private fun hideSystemUI() {
        window?.let { WindowCompat.setDecorFitsSystemWindows(it, false) }
        window?.let {
            WindowInsetsControllerCompat(
                it,
                window!!.decorView.findViewById(android.R.id.content)
            ).let { controller ->
                controller.hide(WindowInsetsCompat.Type.systemBars())

                controller.systemBarsBehavior =
                    WindowInsetsControllerCompat.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
            }
        }
    }
}

