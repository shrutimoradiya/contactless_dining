package com.sampsolution.contactlessdining.view.activity

import android.content.ActivityNotFoundException
import android.content.Intent
import android.os.Bundle
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.sampsolution.contactlessdining.databinding.ActivityContactUsBinding

class ContactUSActivity : AppCompatActivity() {

    private val binding: ActivityContactUsBinding by lazy {
        ActivityContactUsBinding.inflate(
            layoutInflater
        )
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(binding.root)

        binding.ivBack.setOnClickListener { onBackPressed() }

        binding.btnSubmit.setOnClickListener {
            val intent = Intent(Intent.ACTION_SEND)
            intent.setType("message/rfc822")
            intent.putExtra(Intent.EXTRA_EMAIL, arrayOf("shweta.sampsolution@gmail.com"))
            intent.putExtra(Intent.EXTRA_SUBJECT, binding.edtFirstName.text.toString())
            intent.putExtra(Intent.EXTRA_TEXT, binding.edtYourMsg.text.toString())
            try {
                startActivity(Intent.createChooser(intent, "Send mail"))
            } catch (e: ActivityNotFoundException) {
                Toast.makeText(
                    this,
                    "There are no email clients installed.",
                    Toast.LENGTH_SHORT
                ).show()
            }
        }
    }
}