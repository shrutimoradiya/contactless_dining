package com.sampsolution.contactlessdining.model.teleSignOtpModel.sendTeleSign

import com.google.gson.annotations.SerializedName

data class SendTeleSignResponse(
    @SerializedName("reference_id" ) var referenceId : String?           = null,
    @SerializedName("sub_resource" ) var subResource : String?           = null,
    @SerializedName("status"       ) var status      : Status?           = Status(),
    @SerializedName("errors"       ) var errors      : ArrayList<String> = arrayListOf(),
    @SerializedName("verify"       ) var verify      : Verify?           = Verify()
)
