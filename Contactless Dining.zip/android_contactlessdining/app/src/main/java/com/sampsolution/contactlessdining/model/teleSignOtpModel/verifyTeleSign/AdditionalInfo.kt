package com.sampsolution.contactlessdining.model.teleSignOtpModel.verifyTeleSign

import com.google.gson.annotations.SerializedName

data class AdditionalInfo(
    @SerializedName("message_parts_count"          ) var messagePartsCount         : Int?    = null,
    @SerializedName("message_parts_reference_ids"  ) var messagePartsReferenceIds  : String? = null,
    @SerializedName("message_part_sequence_number" ) var messagePartSequenceNumber : Int?    = null
)
