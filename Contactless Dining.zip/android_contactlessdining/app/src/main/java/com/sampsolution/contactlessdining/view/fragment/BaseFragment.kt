package com.sampsolution.contactlessdining.view.fragment

import androidx.fragment.app.Fragment
import com.sampsolution.contactlessdining.service.DigitalServiceRepository

abstract class BaseFragment : Fragment() {

    internal var contactlessService = DigitalServiceRepository.getInstance()

}