package com.sampsolution.contactlessdining.view.adapter

import android.content.Context
import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.sampsolution.contactlessdining.databinding.ItemRestaurantTypeBinding

data class ResTypeHomeAdapter(
    var context: Context,
    val list: ArrayList<String>,
) :
    RecyclerView.Adapter<ResTypeHomeAdapter.TextModelViewHolder>() {

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): TextModelViewHolder {
        return TextModelViewHolder(
            ItemRestaurantTypeBinding.inflate(
                LayoutInflater.from(
                    context
                )
            )
        )
    }

    override fun onBindViewHolder(holder: TextModelViewHolder, position: Int) {
        try {
            holder.binding.tvName1.text = list[position]

        } catch (e: Exception) {
            e.printStackTrace()
        }
    }

    override fun getItemCount(): Int {
        return list.size
    }

    data class TextModelViewHolder(val binding: ItemRestaurantTypeBinding) :
        RecyclerView.ViewHolder(binding.root)


}

