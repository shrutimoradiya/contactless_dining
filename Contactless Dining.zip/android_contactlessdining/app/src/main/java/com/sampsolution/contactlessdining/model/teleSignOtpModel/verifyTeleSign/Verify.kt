package com.sampsolution.contactlessdining.model.teleSignOtpModel.verifyTeleSign

import com.google.gson.annotations.SerializedName

data class Verify(
    @SerializedName("code_state"   ) var codeState   : String? = null,
    @SerializedName("code_entered" ) var codeEntered : String? = null
)
