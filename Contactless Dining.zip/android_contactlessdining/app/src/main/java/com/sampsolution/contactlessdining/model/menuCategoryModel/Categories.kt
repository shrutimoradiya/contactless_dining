package com.sampsolution.contactlessdining.model.menuCategoryModel

import com.google.gson.annotations.SerializedName

data class Categories(
    @SerializedName("id"            ) var id           : Int?    = null,
    @SerializedName("category_name" ) var categoryName : String? = null,
    var    isSelected         : Boolean = false,

    )
