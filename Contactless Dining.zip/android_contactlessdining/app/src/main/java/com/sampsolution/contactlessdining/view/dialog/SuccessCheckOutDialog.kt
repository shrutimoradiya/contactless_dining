package com.sampsolution.contactlessdining.view.dialog

import android.content.Intent
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.WindowManager
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.WindowInsetsControllerCompat
import com.google.android.material.bottomsheet.BottomSheetBehavior
import com.google.android.material.bottomsheet.BottomSheetDialog
import com.sampsolution.contactlessdining.databinding.DialogSuccessCheckOutBinding
import com.sampsolution.contactlessdining.utils.Constant
import com.sampsolution.contactlessdining.utils.SharedPref
import com.sampsolution.contactlessdining.view.activity.MainActivity
import com.sampsolution.contactlessdining.view.activity.MyOrderDetailsActivity

data class SuccessCheckOutDialog(
    val context: AppCompatActivity,
    val orderNumber: String?,
) : BottomSheetDialog(context) {
    private var dialogbinding: DialogSuccessCheckOutBinding? = null
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        dialogbinding = DialogSuccessCheckOutBinding.inflate(LayoutInflater.from(context))

        dialogbinding?.let { binding ->
            setContentView(binding.root)

            hideSystemUI()

            binding.tvOrderNumber.text = "Order #${orderNumber}"

            binding.btnDone.setOnClickListener {
                dismiss()
                val intent = Intent(context, MyOrderDetailsActivity::class.java)
                intent.putExtra("Order id", orderNumber)
                intent.putExtra("key", "cart")
                context.startActivity(intent)
            }


        }

        setCanceledOnTouchOutside(true)
        val layoutParams = WindowManager.LayoutParams()
        layoutParams.copyFrom(window?.attributes)
        layoutParams.width = WindowManager.LayoutParams.MATCH_PARENT
        layoutParams.height = WindowManager.LayoutParams.WRAP_CONTENT
        behavior.state = BottomSheetBehavior.STATE_EXPANDED
        window?.attributes = layoutParams
//        window?.setBackgroundDrawable(ColorDrawable(android.graphics.Color.TRANSPARENT))
        (dialogbinding!!.root.parent as View).setBackgroundColor(
            context.resources.getColor(android.R.color.transparent)
        )
    }

//


    private fun hideSystemUI() {
        window?.let { WindowCompat.setDecorFitsSystemWindows(it, false) }
        window?.let {
            WindowInsetsControllerCompat(
                it,
                window!!.decorView.findViewById(android.R.id.content)
            ).let { controller ->
                controller.hide(WindowInsetsCompat.Type.systemBars())

                controller.systemBarsBehavior =
                    WindowInsetsControllerCompat.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
            }
        }
    }
}

