package com.sampsolution.contactlessdining.view.activity

import android.content.Context
import android.content.Intent
import android.content.res.Configuration
import android.graphics.Color
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.View
import android.view.animation.Animation
import android.view.animation.AnimationUtils
import com.sampsolution.contactlessdining.R
import com.sampsolution.contactlessdining.databinding.ActivityOrderDetailsBinding
import com.sampsolution.contactlessdining.utils.LocaleManager
import com.sampsolution.contactlessdining.view.adapter.OrderDetailsAdapter

class OrderDetailsActivity : BaseActivity() {

    private val binding: ActivityOrderDetailsBinding by lazy {
        ActivityOrderDetailsBinding.inflate(
            layoutInflater
        )
    }
    private var orderId = ""

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(binding.root)
        orderId = intent.getStringExtra("Order id").toString()

        binding.ivBack.setOnClickListener {
            val intent = Intent(this, HomeActivity::class.java)
            startActivity(intent)
        }

        binding.txt1.text = orderId

        apiCall()

        Looper.myLooper()?.let { looper ->
            Handler(looper).postDelayed({
                val slideUp: Animation = AnimationUtils.loadAnimation(this, R.anim.slide_up)
                binding.relNotification.visibility = View.GONE
                binding.relNotification.startAnimation(slideUp)
            }, 5000)
        }

        val slideDown: Animation = AnimationUtils.loadAnimation(this, R.anim.slide_down)
        binding.relNotification.visibility = View.VISIBLE
        binding.relNotification.startAnimation(slideDown)

    }

    private fun apiCall() {
//        val dialog = ProgressDialog(this)
//        dialog.show()

        contactlessService?.orderDetailApi(orderId)?.observeForever {
//            dialog.dismiss()
            it?.let { it1 ->
                binding.rvListBar.adapter =
                    it1.data?.let { it2 -> OrderDetailsAdapter(this, it2.items) }
                binding.rvListBar.isNestedScrollingEnabled = false


                if (it1.data?.orderInstructions != null && it1.data?.orderInstructions != "") {
                    binding.rel2.visibility = View.VISIBLE
                    binding.tvInstruction.text = it1.data?.orderInstructions
                } else {
                    binding.rel2.visibility = View.GONE
                }

                binding.tvItemTotal.text = "$${it1.data?.totalAmount}"
                binding.tvDiscount.text = "$${it1.data?.totalDiscount}"
                binding.tvVariationTotal.text = "$${it1.data?.variations}"
                binding.tvSubTotal.text = "$${it1.data?.subTotal}"
                binding.tvTaxes.text = "$${it1.data?.taxes}"
                binding.tvTotal.text = "$${it1.data?.totalAmount}"
                binding.tvName.text =
                    "${it1.data?.restaurantName} | ${it1.data?.restaurantAddress} | ${it1.data?.time}"

            }
        }
    }


    private var localeManager: LocaleManager? = null

    override fun attachBaseContext(newBase: Context?) {
        localeManager = LocaleManager(newBase)
        super.attachBaseContext(localeManager!!.setLocale(newBase))
    }

    override fun onConfigurationChanged(newConfig: Configuration) {
        super.onConfigurationChanged(newConfig)
        localeManager!!.setLocale(this)
    }

}