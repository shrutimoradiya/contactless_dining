package com.sampsolution.contactlessdining.view.activity

import android.content.Context
import android.content.Intent
import android.content.res.Configuration
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.View
import androidx.appcompat.app.AppCompatActivity
import androidx.appcompat.app.AppCompatDelegate
import com.sampsolution.contactlessdining.R
import com.sampsolution.contactlessdining.utils.Constant
import com.sampsolution.contactlessdining.utils.LocaleManager
import com.sampsolution.contactlessdining.utils.SharedPref

class SplashActivity : BaseActivity() {


    override fun onCreate(savedInstanceState: Bundle?) {

        if (Constant.getData(this, Constant.dark) == "yes") {
            AppCompatDelegate.setDefaultNightMode(AppCompatDelegate.MODE_NIGHT_YES)
        } else {
            AppCompatDelegate.setDefaultNightMode(AppCompatDelegate.MODE_NIGHT_NO)
        }

        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_splash)

        Looper.myLooper()?.let { looper ->
            Handler(looper).postDelayed({
                if (SharedPref(this).isLogin) {
                    finishAffinity()
                    startActivity(Intent(this@SplashActivity, HomeActivity::class.java))
                } else {
                    finishAffinity()
                    startActivity(Intent(this@SplashActivity, MainActivity::class.java))
                }
            }, 1000)
        }

    }

    private var localeManager: LocaleManager? = null

    override fun attachBaseContext(newBase: Context?) {
        localeManager = LocaleManager(newBase)
        super.attachBaseContext(localeManager!!.setLocale(newBase))
    }

    override fun onConfigurationChanged(newConfig: Configuration) {
        super.onConfigurationChanged(newConfig)
        localeManager!!.setLocale(this)
    }

}