package com.sampsolution.contactlessdining.view.activity

import android.app.ProgressDialog
import android.content.Context
import android.content.Intent
import android.content.res.Configuration
import android.net.Uri
import android.os.Bundle
import android.widget.Toast
import androidx.appcompat.widget.AppCompatEditText
import com.budiyev.android.codescanner.CodeScanner
import com.sampsolution.contactlessdining.R
import com.sampsolution.contactlessdining.databinding.ActivityQrscannerBinding
import com.sampsolution.contactlessdining.utils.Constant
import com.sampsolution.contactlessdining.utils.LocaleManager
import com.sampsolution.contactlessdining.view.dialog.VerifyScanDialog

class QRScannerActivity : BaseActivity() {

    private val binding: ActivityQrscannerBinding by lazy {
        ActivityQrscannerBinding.inflate(
            layoutInflater
        )
    }
    private var mCodeScanner: CodeScanner? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(binding.root)

        mCodeScanner = CodeScanner(this, binding.scannerView)
        mCodeScanner!!.setDecodeCallback { result ->
            runOnUiThread {
                val uri = Uri.parse(result.text)
                val qrCode: String? = uri.getQueryParameter("qr_code")
                Constant.saveData(this, Constant.QRCODE, qrCode)
                val intent = Intent(this@QRScannerActivity, HomeActivity::class.java)
                intent.putExtra("QRCODE", qrCode)
                startActivity(intent)
                finish()
            }
        }
        binding.scannerView.setOnClickListener { mCodeScanner!!.startPreview() }

        binding.ivBack.setOnClickListener { onBackPressed() }

        binding.txt3.setOnClickListener {
            VerifyScanDialog(
                this,
                object :
                    VerifyScanDialog.OnOptionSelected {
                    override fun onItemClick(edtNo: AppCompatEditText) {

                        if (edtNo.length() != 0) {
                            menuData(edtNo.text.toString())
                        } else {
                            Toast.makeText(
                                this@QRScannerActivity,
                                getText(R.string.enter_qr_id),
                                Toast.LENGTH_SHORT
                            ).show()
                        }
                    }
                }
            ).show()

        }

    }

    private fun menuData(qrCode: String) {
        val dialog = ProgressDialog(this)
        dialog.show()

        contactlessService?.menuCategoryApi(qrCode)?.observeForever {
            dialog.dismiss()
            it?.let { it1 ->
                if (it1.success == true) {
                    Constant.saveData(
                        this@QRScannerActivity,
                        Constant.QRCODE,
                        qrCode
                    )
                    val intent =
                        Intent(this@QRScannerActivity, HomeActivity::class.java)
                    intent.putExtra("QRCODE", qrCode)
                    startActivity(intent)
                    finish()
                } else {
                    Constant.saveData(this, Constant.QRCODE, null)
                    val intent =
                        Intent(this@QRScannerActivity, HomeActivity::class.java)
                    startActivity(intent)
                    finish()

//                    Toast.makeText(this, it1.message, Toast.LENGTH_SHORT).show()
                }
            }
        }

    }

    private var localeManager: LocaleManager? = null

    override fun attachBaseContext(newBase: Context?) {
        localeManager = LocaleManager(newBase)
        super.attachBaseContext(localeManager!!.setLocale(newBase))
    }

    override fun onConfigurationChanged(newConfig: Configuration) {
        super.onConfigurationChanged(newConfig)
        localeManager!!.setLocale(this)
    }

    override fun onResume() {
        super.onResume()
        mCodeScanner?.startPreview()
    }

    override fun onPause() {
        mCodeScanner?.releaseResources()
        super.onPause()
    }
}