package com.sampsolution.contactlessdining.model.twilioOtpModel.sendOtpModel

import com.google.gson.annotations.SerializedName


data class SendOtpResponse (

    @SerializedName("status"             ) var status           : String?                     = null,
    @SerializedName("payee"              ) var payee            : String?                     = null,
    @SerializedName("date_updated"       ) var dateUpdated      : String?                     = null,
    @SerializedName("send_code_attempts" ) var sendCodeAttempts : ArrayList<SendCodeAttempts> = arrayListOf(),
    @SerializedName("account_sid"        ) var accountSid       : String?                     = null,
    @SerializedName("to"                 ) var to               : String?                     = null,
    @SerializedName("amount"             ) var amount           : String?                     = null,
    @SerializedName("valid"              ) var valid            : Boolean?                    = null,
    @SerializedName("lookup"             ) var lookup           : Lookup?                     = Lookup(),
    @SerializedName("url"                ) var url              : String?                     = null,
    @SerializedName("sid"                ) var sid              : String?                     = null,
    @SerializedName("date_created"       ) var dateCreated      : String?                     = null,
    @SerializedName("service_sid"        ) var serviceSid       : String?                     = null,
    @SerializedName("channel"            ) var channel          : String?                     = null

)