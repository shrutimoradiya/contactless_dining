package com.sampsolution.contactlessdining.view.activity

import android.content.Context
import android.content.Intent
import android.content.res.Configuration
import android.net.Uri
import android.os.Bundle
import androidx.appcompat.app.AppCompatDelegate
import com.sampsolution.contactlessdining.BuildConfig
import com.sampsolution.contactlessdining.R
import com.sampsolution.contactlessdining.databinding.ActivityMenuBinding
import com.sampsolution.contactlessdining.utils.Constant
import com.sampsolution.contactlessdining.utils.LocaleManager
import com.sampsolution.contactlessdining.view.dialog.LogOutDialog

class MenuActivity : BaseActivity() {

    private val binding: ActivityMenuBinding by lazy {
        ActivityMenuBinding.inflate(
            layoutInflater
        )
    }
    private var language: String? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(binding.root)

        val locale = LocaleManager.getLocale(resources)
        language = locale.language

        if (language == LocaleManager.LANGUAGE_ENGLISH) {
            binding.tvLan.text = getString(R.string.english)
        }
        if (language == LocaleManager.LANGUAGE_RUSSIAN) {
            binding.tvLan.text = getString(R.string.russian)
        }
        if (language == LocaleManager.LANGUAGE_FRENCH) {
            binding.tvLan.text = getString(R.string.french)
        }
        if (language == LocaleManager.LANGUAGE_GERMAN) {
            binding.tvLan.text = getString(R.string.german)
        }
        if (language == LocaleManager.LANGUAGE_SPANISH) {
            binding.tvLan.text = getString(R.string.spanish)
        }
        if (language == LocaleManager.LANGUAGE_Chinese) {
            binding.tvLan.text = getString(R.string.chinese)
        }
        if (language == LocaleManager.LANGUAGE_ARABIC) {
            binding.tvLan.text = getString(R.string.arabic)
        }
        if (language == LocaleManager.LANGUAGE_CHINESE_TRADITIONAL) {
            binding.tvLan.text = getString(R.string.chines_traditional)
        }
        if (language == LocaleManager.LANGUAGE_HINDI) {
            binding.tvLan.text = getString(R.string.hindi)
        }
        if (language == LocaleManager.LANGUAGE_Italian) {
            binding.tvLan.text = getString(R.string.italian)
        }
        if (language == LocaleManager.LANGUAGE_Dutch) {
            binding.tvLan.text = getString(R.string.dutch)
        }
        if (language == LocaleManager.LANGUAGE_Turkish) {
            binding.tvLan.text = getString(R.string.turkish)
        }
        if (language == LocaleManager.LANGUAGE_GREEK) {
            binding.tvLan.text = getString(R.string.greek)
        }
        if (language == LocaleManager.LANGUAGE_PORTUGUESE) {
            binding.tvLan.text = getString(R.string.portuguese)
        }
        if (language == LocaleManager.LANGUAGE_JAPANESE) {
            binding.tvLan.text = getString(R.string.japanese)
        }
        if (language == LocaleManager.LANGUAGE_DANISH) {
            binding.tvLan.text = getString(R.string.danish)
        }
        if (language == LocaleManager.LANGUAGE_KOREAN) {
            binding.tvLan.text = getString(R.string.korean)
        }
        if (language == LocaleManager.LANGUAGE_SWEDISH) {
            binding.tvLan.text = getString(R.string.swedish)
        }
        if (language == LocaleManager.LANGUAGE_MALAY) {
            binding.tvLan.text = getString(R.string.malay)
        }
        if (language == LocaleManager.LANGUAGE_INDONESIAN) {
            binding.tvLan.text = getString(R.string.indonesian)
        }
        if (language == LocaleManager.LANGUAGE_POLISH) {
            binding.tvLan.text = getString(R.string.polish)
        }
        if (language == LocaleManager.LANGUAGE_VIETNAMESE) {
            binding.tvLan.text = getString(R.string.vietnamese)
        }
        if (language == LocaleManager.LANGUAGE_PERSIAN) {
            binding.tvLan.text = getString(R.string.persian)
        }
        if (language == LocaleManager.LANGUAGE_SERBIAN) {
            binding.tvLan.text = getString(R.string.serbian)
        }
        if (language == LocaleManager.LANGUAGE_UKRAINIAN) {
            binding.tvLan.text = getString(R.string.ukrainian)
        }
        if (language == LocaleManager.LANGUAGE_THAI) {
            binding.tvLan.text = getString(R.string.thai)
        }
        if (language == LocaleManager.LANGUAGE_HEBREW) {
            binding.tvLan.text = getString(R.string.hebrew)
        }
        if (language == LocaleManager.LANGUAGE_KURDISH) {
            binding.tvLan.text = getString(R.string.kurdish)
        }
        if (language == LocaleManager.LANGUAGE_KHMER) {
            binding.tvLan.text = getString(R.string.khmer)
        }
        if (language == LocaleManager.LANGUAGE_CZECH) {
            binding.tvLan.text = getString(R.string.czech)
        }
        if (language == LocaleManager.LANGUAGE_SLOVAK) {
            binding.tvLan.text = getString(R.string.slovak)
        }
        if (language == LocaleManager.LANGUAGE_LAO) {
            binding.tvLan.text = getString(R.string.lao)
        }
        if (language == LocaleManager.LANGUAGE_BOSNIAN) {
            binding.tvLan.text = getString(R.string.bosnian)
        }
        if (language == LocaleManager.LANGUAGE_BURMESE) {
            binding.tvLan.text = getString(R.string.burmese)
        }
        if (language == LocaleManager.LANGUAGE_ALBANIAN) {
            binding.tvLan.text = getString(R.string.albanian)
        }
        if (language == LocaleManager.LANGUAGE_SWAHILI) {
            binding.tvLan.text = getString(R.string.swahili)
        }
        if (language == LocaleManager.LANGUAGE_KAZAKH) {
            binding.tvLan.text = getString(R.string.kazakh)
        }
        if (language == LocaleManager.LANGUAGE_AZERBAIJANI) {
            binding.tvLan.text = getString(R.string.azerbaijani)
        }
        if (language == LocaleManager.LANGUAGE_TIGRINYA) {
            binding.tvLan.text = getString(R.string.tigrinya)
        }
        if (language == LocaleManager.LANGUAGE_URDU) {
            binding.tvLan.text = getString(R.string.urdu)
        }
        if (language == LocaleManager.LANGUAGE_KANNADA) {
            binding.tvLan.text = getString(R.string.kannada)
        }
        if (language == LocaleManager.LANGUAGE_PORTUGUESE_BR) {
            binding.tvLan.text = getString(R.string.portuguese_br)
        }
        if (language == LocaleManager.LANGUAGE_HUNGARIAN) {
            binding.tvLan.text = getString(R.string.hungarian)
        }
        if (language == LocaleManager.LANGUAGE_TAMIL) {
            binding.tvLan.text = getString(R.string.tamil)
        }
        if (language == LocaleManager.LANGUAGE_ROMANIAN) {
            binding.tvLan.text = getString(R.string.romanian)
        }

        binding.ivBack.setOnClickListener {
            onBackPressed()
        }

        val versionName: String = BuildConfig.VERSION_NAME
        binding.tvVersion.text = "Version : ${versionName}"
//        binding.tvVersion.text="Version : ${BuildConfig.VERSION} - ${BuildConfig.VERSION_NAME}"

        if (Constant.getData(this, Constant.dark).equals("yes")) {
            binding.ivDarkModeSwitch.setImageResource(R.drawable.switch_on)
        } else {
            binding.ivDarkModeSwitch.setImageResource(R.drawable.switch_off)
        }

        binding.relDarkMode.setOnClickListener {
            if (Constant.getData(this, Constant.dark).equals("no")) {
                Constant.saveData(this, Constant.dark, "yes")
                binding.ivDarkModeSwitch.setImageResource(R.drawable.switch_on)
                AppCompatDelegate.setDefaultNightMode(AppCompatDelegate.MODE_NIGHT_YES)
                val i = Intent(this, HomeActivity::class.java)
                startActivity(i.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TASK or Intent.FLAG_ACTIVITY_NEW_TASK))
            } else {
                Constant.saveData(this, Constant.dark, "no")
                binding.ivDarkModeSwitch.setImageResource(R.drawable.switch_off)
                AppCompatDelegate.setDefaultNightMode(AppCompatDelegate.MODE_NIGHT_NO)
                val i = Intent(this, HomeActivity::class.java)
                startActivity(i.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TASK or Intent.FLAG_ACTIVITY_NEW_TASK))
            }
        }

        binding.relProfile.setOnClickListener {
            startActivity(Intent(this, ProfileActivity::class.java))
        }

        binding.relContact.setOnClickListener {
            startActivity(Intent(this, ContactUSActivity::class.java))
        }

        binding.relTerms.setOnClickListener {
            startActivity(Intent(this, TermsConditionsActivity::class.java))
        }

        binding.relPrivacy.setOnClickListener {
            val url = "https://sites.google.com/view/myappprivacypolicy123/home"
            val i = Intent(Intent.ACTION_VIEW)
            i.setData(Uri.parse(url))
            startActivity(i)
        }

        binding.relLogOut.setOnClickListener {
            LogOutDialog(this).show()
        }

        binding.relLanguages.setOnClickListener {
            startActivity(Intent(this, LanguageActivity::class.java))
        }

    }

    private var localeManager: LocaleManager? = null

    override fun attachBaseContext(newBase: Context?) {
        localeManager = LocaleManager(newBase)
        super.attachBaseContext(localeManager!!.setLocale(newBase))
    }

    override fun onConfigurationChanged(newConfig: Configuration) {
        super.onConfigurationChanged(newConfig)
        localeManager!!.setLocale(this)
    }

}