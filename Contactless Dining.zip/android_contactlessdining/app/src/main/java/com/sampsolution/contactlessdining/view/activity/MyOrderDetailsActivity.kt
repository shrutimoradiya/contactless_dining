package com.sampsolution.contactlessdining.view.activity

import android.content.Context
import android.content.Intent
import android.content.res.Configuration
import android.graphics.Color
import android.os.Bundle
import android.view.View
import com.sampsolution.contactlessdining.R
import com.sampsolution.contactlessdining.databinding.ActivityMyOrderDetailsBinding
import com.sampsolution.contactlessdining.utils.LocaleManager
import com.sampsolution.contactlessdining.view.adapter.OrderDetailsAdapter

class MyOrderDetailsActivity : BaseActivity() {

    private val binding: ActivityMyOrderDetailsBinding by lazy {
        ActivityMyOrderDetailsBinding.inflate(
            layoutInflater
        )
    }
    private var orderId = ""
    private var key = ""
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(binding.root)
        orderId = intent.getStringExtra("Order id").toString()
        key = intent.getStringExtra("key").toString()

        binding.ivBack.setOnClickListener {
            finish()
            val intent = Intent(this, HomeActivity::class.java)
            intent.putExtra("key", key)
            startActivity(intent)
        }

        binding.txt.text = "Order #${orderId}"

        apiCall()

    }

    private fun apiCall() {
//        val dialog = ProgressDialog(this)
//        dialog.show()

        contactlessService?.orderDetailApi(orderId)?.observeForever {
//            dialog.dismiss()
            it?.let { it1 ->
                binding.rvListBar.adapter =
                    it1.data?.let { it2 -> OrderDetailsAdapter(this, it2.items) }
                binding.rvListBar.isNestedScrollingEnabled = false

                if (it1.data?.orderInstructions != null && it1.data?.orderInstructions != "") {
                    binding.rel2.visibility = View.VISIBLE
                    binding.tvInstruction.text = it1.data?.orderInstructions
                } else {
                    binding.rel2.visibility = View.GONE
                }

                binding.tvItemTotal.text = "$${it1.data?.itemTotal}"
                binding.tvDiscount.text = "$${it1.data?.totalDiscount}"
                binding.tvVariationTotal.text = "$${it1.data?.variations}"
                binding.tvSubTotal.text = "$${it1.data?.subTotal}"
                binding.tvTaxes.text = "$${it1.data?.taxes}"
                binding.tvTotal.text = "$${it1.data?.totalAmount}"
                binding.tvName.text =
                    "${it1.data?.restaurantName} | ${it1.data?.restaurantAddress} | ${it1.data?.time}"

                binding.tvPaymentType.text = "Payment made via ${it1.data?.gatewayName}"
                binding.tvDate.text = it1.data?.paymentTime
                binding.tvOrderStatus.text = it1.data?.orderStatus


                if (it1.data?.orderStatus == "Pending") {
                    binding.tvOrderStatus.setTextColor(getColor(R.color.txt_pending))
                }
                if (it1.data?.orderStatus == "Processing") {
                    binding.tvOrderStatus.setTextColor(getColor(R.color.orange))
                }
                if (it1.data?.orderStatus == "Completed") {
                    binding.tvOrderStatus.setTextColor(getColor(R.color.green_main))
                }

                if (it1.data?.gatewayName == "COD") {
                    binding.tvReferenceId.visibility = View.GONE
                } else {
                    binding.tvReferenceId.visibility = View.VISIBLE
                }
                binding.tvReferenceId.text = "Transaction ID ${it1.data?.transactionId}"

                if (it1.data?.paymentStatus == 1) {
                    binding.tvStatusType.setTextColor(getColor(R.color.green_main))
                    binding.tvStatusType.text = "PAID"
                } else if (it1.data?.paymentStatus == 0) {
                    binding.tvStatusType.setTextColor(getColor(R.color.txt_pending))
                    binding.tvStatusType.text = "UNPAID"
                }

            }
        }
    }


    private var localeManager: LocaleManager? = null

    override fun attachBaseContext(newBase: Context?) {
        localeManager = LocaleManager(newBase)
        super.attachBaseContext(localeManager!!.setLocale(newBase))
    }

    override fun onConfigurationChanged(newConfig: Configuration) {
        super.onConfigurationChanged(newConfig)
        localeManager!!.setLocale(this)
    }

}