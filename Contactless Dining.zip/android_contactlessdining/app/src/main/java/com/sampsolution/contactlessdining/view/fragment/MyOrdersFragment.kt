package com.sampsolution.contactlessdining.view.fragment

import android.content.Intent
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import com.sampsolution.contactlessdining.R
import com.sampsolution.contactlessdining.databinding.FragmentMyOrdersBinding
import com.sampsolution.contactlessdining.utils.Constant
import com.sampsolution.contactlessdining.view.activity.MenuActivity
import com.sampsolution.contactlessdining.view.activity.QRScannerActivity
import com.sampsolution.contactlessdining.view.adapter.MyOrdersAdapter

open class MyOrdersFragment : BaseFragment() {

    private var binding: FragmentMyOrdersBinding? = null

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        binding = FragmentMyOrdersBinding.inflate(inflater, container, false)

        binding?.let { binding ->
            binding.ivMenu.setOnClickListener {
                startActivity(Intent(requireActivity(), MenuActivity::class.java))
            }

            binding.ivScanner.setOnClickListener {
                startActivity(Intent(requireActivity(), QRScannerActivity::class.java))
            }

            binding.tvAll.setOnClickListener {
                conformation("all")
                colorDefalt()
                binding.txtName.text = getString(R.string.all)
                binding.tvAll.setBackgroundResource(R.drawable.shape_btn_10dp)
                context?.let { it1 -> binding.tvAll.setTextColor(it1.getColor(R.color.white_common)) }
            }

            binding.tvPending.setOnClickListener {
                conformation("pending")
                colorDefalt()
                binding.txtName.text = getString(R.string.pending)
                binding.tvPending.setBackgroundResource(R.drawable.shape_btn_10dp)
                context?.let { it1 -> binding.tvPending.setTextColor(it1.getColor(R.color.white_common)) }
            }

            binding.tvProcessing.setOnClickListener {
                conformation("processing")
                colorDefalt()
                binding.txtName.text = getString(R.string.processing)
                binding.tvProcessing.setBackgroundResource(R.drawable.shape_btn_10dp)
                context?.let { it1 -> binding.tvProcessing.setTextColor(it1.getColor(R.color.white_common)) }
            }

            binding.tvCompleted.setOnClickListener {
                conformation("completed")
                colorDefalt()
                binding.txtName.text = getString(R.string.completed)
                binding.tvCompleted.setBackgroundResource(R.drawable.shape_btn_10dp)
                context?.let { it1 -> binding.tvCompleted.setTextColor(it1.getColor(R.color.white_common)) }
            }

            binding.tvAll.performClick()
        }

        return binding?.root
    }

    private fun colorDefalt() {
        binding?.let { binding ->
            binding.tvAll.setBackgroundResource(R.drawable.shape_border_category)
            binding.tvPending.setBackgroundResource(R.drawable.shape_border_category)
            binding.tvProcessing.setBackgroundResource(R.drawable.shape_border_category)
            binding.tvCompleted.setBackgroundResource(R.drawable.shape_border_category)

            context?.let { it1 -> binding.tvAll.setTextColor(it1.getColor(R.color.white)) }
            context?.let { binding.tvPending.setTextColor(it.getColor(R.color.white)) }
            context?.let { binding.tvProcessing.setTextColor(it.getColor(R.color.white)) }
            context?.let { binding.tvCompleted.setTextColor(it.getColor(R.color.white)) }
        }
    }

    private fun conformation(orderStatus: String) {

        context?.let {
            Constant.getData(it, Constant.USERID)?.let {
                contactlessService?.checkStatusApi(it, orderStatus)?.observeForever {
                    it?.let { it1 ->
                        binding?.shimmerFrameLayout?.stopShimmerAnimation()
                        binding?.shimmerFrameLayout?.visibility = View.GONE
                        binding?.rvListBar?.visibility = View.VISIBLE

                        if (it1.data.size != 0) {
                            binding?.rel1?.visibility = View.VISIBLE
                            binding?.relNoData?.visibility = View.GONE
                            binding?.rvListBar?.adapter =
                                context?.let { context ->
                                    MyOrdersAdapter(context, it1.data)
                                }
                            binding?.rvListBar?.isNestedScrollingEnabled = false
                            binding?.tvCountOrder?.text = "${it1.data.size} Orders"
                        } else {
                            binding?.rel1?.visibility = View.GONE
                            binding?.relNoData?.visibility = View.VISIBLE
                        }

                    }
                }
            }
        }

    }

    override fun onResume() {
        super.onResume()
        binding?.shimmerFrameLayout?.startShimmerAnimation()
    }

    override fun onPause() {
        binding?.shimmerFrameLayout?.stopShimmerAnimation()
        super.onPause()
    }


}