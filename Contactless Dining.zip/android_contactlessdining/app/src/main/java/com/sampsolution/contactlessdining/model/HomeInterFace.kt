package com.sampsolution.contactlessdining.model

interface HomeInterFace {

    fun goneTextCount()
    fun visibleTextCount()


}