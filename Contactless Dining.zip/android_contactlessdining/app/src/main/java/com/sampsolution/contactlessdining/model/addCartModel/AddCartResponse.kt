package com.sampsolution.contactlessdining.model.addCartModel

import com.google.gson.annotations.SerializedName

data class AddCartResponse(
    @SerializedName("success"      ) var success     : Boolean? = null,
    @SerializedName("message"      ) var message     : String?  = null,
    @SerializedName("total_amount" ) var totalAmount : String?  = null,
    @SerializedName("cart_id"      ) var cartId      : String?  = null
)
