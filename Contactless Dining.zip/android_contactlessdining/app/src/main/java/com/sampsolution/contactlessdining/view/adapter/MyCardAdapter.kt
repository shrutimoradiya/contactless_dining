package com.sampsolution.contactlessdining.view.adapter

import android.content.Context
import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.sampsolution.contactlessdining.databinding.ItemMyCardBinding

data class MyCardAdapter(
    var context: Context,
) :
    RecyclerView.Adapter<MyCardAdapter.TextModelViewHolder>() {

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): TextModelViewHolder {
        return TextModelViewHolder(
            ItemMyCardBinding.inflate(
                LayoutInflater.from(
                    context
                )
            )
        )
    }

    override fun onBindViewHolder(holder: TextModelViewHolder, position: Int) {
        try {


        } catch (e: Exception) {
            e.printStackTrace()
        }
    }

    override fun getItemCount(): Int {
        return 2
    }

    data class TextModelViewHolder(val binding: ItemMyCardBinding) :
        RecyclerView.ViewHolder(binding.root)


}
