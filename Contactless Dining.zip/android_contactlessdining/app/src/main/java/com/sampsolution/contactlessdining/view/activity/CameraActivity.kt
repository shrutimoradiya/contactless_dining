package com.sampsolution.contactlessdining.view.activity

import android.Manifest
import android.app.Activity.RESULT_OK
import android.content.Intent
import android.content.pm.PackageManager
import android.database.Cursor
import android.net.Uri
import android.os.Bundle
import android.provider.MediaStore
import android.util.Log
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import androidx.core.content.FileProvider
import androidx.fragment.app.Fragment
import com.sampsolution.contactlessdining.utils.Constant
import com.sampsolution.contactlessdining.utils.PhotoData
import java.io.File
import java.io.IOException

abstract class CameraActivity : BaseActivity() {

    private var currentPhotoPath: String? = null
    var photoData: PhotoData? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        photoData = PhotoData(this)
    }

    fun dispatchTakePictureIntent() {
        val takePictureIntent = Intent(MediaStore.ACTION_IMAGE_CAPTURE)

        try {
            photoData?.photoFile = photoData?.createImageFile()
            currentPhotoPath = photoData?.photoFile?.absolutePath
        } catch (_: IOException) {
        }

        photoData?.photoFile?.let {
            val photoURI: Uri = FileProvider.getUriForFile(
                this,
                "${packageName}.fileprovider",
                it
            )
            photoData?.uri = photoURI
            takePictureIntent.putExtra(MediaStore.EXTRA_OUTPUT, photoURI)
            startActivityForResult(takePictureIntent, Constant.CAMERA_REQUEST_CODE)
        }
    }

    fun dispatchPickUpPictureIntent() {
        val pickPhoto = Intent(Intent.ACTION_PICK, MediaStore.Images.Media.EXTERNAL_CONTENT_URI)
        startActivityForResult(pickPhoto, Constant.GALLERY_REQUEST_CODE)
    }

    fun checkAndRequestPermissions(requestCode: Int = Constant.REQUEST_ID_MULTIPLE_PERMISSIONS): Boolean {
        val wExtStorePermission = ContextCompat.checkSelfPermission(
            this,
            Manifest.permission.WRITE_EXTERNAL_STORAGE
        )
        val cameraPermission = ContextCompat.checkSelfPermission(
            this,
            Manifest.permission.CAMERA
        )
        val listPermissionsNeeded: MutableList<String> = ArrayList()
        if (cameraPermission != PackageManager.PERMISSION_GRANTED) {
            listPermissionsNeeded.add(Manifest.permission.CAMERA)
        }
        if (wExtStorePermission != PackageManager.PERMISSION_GRANTED) {
            listPermissionsNeeded
                .add(Manifest.permission.WRITE_EXTERNAL_STORAGE)
        }
        if (listPermissionsNeeded.isNotEmpty()) {
            ActivityCompat.requestPermissions(
                this, listPermissionsNeeded
                    .toTypedArray(),
                requestCode
            )
            return false
        }
        return true
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == Constant.CAMERA_REQUEST_CODE) {
            if (resultCode == RESULT_OK) {
                val f = currentPhotoPath?.let { File(it) }
                val mediaScanIntent = Intent(Intent.ACTION_MEDIA_SCANNER_SCAN_FILE)
                val contentUri: Uri = Uri.fromFile(f)
                mediaScanIntent.data = contentUri
                sendBroadcast(mediaScanIntent)
                showPhotos()
            }
        }
        if (requestCode == Constant.GALLERY_REQUEST_CODE) {
            if (resultCode == RESULT_OK) {
                val selectedImage = data?.data
                val filePathColumn = arrayOf(MediaStore.Images.Media.DATA)
                if (selectedImage != null) {
                    val cursor: Cursor? = contentResolver?.query(
                        selectedImage,
                        filePathColumn,
                        null,
                        null,
                        null
                    )
                    if (cursor != null) {
                        cursor.moveToFirst()
                        val columnIndex = cursor.getColumnIndex(filePathColumn[0])
                        currentPhotoPath = cursor.getString(columnIndex)
                        photoData?.photoFile = currentPhotoPath?.let { File(it) }
                        photoData?.uri = Uri.fromFile(photoData?.photoFile)
                        cursor.close()
                        showPhotos()
                    }
                }
                Log.e("onActivityResult: ", photoData?.uri.toString())
                Log.e("tag", "onActivityResult: Gallery Image Uri:  $currentPhotoPath")
            }
        }
    }

    override fun onRequestPermissionsResult(
        requestCode: Int,
        permissions: Array<out String>,
        grantResults: IntArray
    ) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        when (requestCode) {
            Constant.REQUEST_ID_MULTIPLE_PERMISSIONS -> if (ContextCompat.checkSelfPermission(
                    this,
                    Manifest.permission.CAMERA
                ) != PackageManager.PERMISSION_GRANTED
            ) {
            } else if (ContextCompat.checkSelfPermission(
                    this,
                    Manifest.permission.WRITE_EXTERNAL_STORAGE
                ) != PackageManager.PERMISSION_GRANTED
            ) {
            } else {
            }

            Constant.REQUEST_ID_CAMERA_PERMISSIONS -> {
                if (ContextCompat.checkSelfPermission(
                        this,
                        Manifest.permission.CAMERA
                    ) != PackageManager.PERMISSION_GRANTED
                ) {
                } else {
                }
            }

            Constant.REQUEST_ID_GALLERY_PERMISSIONS -> {
                if (ContextCompat.checkSelfPermission(
                        this,
                        Manifest.permission.WRITE_EXTERNAL_STORAGE
                    ) != PackageManager.PERMISSION_GRANTED
                ) {
                } else {
                }
            }
        }
    }

    abstract fun showPhotos()
}