package com.sampsolution.contactlessdining.view.adapter

import android.content.Context
import android.content.Intent
import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.bumptech.glide.Glide
import com.sampsolution.contactlessdining.databinding.ItemHomeBinding
import com.sampsolution.contactlessdining.model.homeModel.HomeData
import com.sampsolution.contactlessdining.view.activity.QRScannerActivity

data class HomeAdapter(
    var context: Context,
    val list: ArrayList<HomeData>,
) :
    RecyclerView.Adapter<HomeAdapter.TextModelViewHolder>() {

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): TextModelViewHolder {
        return TextModelViewHolder(
            ItemHomeBinding.inflate(
                LayoutInflater.from(
                    context
                )
            )
        )
    }

    override fun onBindViewHolder(holder: TextModelViewHolder, position: Int) {
        try {

            Glide.with(context).load(list[position].branchImage).into(holder.binding.img)

            holder.binding.textRestaurantName.text = list[position].restaurantName
            holder.binding.tvAddress.text = list[position].branchShortAddress
            holder.binding.tvKm.text = "${list[position].distance} km Away"

            holder.binding.rvRestaurantType.adapter =
                ResTypeHomeAdapter(context, list[position].branchTypes)


            holder.itemView.setOnClickListener {
                val i = Intent(context, QRScannerActivity::class.java)
//                i.putExtra("restaurant_id", list[position].id)
//                i.putExtra("restaurantName", list[position].restaurantName)
                context.startActivity(i)
            }


        } catch (e: Exception) {
            e.printStackTrace()
        }
    }

    override fun getItemCount(): Int {
        return list.size
    }

    data class TextModelViewHolder(val binding: ItemHomeBinding) :
        RecyclerView.ViewHolder(binding.root)


}

