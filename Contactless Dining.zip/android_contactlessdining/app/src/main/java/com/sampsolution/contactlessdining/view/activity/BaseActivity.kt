package com.sampsolution.contactlessdining.view.activity

import android.view.View
import androidx.appcompat.app.AppCompatActivity
import com.sampsolution.contactlessdining.service.DigitalServiceRepository
import com.sampsolution.contactlessdining.service.otp2factorService.Factor2ServiceRepository
import com.sampsolution.contactlessdining.service.teleSignService.TeleSignServiceRepository
import com.sampsolution.contactlessdining.service.twilioOtpService.TwillioOtpServiceRepository

abstract class BaseActivity : AppCompatActivity() {

    internal var contactlessService = DigitalServiceRepository.getInstance()
    internal var twilioService = TwillioOtpServiceRepository.getInstance()
    internal var factor2Service = Factor2ServiceRepository.getInstance()
    internal var teleSignService = TeleSignServiceRepository.getInstance()

    override fun onWindowFocusChanged(hasFocus: Boolean) {
        super.onWindowFocusChanged(hasFocus)
        val decorView = window.decorView
        if (hasFocus) {
            decorView.systemUiVisibility = (
                    View.SYSTEM_UI_FLAG_LAYOUT_STABLE
                    or View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION
//                    or View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN
                    or View.SYSTEM_UI_FLAG_HIDE_NAVIGATION
//                    or View.SYSTEM_UI_FLAG_FULLSCREEN
                            or View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY
                    )
        }
    }

}