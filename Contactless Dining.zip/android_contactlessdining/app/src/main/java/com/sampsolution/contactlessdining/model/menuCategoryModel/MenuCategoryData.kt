package com.sampsolution.contactlessdining.model.menuCategoryModel

import com.google.gson.annotations.SerializedName

data class MenuCategoryData(
    @SerializedName("restaurant_name" ) var restaurantName : String?               = null,
    @SerializedName("restaurant_id"   ) var restaurantId   : Int?                  = null,
    @SerializedName("branch_id"       ) var branchId       : Int?                  = null,
    @SerializedName("branch_name"     ) var branchName     : String?               = null,
    @SerializedName("table_id"        ) var tableId        : Int?                  = null,
    @SerializedName("table_size"      ) var tableSize      : Int?                  = null,
    @SerializedName("qr_code"         ) var qrCode         : String?               = null,
    @SerializedName("categories"      ) var categories     : ArrayList<Categories> = arrayListOf()
)
