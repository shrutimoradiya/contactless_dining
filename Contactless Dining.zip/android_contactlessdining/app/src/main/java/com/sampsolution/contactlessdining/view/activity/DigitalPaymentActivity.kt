package com.sampsolution.contactlessdining.view.activity

import android.app.Activity
import android.app.ProgressDialog
import android.content.Intent
import android.os.Bundle
import android.util.ArrayMap
import android.util.Log
import android.view.View
import android.widget.Toast
import com.google.gson.Gson
import com.payment.paymentsdk.PaymentSdkActivity
import com.payment.paymentsdk.PaymentSdkConfigBuilder
import com.payment.paymentsdk.integrationmodels.PaymentSdkApms
import com.payment.paymentsdk.integrationmodels.PaymentSdkBillingDetails
import com.payment.paymentsdk.integrationmodels.PaymentSdkConfigurationDetails
import com.payment.paymentsdk.integrationmodels.PaymentSdkError
import com.payment.paymentsdk.integrationmodels.PaymentSdkLanguageCode
import com.payment.paymentsdk.integrationmodels.PaymentSdkShippingDetails
import com.payment.paymentsdk.integrationmodels.PaymentSdkTokenise
import com.payment.paymentsdk.integrationmodels.PaymentSdkTransactionClass
import com.payment.paymentsdk.integrationmodels.PaymentSdkTransactionDetails
import com.payment.paymentsdk.integrationmodels.PaymentSdkTransactionType
import com.payment.paymentsdk.sharedclasses.interfaces.CallbackPaymentInterface
import com.paypal.checkout.approve.OnApprove
import com.paypal.checkout.cancel.OnCancel
import com.paypal.checkout.createorder.CreateOrder
import com.paypal.checkout.createorder.CurrencyCode
import com.paypal.checkout.createorder.OrderIntent
import com.paypal.checkout.createorder.UserAction
import com.paypal.checkout.error.OnError
import com.paypal.checkout.order.Amount
import com.paypal.checkout.order.AppContext
import com.paypal.checkout.order.OrderRequest
import com.paypal.checkout.order.PurchaseUnit
import com.paypal.checkout.paymentbutton.PaymentButtonEligibilityStatus
import com.razorpay.Checkout
import com.razorpay.ExternalWalletListener
import com.razorpay.PaymentData
import com.razorpay.PaymentResultWithDataListener
import com.sampsolution.contactlessdining.databinding.ActivityDigitalPaymentBinding
import com.sampsolution.contactlessdining.model.loginModel.UserData
import com.sampsolution.contactlessdining.model.razorpayErrorModel.RazorpayErrorResponse
import com.sampsolution.contactlessdining.utils.Constant
import com.sampsolution.contactlessdining.utils.Constant.CLIENT_KEY
import com.sampsolution.contactlessdining.utils.Constant.CURRENCY
import com.sampsolution.contactlessdining.utils.Constant.MERCHANT_COUNTRY_CODE
import com.sampsolution.contactlessdining.utils.Constant.ORDER_ID
import com.sampsolution.contactlessdining.utils.Constant.PAYPAL_ENABLE
import com.sampsolution.contactlessdining.utils.Constant.PAY_TABS_ENABLE
import com.sampsolution.contactlessdining.utils.Constant.PROFILE_ID
import com.sampsolution.contactlessdining.utils.Constant.RAZORPAY_API_KEY
import com.sampsolution.contactlessdining.utils.Constant.RAZOR_ENABLE
import com.sampsolution.contactlessdining.utils.Constant.SERVER_KEY
import com.sampsolution.contactlessdining.utils.Constant.STRIPE
import com.sampsolution.contactlessdining.utils.SharedPref
import com.sampsolution.contactlessdining.view.dialog.FailedCheckOutDialog
import com.sampsolution.contactlessdining.view.dialog.SuccessCheckOutDialog
import org.json.JSONObject

class DigitalPaymentActivity : BaseActivity(), CallbackPaymentInterface,
    PaymentResultWithDataListener, ExternalWalletListener {

    private val binding: ActivityDigitalPaymentBinding by lazy {
        ActivityDigitalPaymentBinding.inflate(
            layoutInflater
        )
    }
    var isSelected = true
    private var isSelectedPaypal = true
    private var isSelectedRazor = true
    private var isSelectedTabes = true
    private var instruction: String? = null
    private var totalAmount: String? = null
    private var totalAmount1: Double = 0.0
    private var key: String = "stripe"
    private var listSize: Int? = null
    private var token: String? = null
    private var transRef: String? = null
    private var userData: UserData? = null
    private val tag = javaClass.simpleName

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(binding.root)
        SharedPref(this).userInfo?.let {
            try {
                Gson().fromJson(it, UserData::class.java)?.let { it1 ->
                    userData = it1
                }
            } catch (exp: Exception) {
            }
        }
        Checkout.preload(applicationContext)
        instruction = intent.getStringExtra("Instruction")
        totalAmount = intent.getStringExtra("totalAmount")
        val total = intent.getStringExtra("totalAmount1")
        total?.let {
            totalAmount1 = it.toDouble()
        }
        listSize = intent.getIntExtra("ListSize", 0)

        if (PAYPAL_ENABLE) {
            binding.relPaypal.visibility = View.VISIBLE
            binding.v11.visibility = View.VISIBLE
        } else {
            binding.relPaypal.visibility = View.GONE
            binding.v11.visibility = View.GONE
        }

        if (RAZOR_ENABLE) {
            binding.relRazorPay.visibility = View.VISIBLE
            binding.v12.visibility = View.VISIBLE
        } else {
            binding.relRazorPay.visibility = View.GONE
            binding.v12.visibility = View.GONE
        }

        if (PAY_TABS_ENABLE) {
            binding.relPayTabs.visibility = View.VISIBLE
            binding.v2.visibility = View.VISIBLE
        } else {
            binding.relPayTabs.visibility = View.GONE
            binding.v2.visibility = View.GONE
        }

        if (STRIPE) {
            binding.relStripe.visibility = View.VISIBLE
            binding.v1.visibility = View.VISIBLE
        } else {
            binding.relStripe.visibility = View.GONE
            binding.v1.visibility = View.GONE
        }


        binding.ivBack.setOnClickListener {
            val intent = Intent(this, HomeActivity::class.java)
            intent.putExtra("key", "cart")
            intent.putExtra("payKey", "digital")
            startActivity(intent)
        }

        binding.tvTotalPayment.text = "Pay $totalAmount"

        binding.relStripe.setOnClickListener {
            if (isSelected) {
                binding.ivStripeCheck.visibility = View.VISIBLE
                binding.ivPaytabsCheck.visibility = View.GONE
                binding.ivPaypalCheck.visibility = View.GONE
                binding.ivRazorpayCheck.visibility = View.GONE
                key = "stripe"
                isSelected = true
            } else {
                binding.ivStripeCheck.visibility = View.GONE
                binding.ivPaytabsCheck.visibility = View.GONE
                binding.ivPaypalCheck.visibility = View.GONE
                binding.ivRazorpayCheck.visibility = View.GONE
                isSelected = false
            }
        }

        binding.relPaypal.setOnClickListener {
            if (isSelectedPaypal) {
                binding.ivStripeCheck.visibility = View.GONE
                binding.ivPaytabsCheck.visibility = View.GONE
                binding.ivPaypalCheck.visibility = View.VISIBLE
                binding.ivRazorpayCheck.visibility = View.GONE
                key = "payPal"
                isSelectedPaypal = true
            } else {
                binding.ivStripeCheck.visibility = View.GONE
                binding.ivPaytabsCheck.visibility = View.GONE
                binding.ivPaypalCheck.visibility = View.GONE
                binding.ivRazorpayCheck.visibility = View.GONE
                isSelectedPaypal = false
            }
        }

        binding.relRazorPay.setOnClickListener {
            if (isSelectedRazor) {
                binding.ivStripeCheck.visibility = View.GONE
                binding.ivPaytabsCheck.visibility = View.GONE
                binding.ivPaypalCheck.visibility = View.GONE
                binding.ivRazorpayCheck.visibility = View.VISIBLE
                key = "razorPay"
                isSelectedRazor = true
            } else {
                binding.ivStripeCheck.visibility = View.GONE
                binding.ivPaytabsCheck.visibility = View.GONE
                binding.ivPaypalCheck.visibility = View.GONE
                binding.ivRazorpayCheck.visibility = View.GONE
                isSelectedRazor = false
            }
        }
        binding.relPayTabs.setOnClickListener {
            if (isSelectedTabes) {
                binding.ivStripeCheck.visibility = View.GONE
                binding.ivPaytabsCheck.visibility = View.VISIBLE
                binding.ivPaypalCheck.visibility = View.GONE
                binding.ivRazorpayCheck.visibility = View.GONE
                key = "payTabs"
                isSelectedTabes = true
            } else {
                binding.ivStripeCheck.visibility = View.GONE
                binding.ivPaytabsCheck.visibility = View.GONE
                binding.ivPaypalCheck.visibility = View.GONE
                binding.ivRazorpayCheck.visibility = View.GONE
                isSelectedTabes = false
            }
        }

        binding.btnNext.setOnClickListener {
            when (key) {
                "payTabs" -> {
                    payTabsPayment()
                }
                "razorPay" -> {
                    razorPay()
                }
                "payPal" -> {
                    binding.paymentButton.performClick()
                }
                "stripe" -> {

                }
            }
        }

        payPalPayment()

    }

    private fun payTabsPayment() {
        val configData = generatePaytabsConfigurationDetails()
        PaymentSdkActivity.startCardPayment(
            this, configData, this
        )
    }

    private fun payPalPayment() {
        binding.paymentButton.onEligibilityStatusChanged =
            { buttonEligibilityStatus: PaymentButtonEligibilityStatus ->
                Log.v(tag, "OnEligibilityStatusChanged")
                Log.d(tag, "Button eligibility status: $buttonEligibilityStatus")
            }
        setupPaymentButton()
    }

    private fun razorPay() {
        startPayment()
    }

    private fun setupPaymentButton() {
        binding.paymentButton.setup(
            createOrder = CreateOrder { createOrderActions ->
                Log.v(tag, "CreateOrder")
                createOrderActions.create(
                    OrderRequest.Builder()
                        .appContext(
                            AppContext(
                                userAction = UserAction.PAY_NOW
                            )
                        )
                        .intent(OrderIntent.CAPTURE)
                        .purchaseUnitList(
                            listOf(
                                PurchaseUnit.Builder()
                                    .amount(
                                        Amount.Builder()
                                            .value(totalAmount1.toString())
                                            .currencyCode(CurrencyCode.USD)
                                            .build()
                                    )
                                    .build()
                            )
                        )
                        .build()
                        .also { Log.d(tag, "Order: $it") }
                )
            },
            onApprove = OnApprove { approval ->
                instruction?.let {
                    approval.data.paymentId?.let { it1 ->
                        conformation(
                            it1,
                            it,
                            "Paypal"
                        )
                    }
                }
                Log.v(tag, "OnApprove")
                Log.d(tag, "Approval details: $approval")
                approval.orderActions.capture { captureOrderResult ->

                    Log.v(tag, "Capture Order")
                    Log.d(tag, "Capture order result: $captureOrderResult")
                }
            },
            onCancel = OnCancel {
                Log.v(tag, "OnCancel")
                Log.d(tag, "Buyer cancelled the checkout experience.")
            },
            onError = OnError { errorInfo ->
                Log.v(tag, "OnError")
                Log.d(tag, "Error details: $errorInfo")
            }
        )
    }

    private fun conformation(
        transaction_id: String,
        order_instructions: String,
        paymentType: String
    ) {

        val dialog = ProgressDialog(this)
        dialog.show()
        val map: ArrayMap<String?, Any?> = ArrayMap<String?, Any?>()
        map["user_id"] = Constant.getData(this, Constant.USERID)
        map["order_instructions"] = order_instructions
        map["transaction_id"] = transaction_id
        map["gateway_name"] = paymentType

        contactlessService?.checkOutApi(map)?.observeForever {
            dialog.dismiss()
            it?.let { it1 ->
                if (it1.success == true) {
                    if (listSize != 0) {
                        if (Constant.intGetData(this, Constant.ADDCARTCOUNt) != 0) {
                            Constant.intSaveData(
                                this,
                                Constant.ADDCARTCOUNt,
                                (Constant.intGetData(
                                    this,
                                    Constant.ADDCARTCOUNt
                                ) - listSize!!)
                            )
                        }


                    }
//                    Constant.saveData(this, Constant.QRCODE, null)
                    SuccessCheckOutDialog(this, it1.orderNumber).show()
                } else {
                    FailedCheckOutDialog(this, "", "").show()
                }
            }
        }

    }

    private fun startPayment() {
        val activity: Activity = this
        val co = Checkout()
        co.setKeyID(RAZORPAY_API_KEY)

        try {
            val options = JSONObject()
            options.put("name", "${userData?.firstName} ${userData?.lastName}")
            options.put("description", "Demoing Charges")
            //You can omit the image option to fetch the image from dashboard
            options.put("image", "https://s3.amazonaws.com/rzp-mobile/images/rzp.png")
            options.put("currency", "USD")
            options.put("amount", totalAmount1 * 100)
            options.put("send_sms_hash", true);

            val prefill = JSONObject()
            prefill.put("email", userData?.email)
            prefill.put("contact", userData?.mobileNumber)

            options.put("prefill", prefill)
//            }

            co.open(activity, options)
        } catch (e: java.lang.Exception) {
            FailedCheckOutDialog(this, "payment", e.message).show()
//            Toast.makeText(activity, "Error in payment: " + e.message, Toast.LENGTH_LONG).show()
            e.printStackTrace()
        }
    }

    private fun generatePaytabsConfigurationDetails(selectedApm: PaymentSdkApms? = null): PaymentSdkConfigurationDetails {
        val profileId = PROFILE_ID
        val serverKey = SERVER_KEY
        val clientKey = CLIENT_KEY
        val locale = PaymentSdkLanguageCode.EN /*Or PaymentSdkLanguageCode.AR*/
        val transactionTitle = "Test SDK"
        val orderId = ORDER_ID
        val cartDesc = "Cart description"
        val currency = CURRENCY
        val merchantCountryCode = MERCHANT_COUNTRY_CODE
        val billingData = PaymentSdkBillingDetails(
            "City",
            "IN",
            userData?.email,
            "${userData?.firstName} ${userData?.lastName}",
            "${userData?.countryCode}${userData?.mobileNumber}",
            "121321",
            "street2",
            "123456"
        )

        val shippingData = PaymentSdkShippingDetails(
            "City",
            "IN",
            userData?.email,
            "${userData?.firstName} ${userData?.lastName}",
            "${userData?.countryCode}${userData?.mobileNumber}",
            "3510",
            "street2",
            "123456"
        )
        val configData = PaymentSdkConfigBuilder(
            profileId, serverKey, clientKey, totalAmount1, currency
        ).setCartDescription(cartDesc).setLanguageCode(locale)
            .setBillingData(billingData).setMerchantCountryCode(merchantCountryCode)
            .setTransactionType(PaymentSdkTransactionType.SALE)
            .setTransactionClass(PaymentSdkTransactionClass.ECOM).setShippingData(shippingData)
            //Check other tokenizing types in PaymentSdkTokenize
            .setTokenise(PaymentSdkTokenise.MERCHANT_MANDATORY).setCartId(orderId)
            .showBillingInfo(true).showShippingInfo(false).forceShippingInfo(false)
            .setScreenTitle(transactionTitle).hideCardScanner(false).linkBillingNameWithCard(false)
        if (selectedApm != null) configData.setAlternativePaymentMethods(listOf(selectedApm))
        return configData.build()
    }


    // pay tabs
    override fun onError(error: PaymentSdkError) {
        FailedCheckOutDialog(this, "payment", error.msg).show()
//        Toast.makeText(this, "${error.msg}", Toast.LENGTH_SHORT).show()
    }

    override fun onPaymentCancel() {
        Toast.makeText(this, "onPaymentCancel", Toast.LENGTH_SHORT).show()
    }

    override fun onPaymentFinish(paymentSdkTransactionDetails: PaymentSdkTransactionDetails) {
        Log.d("TAG", "Did payment success?: ${paymentSdkTransactionDetails.isSuccess}")
        token = paymentSdkTransactionDetails.token
        transRef = paymentSdkTransactionDetails.transactionReference
        instruction?.let { transRef?.let { it1 -> conformation(it1, it, "Paytabs") } }
//        Toast.makeText(
//            this,
//            paymentSdkTransactionDetails.paymentResult?.responseMessage ?: "PaymentFinish",
//            Toast.LENGTH_SHORT
//        ).show()
    }



    // razorpay method
    override fun onPaymentSuccess(p0: String?, p1: PaymentData?) {
        instruction?.let { p0?.let { it1 -> conformation(it1, it, "Razorpay") } }
//        Toast.makeText(
//            this, "Payment Successful : Payment ID: $p0\n" +
//                    "Payment Data: ${p1?.data}", Toast.LENGTH_SHORT
//        ).show()
    }

    override fun onPaymentError(p0: Int, p1: String?, p2: PaymentData?) {
//       val userInfo = Gson().toJson(data)
        val gson = Gson()

        val data: RazorpayErrorResponse = gson.fromJson(p1, RazorpayErrorResponse::class.java)

//        Toast.makeText(this, "Payment Failed : Payment Data: ${p2?.data}", Toast.LENGTH_SHORT)
//            .show()
        FailedCheckOutDialog(this, "payment", data.error?.reason).show()
    }

    override fun onExternalWalletSelected(p0: String?, p1: PaymentData?) {
//        Toast.makeText(
//            this,
//            "External wallet was selected : Payment Data: ${p1?.data}",
//            Toast.LENGTH_SHORT
//        ).show()
    }


}