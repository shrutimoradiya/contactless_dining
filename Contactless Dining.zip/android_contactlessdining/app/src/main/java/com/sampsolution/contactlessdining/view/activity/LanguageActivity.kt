package com.sampsolution.contactlessdining.view.activity

import android.content.Context
import android.content.Intent
import android.content.res.Configuration
import android.os.Bundle
import com.sampsolution.contactlessdining.R
import com.sampsolution.contactlessdining.databinding.ActivityLanguageBinding
import com.sampsolution.contactlessdining.utils.LocaleManager

class LanguageActivity : BaseActivity() {

    private val binding: ActivityLanguageBinding by lazy {
        ActivityLanguageBinding.inflate(
            layoutInflater
        )
    }
    private var language: String? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(binding.root)

        val locale = LocaleManager.getLocale(resources)
        language = locale.language

        unselect()
        if (language == LocaleManager.LANGUAGE_ENGLISH) {
            binding.ivEnglish.setImageResource(R.drawable.radio_fill)
        }
        if (language == LocaleManager.LANGUAGE_RUSSIAN) {
            binding.ivRussian.setImageResource(R.drawable.radio_fill)
        }
        if (language == LocaleManager.LANGUAGE_FRENCH) {
            binding.ivFrench.setImageResource(R.drawable.radio_fill)
        }
        if (language == LocaleManager.LANGUAGE_GERMAN) {
            binding.ivGerman.setImageResource(R.drawable.radio_fill)
        }
        if (language == LocaleManager.LANGUAGE_SPANISH) {
            binding.ivSpanish.setImageResource(R.drawable.radio_fill)
        }
        if (language == LocaleManager.LANGUAGE_Chinese) {
            binding.ivChinese.setImageResource(R.drawable.radio_fill)
        }
        if (language == LocaleManager.LANGUAGE_ARABIC) {
            binding.ivArabic.setImageResource(R.drawable.radio_fill)
        }
        if (language == LocaleManager.LANGUAGE_CHINESE_TRADITIONAL) {
            binding.ivChinesTraditional.setImageResource(R.drawable.radio_fill)
        }
        if (language == LocaleManager.LANGUAGE_HINDI) {
            binding.ivHindi.setImageResource(R.drawable.radio_fill)
        }
        if (language == LocaleManager.LANGUAGE_Italian) {
            binding.ivItalian.setImageResource(R.drawable.radio_fill)
        }
        if (language == LocaleManager.LANGUAGE_Dutch) {
            binding.ivDutch.setImageResource(R.drawable.radio_fill)
        }
        if (language == LocaleManager.LANGUAGE_Turkish) {
            binding.ivTurkish.setImageResource(R.drawable.radio_fill)
        }
        if (language == LocaleManager.LANGUAGE_GREEK) {
            binding.ivGreek.setImageResource(R.drawable.radio_fill)
        }
        if (language == LocaleManager.LANGUAGE_PORTUGUESE) {
            binding.ivPortuguese.setImageResource(R.drawable.radio_fill)
        }
        if (language == LocaleManager.LANGUAGE_JAPANESE) {
            binding.ivJapanese.setImageResource(R.drawable.radio_fill)
        }
        if (language == LocaleManager.LANGUAGE_DANISH) {
            binding.ivDanish.setImageResource(R.drawable.radio_fill)
        }
        if (language == LocaleManager.LANGUAGE_SWEDISH) {
            binding.ivSwedish.setImageResource(R.drawable.radio_fill)
        }
        if (language == LocaleManager.LANGUAGE_KOREAN) {
            binding.ivKorean.setImageResource(R.drawable.radio_fill)
        }
        if (language == LocaleManager.LANGUAGE_MALAY) {
            binding.ivMalay.setImageResource(R.drawable.radio_fill)
        }
        if (language == LocaleManager.LANGUAGE_INDONESIAN) {
            binding.ivIndonesian.setImageResource(R.drawable.radio_fill)
        }
        if (language == LocaleManager.LANGUAGE_POLISH) {
            binding.ivPolish.setImageResource(R.drawable.radio_fill)
        }
        if (language == LocaleManager.LANGUAGE_VIETNAMESE) {
            binding.ivVietnamese.setImageResource(R.drawable.radio_fill)
        }
        if (language == LocaleManager.LANGUAGE_PERSIAN) {
            binding.ivPersian.setImageResource(R.drawable.radio_fill)
        }
        if (language == LocaleManager.LANGUAGE_SERBIAN) {
            binding.ivSerbian.setImageResource(R.drawable.radio_fill)
        }
        if (language == LocaleManager.LANGUAGE_UKRAINIAN) {
            binding.ivUkrainian.setImageResource(R.drawable.radio_fill)
        }
        if (language == LocaleManager.LANGUAGE_HEBREW) {
            binding.ivHebrew.setImageResource(R.drawable.radio_fill)
        }
        if (language == LocaleManager.LANGUAGE_THAI) {
            binding.ivThai.setImageResource(R.drawable.radio_fill)
        }
        if (language == LocaleManager.LANGUAGE_KURDISH) {
            binding.ivKurdish.setImageResource(R.drawable.radio_fill)
        }
        if (language == LocaleManager.LANGUAGE_CZECH) {
            binding.ivCzech.setImageResource(R.drawable.radio_fill)
        }
        if (language == LocaleManager.LANGUAGE_KHMER) {
            binding.ivKhmer.setImageResource(R.drawable.radio_fill)
        }
        if (language == LocaleManager.LANGUAGE_BOSNIAN) {
            binding.ivBosnian.setImageResource(R.drawable.radio_fill)
        }
        if (language == LocaleManager.LANGUAGE_LAO) {
            binding.ivLao.setImageResource(R.drawable.radio_fill)
        }
        if (language == LocaleManager.LANGUAGE_SLOVAK) {
            binding.ivSlovak.setImageResource(R.drawable.radio_fill)
        }
        if (language == LocaleManager.LANGUAGE_BURMESE) {
            binding.ivBurmese.setImageResource(R.drawable.radio_fill)
        }
        if (language == LocaleManager.LANGUAGE_ALBANIAN) {
            binding.ivAlbanian.setImageResource(R.drawable.radio_fill)
        }
        if (language == LocaleManager.LANGUAGE_SWAHILI) {
            binding.ivSwahili.setImageResource(R.drawable.radio_fill)
        }
        if (language == LocaleManager.LANGUAGE_AZERBAIJANI) {
            binding.ivAzerbaijani.setImageResource(R.drawable.radio_fill)
        }
        if (language == LocaleManager.LANGUAGE_TIGRINYA) {
            binding.ivTigrinya.setImageResource(R.drawable.radio_fill)
        }
        if (language == LocaleManager.LANGUAGE_KAZAKH) {
            binding.ivKazakh.setImageResource(R.drawable.radio_fill)
        }
        if (language == LocaleManager.LANGUAGE_URDU) {
            binding.ivUrdu.setImageResource(R.drawable.radio_fill)
        }
        if (language == LocaleManager.LANGUAGE_KANNADA) {
            binding.ivKannada.setImageResource(R.drawable.radio_fill)
        }
        if (language == LocaleManager.LANGUAGE_PORTUGUESE_BR) {
            binding.ivPortugueseBr.setImageResource(R.drawable.radio_fill)
        }
        if (language == LocaleManager.LANGUAGE_ROMANIAN) {
            binding.ivRomanian.setImageResource(R.drawable.radio_fill)
        }
        if (language == LocaleManager.LANGUAGE_HUNGARIAN) {
            binding.ivHungarian.setImageResource(R.drawable.radio_fill)
        }
        if (language == LocaleManager.LANGUAGE_TAMIL) {
            binding.ivTamil.setImageResource(R.drawable.radio_fill)
        }

        binding.relEnglish.setOnClickListener {
            unselect()
            binding.ivEnglish.setImageResource(R.drawable.radio_fill)
            language = LocaleManager.LANGUAGE_ENGLISH
            setNewLocale(LocaleManager.LANGUAGE_ENGLISH)
        }

        binding.relRussian.setOnClickListener {
            unselect()
            binding.ivRussian.setImageResource(R.drawable.radio_fill)
            language = LocaleManager.LANGUAGE_RUSSIAN
            setNewLocale(LocaleManager.LANGUAGE_RUSSIAN)
        }

        binding.relFrench.setOnClickListener {
            unselect()
            binding.ivFrench.setImageResource(R.drawable.radio_fill)
            language = LocaleManager.LANGUAGE_FRENCH
            setNewLocale(LocaleManager.LANGUAGE_FRENCH)
        }

        binding.relGerman.setOnClickListener {
            unselect()
            binding.ivGerman.setImageResource(R.drawable.radio_fill)
            language = LocaleManager.LANGUAGE_GERMAN
            setNewLocale(LocaleManager.LANGUAGE_GERMAN)
        }

        binding.relSpanish.setOnClickListener {
            unselect()
            binding.ivSpanish.setImageResource(R.drawable.radio_fill)
            language = LocaleManager.LANGUAGE_SPANISH
            setNewLocale(LocaleManager.LANGUAGE_SPANISH)
        }

        binding.relChinese.setOnClickListener {
            unselect()
            binding.ivChinese.setImageResource(R.drawable.radio_fill)
            language = LocaleManager.LANGUAGE_Chinese
            setNewLocale(LocaleManager.LANGUAGE_Chinese)
        }

        binding.relArabic.setOnClickListener {
            unselect()
            binding.ivArabic.setImageResource(R.drawable.radio_fill)
            language = LocaleManager.LANGUAGE_ARABIC
            setNewLocale(LocaleManager.LANGUAGE_ARABIC)
        }

        binding.relChinesTraditional.setOnClickListener {
            unselect()
            binding.ivChinesTraditional.setImageResource(R.drawable.radio_fill)
            language = LocaleManager.LANGUAGE_CHINESE_TRADITIONAL
            setNewLocale(LocaleManager.LANGUAGE_CHINESE_TRADITIONAL)
        }

        binding.relHindi.setOnClickListener {
            unselect()
            binding.ivHindi.setImageResource(R.drawable.radio_fill)
            language = LocaleManager.LANGUAGE_HINDI
            setNewLocale(LocaleManager.LANGUAGE_HINDI)
        }

        binding.relItalian.setOnClickListener {
            unselect()
            binding.ivItalian.setImageResource(R.drawable.radio_fill)
            language = LocaleManager.LANGUAGE_Italian
            setNewLocale(LocaleManager.LANGUAGE_Italian)
        }

        binding.relDutch.setOnClickListener {
            unselect()
            binding.ivDutch.setImageResource(R.drawable.radio_fill)
            language = LocaleManager.LANGUAGE_Dutch
            setNewLocale(LocaleManager.LANGUAGE_Dutch)
        }

        binding.relTurkish.setOnClickListener {
            unselect()
            binding.ivTurkish.setImageResource(R.drawable.radio_fill)
            language = LocaleManager.LANGUAGE_Turkish
            setNewLocale(LocaleManager.LANGUAGE_Turkish)
        }

        binding.relGreek.setOnClickListener {
            unselect()
            binding.ivGreek.setImageResource(R.drawable.radio_fill)
            language = LocaleManager.LANGUAGE_GREEK
            setNewLocale(LocaleManager.LANGUAGE_GREEK)
        }

        binding.relPortuguese.setOnClickListener {
            unselect()
            binding.ivPortuguese.setImageResource(R.drawable.radio_fill)
            language = LocaleManager.LANGUAGE_PORTUGUESE
            setNewLocale(LocaleManager.LANGUAGE_PORTUGUESE)
        }

        binding.relJapanese.setOnClickListener {
            unselect()
            binding.ivJapanese.setImageResource(R.drawable.radio_fill)
            language = LocaleManager.LANGUAGE_JAPANESE
            setNewLocale(LocaleManager.LANGUAGE_JAPANESE)
        }

        binding.relSwedish.setOnClickListener {
            unselect()
            binding.ivSwedish.setImageResource(R.drawable.radio_fill)
            language = LocaleManager.LANGUAGE_SWEDISH
            setNewLocale(LocaleManager.LANGUAGE_SWEDISH)
        }

        binding.relDanish.setOnClickListener {
            unselect()
            binding.ivDanish.setImageResource(R.drawable.radio_fill)
            language = LocaleManager.LANGUAGE_DANISH
            setNewLocale(LocaleManager.LANGUAGE_DANISH)
        }

        binding.relKorean.setOnClickListener {
            unselect()
            binding.ivKorean.setImageResource(R.drawable.radio_fill)
            language = LocaleManager.LANGUAGE_KOREAN
            setNewLocale(LocaleManager.LANGUAGE_KOREAN)
        }

        binding.relIndonesian.setOnClickListener {
            unselect()
            binding.ivIndonesian.setImageResource(R.drawable.radio_fill)
            language = LocaleManager.LANGUAGE_INDONESIAN
            setNewLocale(LocaleManager.LANGUAGE_INDONESIAN)
        }

        binding.relMalay.setOnClickListener {
            unselect()
            binding.ivMalay.setImageResource(R.drawable.radio_fill)
            language = LocaleManager.LANGUAGE_MALAY
            setNewLocale(LocaleManager.LANGUAGE_MALAY)
        }

        binding.relPolish.setOnClickListener {
            unselect()
            binding.ivPolish.setImageResource(R.drawable.radio_fill)
            language = LocaleManager.LANGUAGE_POLISH
            setNewLocale(LocaleManager.LANGUAGE_POLISH)
        }

        binding.relVietnamese.setOnClickListener {
            unselect()
            binding.ivVietnamese.setImageResource(R.drawable.radio_fill)
            language = LocaleManager.LANGUAGE_VIETNAMESE
            setNewLocale(LocaleManager.LANGUAGE_VIETNAMESE)
        }

        binding.relPersian.setOnClickListener {
            unselect()
            binding.ivPersian.setImageResource(R.drawable.radio_fill)
            language = LocaleManager.LANGUAGE_PERSIAN
            setNewLocale(LocaleManager.LANGUAGE_PERSIAN)
        }

        binding.relSerbian.setOnClickListener {
            unselect()
            binding.ivSerbian.setImageResource(R.drawable.radio_fill)
            language = LocaleManager.LANGUAGE_SERBIAN
            setNewLocale(LocaleManager.LANGUAGE_SERBIAN)
        }

        binding.relUkrainian.setOnClickListener {
            unselect()
            binding.ivUkrainian.setImageResource(R.drawable.radio_fill)
            language = LocaleManager.LANGUAGE_UKRAINIAN
            setNewLocale(LocaleManager.LANGUAGE_UKRAINIAN)
        }

        binding.relThai.setOnClickListener {
            unselect()
            binding.ivThai.setImageResource(R.drawable.radio_fill)
            language = LocaleManager.LANGUAGE_THAI
            setNewLocale(LocaleManager.LANGUAGE_THAI)
        }

        binding.relHebrew.setOnClickListener {
            unselect()
            binding.ivHebrew.setImageResource(R.drawable.radio_fill)
            language = LocaleManager.LANGUAGE_HEBREW
            setNewLocale(LocaleManager.LANGUAGE_HEBREW)
        }

        binding.relKurdish.setOnClickListener {
            unselect()
            binding.ivKurdish.setImageResource(R.drawable.radio_fill)
            language = LocaleManager.LANGUAGE_KURDISH
            setNewLocale(LocaleManager.LANGUAGE_KURDISH)
        }

        binding.relCzech.setOnClickListener {
            unselect()
            binding.ivCzech.setImageResource(R.drawable.radio_fill)
            language = LocaleManager.LANGUAGE_CZECH
            setNewLocale(LocaleManager.LANGUAGE_CZECH)
        }

        binding.relKhmer.setOnClickListener {
            unselect()
            binding.ivKhmer.setImageResource(R.drawable.radio_fill)
            language = LocaleManager.LANGUAGE_KHMER
            setNewLocale(LocaleManager.LANGUAGE_KHMER)
        }

        binding.relSlovak.setOnClickListener {
            unselect()
            binding.ivSlovak.setImageResource(R.drawable.radio_fill)
            language = LocaleManager.LANGUAGE_SLOVAK
            setNewLocale(LocaleManager.LANGUAGE_SLOVAK)
        }

        binding.relLao.setOnClickListener {
            unselect()
            binding.ivLao.setImageResource(R.drawable.radio_fill)
            language = LocaleManager.LANGUAGE_LAO
            setNewLocale(LocaleManager.LANGUAGE_LAO)
        }

        binding.relBosnian.setOnClickListener {
            unselect()
            binding.ivBosnian.setImageResource(R.drawable.radio_fill)
            language = LocaleManager.LANGUAGE_BOSNIAN
            setNewLocale(LocaleManager.LANGUAGE_BOSNIAN)
        }

        binding.relSwahili.setOnClickListener {
            unselect()
            binding.ivSwahili.setImageResource(R.drawable.radio_fill)
            language = LocaleManager.LANGUAGE_SWAHILI
            setNewLocale(LocaleManager.LANGUAGE_SWAHILI)
        }

        binding.relBurmese.setOnClickListener {
            unselect()
            binding.ivBurmese.setImageResource(R.drawable.radio_fill)
            language = LocaleManager.LANGUAGE_BURMESE
            setNewLocale(LocaleManager.LANGUAGE_BURMESE)
        }

        binding.relAlbanian.setOnClickListener {
            unselect()
            binding.ivAlbanian.setImageResource(R.drawable.radio_fill)
            language = LocaleManager.LANGUAGE_ALBANIAN
            setNewLocale(LocaleManager.LANGUAGE_ALBANIAN)
        }

        binding.relHungarian.setOnClickListener {
            unselect()
            binding.ivHungarian.setImageResource(R.drawable.radio_fill)
            language = LocaleManager.LANGUAGE_HUNGARIAN
            setNewLocale(LocaleManager.LANGUAGE_HUNGARIAN)
        }

        binding.relRomanian.setOnClickListener {
            unselect()
            binding.ivRomanian.setImageResource(R.drawable.radio_fill)
            language = LocaleManager.LANGUAGE_ROMANIAN
            setNewLocale(LocaleManager.LANGUAGE_ROMANIAN)
        }

        binding.relTamil.setOnClickListener {
            unselect()
            binding.ivTamil.setImageResource(R.drawable.radio_fill)
            language = LocaleManager.LANGUAGE_TAMIL
            setNewLocale(LocaleManager.LANGUAGE_TAMIL)
        }

        binding.relAzerbaijani.setOnClickListener {
            unselect()
            binding.ivAzerbaijani.setImageResource(R.drawable.radio_fill)
            language = LocaleManager.LANGUAGE_AZERBAIJANI
            setNewLocale(LocaleManager.LANGUAGE_AZERBAIJANI)
        }

        binding.relKazakh.setOnClickListener {
            unselect()
            binding.ivKazakh.setImageResource(R.drawable.radio_fill)
            language = LocaleManager.LANGUAGE_KAZAKH
            setNewLocale(LocaleManager.LANGUAGE_KAZAKH)
        }

        binding.relTigrinya.setOnClickListener {
            unselect()
            binding.ivTigrinya.setImageResource(R.drawable.radio_fill)
            language = LocaleManager.LANGUAGE_TIGRINYA
            setNewLocale(LocaleManager.LANGUAGE_TIGRINYA)
        }

        binding.relUrdu.setOnClickListener {
            unselect()
            binding.ivUrdu.setImageResource(R.drawable.radio_fill)
            language = LocaleManager.LANGUAGE_URDU
            setNewLocale(LocaleManager.LANGUAGE_URDU)
        }

        binding.relKannada.setOnClickListener {
            unselect()
            binding.ivKannada.setImageResource(R.drawable.radio_fill)
            language = LocaleManager.LANGUAGE_KANNADA
            setNewLocale(LocaleManager.LANGUAGE_KANNADA)
        }

        binding.relPortugueseBr.setOnClickListener {
            unselect()
            binding.ivPortugueseBr.setImageResource(R.drawable.radio_fill)
            language = LocaleManager.LANGUAGE_PORTUGUESE_BR
            setNewLocale(LocaleManager.LANGUAGE_PORTUGUESE_BR)
        }


        binding.ivBack.setOnClickListener { super.onBackPressed() }
    }

    private fun unselect() {
        binding.ivEnglish.setImageResource(R.drawable.radio)
        binding.ivRussian.setImageResource(R.drawable.radio)
        binding.ivFrench.setImageResource(R.drawable.radio)
        binding.ivGerman.setImageResource(R.drawable.radio)
        binding.ivSpanish.setImageResource(R.drawable.radio)
        binding.ivChinese.setImageResource(R.drawable.radio)

        binding.ivArabic.setImageResource(R.drawable.radio)
        binding.ivChinesTraditional.setImageResource(R.drawable.radio)
        binding.ivHindi.setImageResource(R.drawable.radio)
        binding.ivItalian.setImageResource(R.drawable.radio)
        binding.ivDutch.setImageResource(R.drawable.radio)
        binding.ivTurkish.setImageResource(R.drawable.radio)

        binding.ivGreek.setImageResource(R.drawable.radio)
        binding.ivPortuguese.setImageResource(R.drawable.radio)
        binding.ivJapanese.setImageResource(R.drawable.radio)
        binding.ivSwedish.setImageResource(R.drawable.radio)
        binding.ivDanish.setImageResource(R.drawable.radio)
        binding.ivKorean.setImageResource(R.drawable.radio)

        binding.ivIndonesian.setImageResource(R.drawable.radio)
        binding.ivMalay.setImageResource(R.drawable.radio)
        binding.ivPolish.setImageResource(R.drawable.radio)
        binding.ivVietnamese.setImageResource(R.drawable.radio)
        binding.ivSerbian.setImageResource(R.drawable.radio)
        binding.ivPersian.setImageResource(R.drawable.radio)

        binding.ivUkrainian.setImageResource(R.drawable.radio)
        binding.ivThai.setImageResource(R.drawable.radio)
        binding.ivHebrew.setImageResource(R.drawable.radio)
        binding.ivKurdish.setImageResource(R.drawable.radio)
        binding.ivCzech.setImageResource(R.drawable.radio)
        binding.ivKhmer.setImageResource(R.drawable.radio)

        binding.ivBosnian.setImageResource(R.drawable.radio)
        binding.ivSlovak.setImageResource(R.drawable.radio)
        binding.ivLao.setImageResource(R.drawable.radio)

        binding.ivBurmese.setImageResource(R.drawable.radio)
        binding.ivAlbanian.setImageResource(R.drawable.radio)
        binding.ivSwahili.setImageResource(R.drawable.radio)
        binding.ivAzerbaijani.setImageResource(R.drawable.radio)
        binding.ivKazakh.setImageResource(R.drawable.radio)
        binding.ivTigrinya.setImageResource(R.drawable.radio)
        binding.ivUrdu.setImageResource(R.drawable.radio)
        binding.ivPortugueseBr.setImageResource(R.drawable.radio)
        binding.ivKannada.setImageResource(R.drawable.radio)

        binding.ivHungarian.setImageResource(R.drawable.radio)
        binding.ivRomanian.setImageResource(R.drawable.radio)
        binding.ivKannada.setImageResource(R.drawable.radio)
    }

    private var localeManager: LocaleManager? = null

    private fun setNewLocale(language: String?) {
        localeManager!!.setNewLocale(this, language)
        val i = Intent(this, HomeActivity::class.java)
        startActivity(i.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TASK or Intent.FLAG_ACTIVITY_NEW_TASK))
    }

    override fun attachBaseContext(newBase: Context?) {
        localeManager = LocaleManager(newBase)
        super.attachBaseContext(localeManager!!.setLocale(newBase))
    }

    override fun onConfigurationChanged(newConfig: Configuration) {
        super.onConfigurationChanged(newConfig)
        localeManager!!.setLocale(this)
    }

}