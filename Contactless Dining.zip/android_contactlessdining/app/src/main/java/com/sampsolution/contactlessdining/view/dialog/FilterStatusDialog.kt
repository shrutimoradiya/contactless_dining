package com.sampsolution.contactlessdining.view.dialog

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.WindowManager
import androidx.appcompat.app.AppCompatActivity
import com.google.android.material.bottomsheet.BottomSheetDialog
import com.sampsolution.contactlessdining.databinding.DialogFilterBinding

data class FilterStatusDialog(
    val context: AppCompatActivity,
    val filter: String,
    val listener: OnOptionSelected
) : BottomSheetDialog(context) {
    private var dialogbinding: DialogFilterBinding? = null
    var isSelected = true

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        dialogbinding = DialogFilterBinding.inflate(LayoutInflater.from(context))

        dialogbinding?.let { binding ->
            setContentView(binding.root)


            binding.relDistanceCheck.setOnClickListener {
                if (isSelected) {
                    binding.ivDistance.visibility = View.VISIBLE

                } else {
                    binding.ivDistance.visibility = View.GONE

                }
                isSelected = !isSelected
            }

            binding.relOpenNowCheck.setOnClickListener {
                if (isSelected) {
                    binding.ivOpenNow.visibility = View.VISIBLE

                } else {
                    binding.ivOpenNow.visibility = View.GONE

                }
                isSelected = !isSelected
            }

            binding.relOffers.setOnClickListener {
                if (isSelected) {
                    binding.ivOffers.visibility = View.VISIBLE

                } else {
                    binding.ivOffers.visibility = View.GONE

                }
                isSelected = !isSelected
            }

            binding.relMusic.setOnClickListener {
                if (isSelected) {
                    binding.ivMusic.visibility = View.VISIBLE

                } else {
                    binding.ivMusic.visibility = View.GONE

                }
                isSelected = !isSelected
            }

            binding.btnSave.setOnClickListener { dismiss() }

        }

        setCanceledOnTouchOutside(true)
        val layoutParams = WindowManager.LayoutParams()
        layoutParams.copyFrom(window?.attributes)
        layoutParams.width = WindowManager.LayoutParams.MATCH_PARENT
        layoutParams.height = WindowManager.LayoutParams.WRAP_CONTENT
        window?.attributes = layoutParams
//        window?.setBackgroundDrawable(ColorDrawable(android.graphics.Color.TRANSPARENT))
        (dialogbinding!!.root.parent as View).setBackgroundColor(
            context.resources.getColor(android.R.color.transparent)
        )
    }

    interface OnOptionSelected {
        fun onItemClick(option: String)
        fun onApplyClick()
    }

}