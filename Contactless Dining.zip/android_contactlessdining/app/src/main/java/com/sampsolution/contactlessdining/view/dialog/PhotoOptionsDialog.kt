package com.sampsolution.contactlessdining.view.dialog

import android.app.Dialog
import android.graphics.Color
import android.graphics.drawable.ColorDrawable
import android.os.Bundle
import android.view.LayoutInflater
import android.view.WindowManager
import androidx.appcompat.app.AppCompatActivity
import com.sampsolution.contactlessdining.databinding.DialogPhotoOptionBinding

data class PhotoOptionsDialog(val context: AppCompatActivity, val listener: onOptionSelected?) :
    Dialog(context) {
    private var dialogbinding: DialogPhotoOptionBinding? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        dialogbinding = DialogPhotoOptionBinding.inflate(LayoutInflater.from(context))

        dialogbinding?.root?.let { setContentView(it) }
        dialogbinding?.iconClose?.setOnClickListener {
            dismiss()
        }
        dialogbinding?.btnDone?.setOnClickListener {
            dialogbinding?.let {
                if (it.gallery.isChecked) {
                    listener?.onGalleryClick()
                }

                if (it.camera.isChecked) {
                    listener?.onCameraClick()
                }
            }
            dismiss()
        }
        setCanceledOnTouchOutside(true)
        val layoutParams = WindowManager.LayoutParams()
        layoutParams.copyFrom(window?.attributes)
        layoutParams.width = WindowManager.LayoutParams.MATCH_PARENT
        layoutParams.height = WindowManager.LayoutParams.WRAP_CONTENT
        window?.attributes = layoutParams
//        window?.setLayout(WindowManager.LayoutParams.MATCH_PARENT, WindowManager.LayoutParams.WRAP_CONTENT)
        window?.setBackgroundDrawable(ColorDrawable(Color.TRANSPARENT))
    }

    interface onOptionSelected {
        fun onCameraClick()
        fun onGalleryClick()
    }
}