package com.sampsolution.contactlessdining.model.teleSignOtpModel.verifyTeleSign

import com.google.gson.annotations.SerializedName

data class TeleSignVerifyResponse (
    @SerializedName("reference_id"    ) var referenceId    : String?           = null,
    @SerializedName("sub_resource"    ) var subResource    : String?           = null,
    @SerializedName("errors"          ) var errors         : ArrayList<String> = arrayListOf(),
    @SerializedName("status"          ) var status         : Status?           = Status(),
    @SerializedName("verify"          ) var verify         : Verify?           = Verify(),
    @SerializedName("additional_info" ) var additionalInfo : AdditionalInfo?   = AdditionalInfo()

)