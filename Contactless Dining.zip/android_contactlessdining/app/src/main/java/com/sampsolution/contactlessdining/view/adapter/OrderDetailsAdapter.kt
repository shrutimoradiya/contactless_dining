package com.sampsolution.contactlessdining.view.adapter

import android.content.Context
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.bumptech.glide.Glide
import com.sampsolution.contactlessdining.databinding.ItemOrderDetailsBinding
import com.sampsolution.contactlessdining.model.orderDetailModel.Items

data class OrderDetailsAdapter(
    var context: Context,
    val list: ArrayList<Items>,
) :
    RecyclerView.Adapter<OrderDetailsAdapter.TextModelViewHolder>() {

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): TextModelViewHolder {
        return TextModelViewHolder(
            ItemOrderDetailsBinding.inflate(
                LayoutInflater.from(
                    context
                )
            )
        )
    }

    override fun onBindViewHolder(holder: TextModelViewHolder, position: Int) {
        try {
            val data = list[position]

            Glide.with(context).load(data.itemImage).into(holder.binding.img)

            holder.binding.tvName.text = data.itemName
            holder.binding.tvAddress.text = data.itemDescription
            holder.binding.tvQty.text = "x${data.itemQty}"
            holder.binding.tvRs.text = "$${data.originalAmount}"

            if (data.variations != null && data.variations != "") {
                holder.binding.tvVariation.visibility = View.VISIBLE
                holder.binding.tvVariation.text = "Variations: ${data.variations}"
            }
            else{
                holder.binding.tvVariation.visibility = View.GONE
            }


        } catch (e: Exception) {
            e.printStackTrace()
        }
    }

    override fun getItemCount(): Int {
        return list.size
    }

    data class TextModelViewHolder(val binding: ItemOrderDetailsBinding) :
        RecyclerView.ViewHolder(binding.root)


}

