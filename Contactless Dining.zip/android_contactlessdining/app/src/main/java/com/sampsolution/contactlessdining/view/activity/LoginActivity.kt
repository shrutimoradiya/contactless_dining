package com.sampsolution.contactlessdining.view.activity

import android.content.Context
import android.content.Intent
import android.content.res.Configuration
import android.os.Bundle
import android.view.inputmethod.InputMethodManager
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.rilixtech.widget.countrycodepicker.CountryCodePicker
import com.sampsolution.contactlessdining.databinding.ActivityLoginBinding
import com.sampsolution.contactlessdining.utils.LocaleManager


class LoginActivity : AppCompatActivity() {

    private val binding: ActivityLoginBinding by lazy {
        ActivityLoginBinding.inflate(
            layoutInflater
        )
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(binding.root)

        binding.edtPhone.requestFocus()
        val imm = getSystemService(INPUT_METHOD_SERVICE) as InputMethodManager
        imm.showSoftInput(binding.edtPhone, InputMethodManager.SHOW_IMPLICIT)

        binding.ivBack.setOnClickListener { onBackPressed() }

        binding.btnNext.setOnClickListener {
//            if(checkValidity(binding.ccp))
//            {
            if (binding.edtPhone.length() == 10) {
                val intent = Intent(this, VerificationActivity::class.java)
                intent.putExtra("countryCode", binding.ccp.selectedCountryCode)
                intent.putExtra("MobileNo", binding.edtPhone.text.toString())
                startActivity(intent)
            } else {
                Toast.makeText(this, "Please enter a valid phone number", Toast.LENGTH_SHORT).show()
            }
//
//            }else{
//                Toast.makeText(this, "Please enter a valid phone number", Toast.LENGTH_SHORT).show()
//            }
        }

    }


    private fun checkValidity(ccp: CountryCodePicker): Boolean {
        return if (ccp.isValid) {
            Toast.makeText(this, "number " + ccp.fullNumber + " is valid.", Toast.LENGTH_SHORT)
                .show()
            true
        } else {
            false
        }

    }

    private var localeManager: LocaleManager? = null

    override fun attachBaseContext(newBase: Context?) {
        localeManager = LocaleManager(newBase)
        super.attachBaseContext(localeManager!!.setLocale(newBase))
    }

    override fun onConfigurationChanged(newConfig: Configuration) {
        super.onConfigurationChanged(newConfig)
        localeManager!!.setLocale(this)
    }


}