package com.sampsolution.contactlessdining.view.adapter

import android.annotation.SuppressLint
import android.content.Context
import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.RecyclerView
import com.bumptech.glide.Glide
import com.sampsolution.contactlessdining.databinding.ItemScanMenuBinding
import com.sampsolution.contactlessdining.model.menuModel.Menus
import com.sampsolution.contactlessdining.view.dialog.AddMenuItemDialog

data class MenuScanAdapter(
    var context: Context,
    val list: ArrayList<Menus>,
    val listener: AddMenuItemDialog.OnOptionSelected

) :
    RecyclerView.Adapter<MenuScanAdapter.TextModelViewHolder>() {

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): TextModelViewHolder {
        return TextModelViewHolder(
            ItemScanMenuBinding.inflate(
                LayoutInflater.from(
                    context
                )
            )
        )
    }

    override fun onBindViewHolder(
        holder: TextModelViewHolder,
        @SuppressLint("RecyclerView") position: Int
    ) {
        try {
            val data = list[position]

            Glide.with(context).load(data.itemImage).into(holder.binding.img)
            holder.binding.tvName.text = data.itemName
            holder.binding.tvDescription.text = data.itemDescription
            holder.binding.tvPrize.text = "$${data.itemPrice}"

            holder.itemView.setOnClickListener {
                AddMenuItemDialog(
                    context as AppCompatActivity,
                    data, object :
                        AddMenuItemDialog.OnOptionSelected {
                        override fun onItemClick(
                            id: Int?,
                            count: Int,
                            variations_id: Int,
                            options_id: String
                        ) {
                            listener.onItemClick(id, count, variations_id, options_id)
                        }
                    }

                ).show()
            }

        } catch (e: Exception) {
            e.printStackTrace()
        }
    }

    override fun getItemCount(): Int {
        return list.size
    }

    data class TextModelViewHolder(val binding: ItemScanMenuBinding) :
        RecyclerView.ViewHolder(binding.root)


}

