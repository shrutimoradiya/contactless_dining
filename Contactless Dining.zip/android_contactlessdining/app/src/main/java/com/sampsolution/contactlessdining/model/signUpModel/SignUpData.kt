import com.google.gson.annotations.SerializedName

data class SignUpData (

    @SerializedName("user_id"       ) var userId       : Int?    = null,
    @SerializedName("first_name"    ) var firstName    : String? = null,
    @SerializedName("last_name"     ) var lastName     : String? = null,
    @SerializedName("country_code"  ) var countryCode  : String? = null,
    @SerializedName("mobile_number" ) var mobileNumber : String? = null,
    @SerializedName("date_of_birth" ) var dateOfBirth  : String? = null,
    @SerializedName("email"         ) var email        : String? = null

)