package com.sampsolution.contactlessdining.model.menuModel

import com.google.gson.annotations.SerializedName

data class Options(
    @SerializedName("option_id"    ) var optionId    : Int?    = null,
    @SerializedName("option_name"  ) var optionName  : String? = null,
    @SerializedName("option_price" ) var optionPrice : String? = null,
    var    isSelected         : Boolean = false

    )
