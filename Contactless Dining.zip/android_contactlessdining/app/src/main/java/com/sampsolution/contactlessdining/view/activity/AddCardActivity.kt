package com.sampsolution.contactlessdining.view.activity

import android.os.Bundle
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import com.sampsolution.contactlessdining.R
import com.sampsolution.contactlessdining.databinding.ActivityAddCardBinding
import com.sampsolution.contactlessdining.databinding.ActivityHomeBinding

class AddCardActivity : BaseActivity() {

    private val binding: ActivityAddCardBinding by lazy {
        ActivityAddCardBinding.inflate(
            layoutInflater
        )
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(binding.root)

        binding.ivBack.setOnClickListener { onBackPressed() }

    }
}