package com.sampsolution.contactlessdining.service.twilioOtpService

import android.util.ArrayMap
import com.sampsolution.contactlessdining.model.twilioOtpModel.sendOtpModel.SendOtpResponse
import com.sampsolution.contactlessdining.model.twilioOtpModel.verifyOtpModel.VerifyOtpResponse
import retrofit2.Call
import retrofit2.http.*

interface TwillioOtpServiceAPI {

    companion object {
        private const val BASE_URL = "https://verify.twilio.com/"
        const val API_BASE_URL = "${BASE_URL}v2/"
    }


    @POST("Services/VA34792c03da216423c55de0ca3cc26b9c/Verifications")
    @FormUrlEncoded
    fun getSendOtp(
        @Header("Authorization") h1: String,
        @FieldMap params: ArrayMap<String?, Any?>
    ): Call<SendOtpResponse?>?


    @POST("Services/VA34792c03da216423c55de0ca3cc26b9c/VerificationCheck")
    @FormUrlEncoded
    fun getVerifyOtp(
        @Header("Authorization") h1: String,
        @FieldMap params: ArrayMap<String?, Any?>
    ): Call<VerifyOtpResponse?>?


}