package com.sampsolution.contactlessdining.model.menuModel

import com.google.gson.annotations.SerializedName

data class MenuData(
    @SerializedName("restaurant_id" ) var restaurantId : Int?             = null,
    @SerializedName("category_id"   ) var categoryId   : Int?             = null,
    @SerializedName("branch_id"     ) var branchId     : Int?             = null,
    @SerializedName("branch_name"   ) var branchName   : String?          = null,
    @SerializedName("menus"         ) var menus        : ArrayList<Menus> = arrayListOf()
)
