package com.sampsolution.contactlessdining.view.adapter

import android.annotation.SuppressLint
import android.content.Context
import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.sampsolution.contactlessdining.databinding.ItemSizeBinding
import com.sampsolution.contactlessdining.model.menuModel.Options
import com.sampsolution.contactlessdining.model.menuModel.Variations

data class SizeAdapter(
    var context: Context,
    val list: ArrayList<Variations>,
    val listener: OnClickListener,
) :
    RecyclerView.Adapter<SizeAdapter.TextModelViewHolder>() {

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): TextModelViewHolder {
        return TextModelViewHolder(
            ItemSizeBinding.inflate(
                LayoutInflater.from(
                    context
                )
            )
        )
    }

    override fun onBindViewHolder(
        holder: TextModelViewHolder,
        @SuppressLint("RecyclerView") position: Int
    ) {
        try {
            val data = list[position]

            holder.binding.txt.text = data.name

            holder.binding.rvSize.adapter =
                SubSizeAdapter(context, data.selectionType, data.options, object :
                    OnClickListener {
                    override fun onCheckClick(options: Options) {
                        listener.onCheckClick(options)
                    }

                })
            holder.binding.rvSize.isNestedScrollingEnabled = false

        } catch (e: Exception) {
            e.printStackTrace()
        }
    }

    override fun getItemCount(): Int {
        return list.size
    }

    data class TextModelViewHolder(val binding: ItemSizeBinding) :
        RecyclerView.ViewHolder(binding.root)


    interface OnClickListener {
        fun onCheckClick(options: Options)

    }


}

