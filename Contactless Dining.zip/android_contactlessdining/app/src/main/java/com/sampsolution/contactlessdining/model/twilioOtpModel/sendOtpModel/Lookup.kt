package com.sampsolution.contactlessdining.model.twilioOtpModel.sendOtpModel

import com.google.gson.annotations.SerializedName


data class Lookup (

  @SerializedName("carrier" ) var carrier : String? = null

)