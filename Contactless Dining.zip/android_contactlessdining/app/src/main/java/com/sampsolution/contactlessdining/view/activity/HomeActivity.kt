package com.sampsolution.contactlessdining.view.activity

import android.Manifest
import android.app.Activity
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.pm.PackageManager
import android.content.res.Configuration
import android.os.Build
import android.os.Bundle
import android.view.View
import androidx.annotation.RequiresApi
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import androidx.fragment.app.Fragment
import androidx.fragment.app.FragmentTransaction
import com.google.gson.Gson
import com.sampsolution.contactlessdining.R
import com.sampsolution.contactlessdining.app.ConnectivityReceiver
import com.sampsolution.contactlessdining.app.ServiceApp
import com.sampsolution.contactlessdining.databinding.ActivityHomeBinding
import com.sampsolution.contactlessdining.model.HomeInterFace
import com.sampsolution.contactlessdining.model.loginModel.UserData
import com.sampsolution.contactlessdining.utils.Constant
import com.sampsolution.contactlessdining.utils.LocaleManager
import com.sampsolution.contactlessdining.utils.SharedPref
import com.sampsolution.contactlessdining.view.dialog.NotificationDialog
import com.sampsolution.contactlessdining.view.fragment.CartFragment
import com.sampsolution.contactlessdining.view.fragment.HomeFragment
import com.sampsolution.contactlessdining.view.fragment.MyOrdersFragment
import java.security.AccessController.getContext
import java.util.Calendar

class HomeActivity : BaseActivity(), ConnectivityReceiver.ConnectivityReceiverListener,
    HomeInterFace {

    private val binding: ActivityHomeBinding by lazy {
        ActivityHomeBinding.inflate(
            layoutInflater
        )
    }
    private var frag1: Fragment? = null
    private var key: String? = null
    private var payKey: String? = null
    private var sharedPref: SharedPref? = null
    @RequiresApi(Build.VERSION_CODES.TIRAMISU)
    private val permissionStorage = arrayOf(
        Manifest.permission.POST_NOTIFICATIONS
    )
    private val requestExternalStorage = 1
    var dialog: NotificationDialog? = null
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(binding.root)
        key = intent.getStringExtra("key")
        payKey = intent.getStringExtra("payKey")
        sharedPref = SharedPref(this)

        val intentFilter = IntentFilter("android.net.conn.CONNECTIVITY_CHANGE")
        this.registerReceiver(ConnectivityReceiver(), intentFilter)

        if (Constant.intGetData(
                this,
                Constant.ADDCARTCOUNt
            ) == 0
        ) {
            goneTextCount()
        } else {
            visibleTextCount()
        }

        if (!checkWriteExternalPermission()) {
            dialog = NotificationDialog(this, object :
                NotificationDialog.OnOptionSelected {
                override fun onItemClick() {
                    verifyStoragePermissions(this@HomeActivity)
                    dialog?.dismiss()
                }

            })
            dialog!!.show()
        }

        binding.ivScanner.setOnClickListener {
            startActivity(Intent(this, QRScannerActivity::class.java))
        }

        binding.ivMenu.setOnClickListener {
            startActivity(Intent(this, MenuActivity::class.java))
        }

        binding.relHome.setOnClickListener {
            homeSetText()
            setFragment(HomeFragment(listener = this))
            defaultView()
            binding.ivHome.setImageResource(R.drawable.ic_home_fill)
        }

        binding.relCart.setOnClickListener {
            cartSetText()
            setFragment(CartFragment(this, payKey))
            defaultView()
            binding.ivCart.setImageResource(R.drawable.ic_cart_fill)
        }

        binding.relMyOrders.setOnClickListener {
            setFragment(MyOrdersFragment())
            myOrdersSetText()
            defaultView()
            binding.ivMyOrders.setImageResource(R.drawable.ic_my_orders_fill)
        }

        when (key) {
            "cart" -> {
                binding.relCart.performClick()
            }

            "myOrder" -> {
                binding.relMyOrders.performClick()
            }

            else -> {
                binding.relHome.performClick()
            }
        }


    }

    @RequiresApi(Build.VERSION_CODES.TIRAMISU)
    private fun verifyStoragePermissions(activity: Activity?) {
        val permissions =
            ActivityCompat.checkSelfPermission(activity!!, Manifest.permission.POST_NOTIFICATIONS)
        if (permissions != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(activity, permissionStorage, requestExternalStorage)
        }
    }

    private fun checkWriteExternalPermission(): Boolean {
        val permission = Manifest.permission.POST_NOTIFICATIONS
        val res: Int = checkCallingOrSelfPermission(permission)
        return res == PackageManager.PERMISSION_GRANTED
    }

    private fun myOrdersSetText() {
        binding.tvMain.text = getText(R.string.my_orders)
        binding.tvTime.text = getText(R.string.my_orders_status)
    }

    private fun cartSetText() {
        binding.tvMain.text = getText(R.string.my_cart)
        if (Constant.intGetData(
                this,
                Constant.ADDCARTCOUNt
            ) == 0
        ) {
            binding.tvTime.text = "0 ${getString(R.string._0_order_item_s)}"
        } else {
            val count = Constant.intGetData(
                this,
                Constant.ADDCARTCOUNt
            )
            binding.tvTime.text = "$count ${getString(R.string._0_order_item_s)}"
        }
    }

    private fun homeSetText() {
        SharedPref(this).userInfo?.let {
            try {
                Gson().fromJson(it, UserData::class.java)?.let { it1 ->
                    if (it1.firstName!!.length > 5) {
                        val firstLatter =
                            it1.firstName?.substring(0, Math.min(it1.firstName!!.length, 5))

                        binding.tvMain.text = "Hello ${firstLatter}.. \uD83D\uDC4B"
                    } else {
                        binding.tvMain.text = "Hello ${it1.firstName} \uD83D\uDC4B"
                    }
                }
            } catch (_: Exception) {

            }
        }

        val c: Calendar = Calendar.getInstance()

        when (c.get(Calendar.HOUR_OF_DAY)) {
            in 0..11 -> {
                binding.tvTime.text = getString(R.string.good_morning)
            }

            in 12..15 -> {
                binding.tvTime.text = getString(R.string.good_afternoon)
            }

            in 16..20 -> {
                binding.tvTime.text = getString(R.string.good_evening)
            }

            in 21..23 -> {
                binding.tvTime.text = getString(R.string.good_night)
            }
        }

    }

    private fun defaultView() {
        binding.ivHome.setImageResource(R.drawable.ic_home)
        binding.ivCart.setImageResource(R.drawable.ic_cart)
        binding.ivMyOrders.setImageResource(R.drawable.ic_my_orders)
    }

    private fun setFragment(frag: Fragment) {
        this.frag1 = frag
        for (fragment2 in supportFragmentManager.fragments) {
            supportFragmentManager.beginTransaction().remove(fragment2).commit()
        }

        supportFragmentManager.beginTransaction()
            .replace(R.id.container, frag)
            .setTransition(FragmentTransaction.TRANSIT_FRAGMENT_FADE)
            .commitNow()
    }

    private var localeManager: LocaleManager? = null

    override fun attachBaseContext(newBase: Context?) {
        localeManager = LocaleManager(newBase)
        super.attachBaseContext(localeManager!!.setLocale(newBase))
    }

    override fun onConfigurationChanged(newConfig: Configuration) {
        super.onConfigurationChanged(newConfig)
        localeManager!!.setLocale(this)
    }

    override fun visibleTextCount() {
        binding.tvCount.visibility = View.VISIBLE
        binding.tvCount.text =
            Constant.intGetData(
                this,
                Constant.ADDCARTCOUNt
            ).toString()

        if (frag1 is CartFragment) {
            val count = Constant.intGetData(
                this,
                Constant.ADDCARTCOUNt
            )
            binding.tvTime.text = "${count} ${getString(R.string._0_order_item_s)}"
        }
    }

    override fun goneTextCount() {
        binding.tvCount.visibility = View.GONE
        if (frag1 is CartFragment) {
            binding.tvTime.text = "0 ${getString(R.string._0_order_item_s)}"
        }
    }

    override fun onResume() {
        super.onResume()
        ServiceApp.mInstance?.setConnectivityListener(this)
    }

    override fun onPause() {
        super.onPause()
        ServiceApp.mInstance?.setConnectivityListener(this)
    }

    override fun onNetworkConnectionChanged(isConnected: Boolean) {
        if (Constant.getBool(this, Constant.connection) != isConnected) {
            Constant.saveBool(this, Constant.connection, isConnected)
            if (isConnected) {
                when (frag1) {
                    is HomeFragment -> {
                        setFragment(HomeFragment())
                    }

                    is CartFragment -> {
                        setFragment(CartFragment())
                    }

                    is MyOrdersFragment -> {
                        setFragment(MyOrdersFragment())
                    }
                }
//                isOnlineDialog(context)
            } else {
//                isOfflineDialog(context)
            }
        }
    }
}