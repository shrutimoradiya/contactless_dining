package com.sampsolution.contactlessdining.service.otp2factorService

import android.widget.Toast
import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import com.google.gson.GsonBuilder
import com.sampsolution.contactlessdining.R
import com.sampsolution.contactlessdining.app.ServiceApp
import com.sampsolution.contactlessdining.model.otp2factorModel.BaseResponse
import com.sampsolution.contactlessdining.model.otp2factorModel.VerifyResponse
import okhttp3.Interceptor
import okhttp3.OkHttpClient
import okhttp3.logging.HttpLoggingInterceptor
import java.util.concurrent.TimeUnit
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response
import retrofit2.Retrofit
import retrofit2.converter.gson.GsonConverterFactory


class Factor2ServiceRepository {
    private var hotVideoService: Factor2ServiceAPI? = null

    //    private var hotVideoService2: FleetServiceAPI? = null
    private val context = ServiceApp.context

    companion object {
        private var VPNRepository: Factor2ServiceRepository? = null

        @Synchronized
        fun getInstance(): Factor2ServiceRepository? {
            if (VPNRepository == null) {
                VPNRepository = Factor2ServiceRepository()
            }
            return VPNRepository
        }
    }

    init {
        val okHttp = OkHttpClient.Builder()
            .connectTimeout(2, TimeUnit.MINUTES)
//            .writeTimeout(10, TimeUnit.SECONDS)
//            .readTimeout(30, TimeUnit.SECONDS)
            .cache(null)

        okHttp.addInterceptor(Interceptor {
            val newRequest = it.request().newBuilder()
                .build()
            return@Interceptor it.proceed(newRequest)
        })

        val logging = HttpLoggingInterceptor()
        logging.level = HttpLoggingInterceptor.Level.BODY
        okHttp.addInterceptor(logging)

        val okHttpClient = okHttp.build()
        val gson = GsonBuilder()
            .setLenient()
            .create()
//        var basic = Credentials.basic("YOUR_USERNAME", "YOUR_PASSWORD")

        val retrofit = Retrofit.Builder()
            .addConverterFactory(GsonConverterFactory.create(gson))
            .client(okHttpClient)
            .baseUrl(Factor2ServiceAPI.API_BASE_URL)
            .build()

        hotVideoService = retrofit.create(Factor2ServiceAPI::class.java)


//        val retrofit2 = Retrofit.Builder()
//            .baseUrl(FleetServiceAPI.API_BASE_URL)
//            .addConverterFactory(ScalarsConverterFactory.create())
////            .client(okHttpClient)
//            .build()
//
//        hotVideoService2 = retrofit2.create(FleetServiceAPI::class.java)

    }



    fun get2FactorOtpApi(apiKey: String,phoneNo: String,otpTemplateName: String): LiveData<BaseResponse?> {
        val data: MutableLiveData<BaseResponse?> = MutableLiveData()

        hotVideoService?.get2FactorOtp(apiKey,phoneNo,otpTemplateName)
            ?.enqueue(object : Callback<BaseResponse?> {
                override fun onResponse(
                    call: Call<BaseResponse?>,
                    response: Response<BaseResponse?>
                ) {
                    response.body()?.let {
                        data.value = it
                    } ?: run {
                        data.value = null
                        Toast.makeText(
                            context,
                            context?.resources?.getString(R.string.somthing_wrong),
                            Toast.LENGTH_SHORT
                        ).show()
                    }
                }

                override fun onFailure(call: Call<BaseResponse?>, t: Throwable) {
                    t.printStackTrace()
                    data.value = null
                }
            })
        return data
    }

    fun get2FactorVerifyOtpApi(apiKey: String,otp_session_id: String,otp_entered_by_user: String): LiveData<VerifyResponse?> {
        val data: MutableLiveData<VerifyResponse?> = MutableLiveData()

        hotVideoService?.get2FactorVerifyOtp(apiKey,otp_session_id,otp_entered_by_user)
            ?.enqueue(object : Callback<VerifyResponse?> {
                override fun onResponse(
                    call: Call<VerifyResponse?>,
                    response: Response<VerifyResponse?>
                ) {
                    response.body()?.let {
                        data.value = it
                    } ?: run {
                        data.value = null
                        Toast.makeText(
                            context,
                            context?.resources?.getString(R.string.somthing_wrong),
                            Toast.LENGTH_SHORT
                        ).show()
                    }
                }

                override fun onFailure(call: Call<VerifyResponse?>, t: Throwable) {
                    t.printStackTrace()
                    data.value = null
                }
            })
        return data
    }

}