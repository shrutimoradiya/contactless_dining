package com.sampsolution.contactlessdining.model.homeModel

import com.google.gson.annotations.SerializedName

data class HomeData(
    @SerializedName("restaurant_id"        ) var restaurantId       : Int?              = null,
    @SerializedName("restaurant_name"      ) var restaurantName     : String?           = null,
    @SerializedName("branch_id"            ) var branchId           : Int?              = null,
    @SerializedName("branch_name"          ) var branchName         : String?           = null,
    @SerializedName("branch_image"         ) var branchImage        : String?           = null,
    @SerializedName("branch_types"         ) var branchTypes        : ArrayList<String> = arrayListOf(),
    @SerializedName("branch_address"       ) var branchAddress      : String?           = null,
    @SerializedName("branch_short_address" ) var branchShortAddress : String?           = null,
    @SerializedName("branch_latitude"      ) var branchLatitude     : String?           = null,
    @SerializedName("branch_longitude"     ) var branchLongitude    : String?           = null,
    @SerializedName("distance"             ) var distance           : Double?           = null,
    @SerializedName("cash_on_service"      ) var cashOnService      : String?           = null
)
