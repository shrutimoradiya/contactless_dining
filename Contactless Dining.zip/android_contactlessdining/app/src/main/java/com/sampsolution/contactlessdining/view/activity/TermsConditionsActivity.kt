package com.sampsolution.contactlessdining.view.activity

import android.content.Context
import android.content.res.Configuration
import android.os.Bundle
import com.sampsolution.contactlessdining.databinding.ActivityTermsConditionssBinding
import com.sampsolution.contactlessdining.utils.LocaleManager

class TermsConditionsActivity : BaseActivity() {

    private val binding: ActivityTermsConditionssBinding by lazy {
        ActivityTermsConditionssBinding.inflate(
            layoutInflater
        )
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(binding.root)

        binding.ivBack.setOnClickListener { onBackPressed() }
    }

    private var localeManager: LocaleManager? = null

    override fun attachBaseContext(newBase: Context?) {
        localeManager = LocaleManager(newBase)
        super.attachBaseContext(localeManager!!.setLocale(newBase))
    }

    override fun onConfigurationChanged(newConfig: Configuration) {
        super.onConfigurationChanged(newConfig)
        localeManager!!.setLocale(this)
    }

}