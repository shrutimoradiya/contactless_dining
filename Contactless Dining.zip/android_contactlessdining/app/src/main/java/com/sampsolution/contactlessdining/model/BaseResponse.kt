package com.sampsolution.contactlessdining.model

import com.google.gson.annotations.SerializedName

data class BaseResponse(
    @SerializedName("success"      ) var success     : Boolean? = null,
    @SerializedName("message"      ) var message     : String?  = null,
    @SerializedName("total_amount" ) var totalAmount : Int?     = null
)
