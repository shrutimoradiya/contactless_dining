package com.sampsolution.contactlessdining.view.fragment

import android.app.ProgressDialog
import android.content.Intent
import android.os.Bundle
import android.util.ArrayMap
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Toast
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.sampsolution.contactlessdining.databinding.FragmentHomeBinding
import com.sampsolution.contactlessdining.model.HomeInterFace
import com.sampsolution.contactlessdining.model.menuCategoryModel.Categories
import com.sampsolution.contactlessdining.utils.Constant
import com.sampsolution.contactlessdining.view.activity.QRScannerActivity
import com.sampsolution.contactlessdining.view.adapter.MenuNameAdapter
import com.sampsolution.contactlessdining.view.adapter.MenuScanAdapter
import com.sampsolution.contactlessdining.view.dialog.AddMenuItemDialog

open class HomeFragment : BaseFragment, MenuNameAdapter.onClickListener {

    private var binding: FragmentHomeBinding? = null
    private val list: ArrayList<Categories> = arrayListOf()

    private var restaurantId: Int? = null
    private var branchId: Int? = null
    var listener: HomeInterFace? = null

    constructor() : super()

    constructor(listener: HomeInterFace) {
        this.listener = listener
    }


    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        binding = FragmentHomeBinding.inflate(inflater, container, false)
        binding?.btnScan?.setOnClickListener {
            startActivity(Intent(context, QRScannerActivity::class.java))
        }
//        main()

        return binding?.root
    }

    private fun main() {

        val qrCode = context?.let { Constant.getData(it, Constant.QRCODE) }
        if (qrCode == null) {
            binding?.relScan?.visibility = View.VISIBLE
            binding?.relMenu?.visibility = View.GONE

        } else {
            binding?.relMenu?.visibility = View.VISIBLE
            binding?.relScan?.visibility = View.GONE

            menuData(qrCode)
        }
    }


    private fun menuData(id: String) {
        list.clear()
//        val dialog = ProgressDialog(requireContext())
//        dialog.show()

        contactlessService?.menuCategoryApi(id)?.observeForever {
//            dialog.dismiss()
            it?.let { it1 ->
                if (it1.success == true) {
                    binding?.relMenu?.visibility = View.VISIBLE
                    binding?.relScan?.visibility = View.GONE
                    list.add(Categories(categoryName = "All", isSelected = true))
                    it1.data?.let { it2 -> list.addAll(it2.categories) }
                    val layoutManager1: RecyclerView.LayoutManager =
                        LinearLayoutManager(context, LinearLayoutManager.HORIZONTAL, false)
                    binding!!.rvName.adapter =
                        context?.let { it2 -> MenuNameAdapter(it2, list, this) }
                    binding!!.rvName.layoutManager = layoutManager1
                    restaurantId = it1.data?.restaurantId!!
                    branchId = it1.data?.branchId!!
                    binding!!.tvRestaurantName.text =
                        "${it1.data!!.restaurantName}-${it1.data!!.branchName}"

                    for (temp in list) {
                        if (temp.categoryName == "All") {
                            conformation(it1.data?.restaurantId.toString(), "", branchId.toString())
                        }
                    }
                } else {
//                    Toast.makeText(context,it1.message,Toast.LENGTH_SHORT).show()
                    binding?.relScan?.visibility = View.VISIBLE
                    binding?.relMenu?.visibility = View.GONE
                }
            }
        }

    }

    override fun onClick(position: Int, data: Categories) {
        for (temp in list) {
            temp.isSelected = false
        }

        list[position].isSelected = true
        binding?.rvName?.adapter?.notifyDataSetChanged()

        if (data.id == null) {
            conformation(restaurantId.toString(), "", branchId.toString())
        } else {
            conformation(restaurantId.toString(), data.id.toString(), branchId.toString())
        }
    }


    private fun conformation(restaurantId: String, categoryId: String, branchId: String) {

//        val dialog = ProgressDialog(requireContext())
//        dialog.show()

        contactlessService?.menuApi(restaurantId, categoryId, branchId)?.observeForever {
//            dialog.dismiss()
            it?.let { it1 ->
                binding?.shimmerFrameLayout?.stopShimmerAnimation()
                binding?.shimmerFrameLayout?.visibility = View.GONE
                binding?.rvListBar?.visibility = View.VISIBLE

                if (it1.data == null) {
                    binding!!.relNoData.visibility = View.VISIBLE
                    binding!!.scoll.visibility = View.GONE
                } else {
                    binding!!.relNoData.visibility = View.GONE
                    binding!!.scoll.visibility = View.VISIBLE
                    binding!!.rvListBar.adapter =
                        it1.data?.let { it2 ->
                            context?.let { it3 ->
                                MenuScanAdapter(it3, it2.menus, object :
                                    AddMenuItemDialog.OnOptionSelected {
                                    override fun onItemClick(
                                        id: Int?,
                                        count: Int,
                                        variationsId: Int,
                                        optionsId: String,
                                    ) {
                                        addCartApi(
                                            id.toString(), count.toString(),
                                            variationsId.toString(), optionsId
                                        )
                                    }

                                })
                            }
                        }
                    binding!!.rvListBar.isNestedScrollingEnabled = false
                }
            }
        }

    }


    private fun addCartApi(
        ordered_item_id: String,
        item_qty: String,
        variations_id: String,
        options_id: String,
    ) {

        val dialog = ProgressDialog(requireActivity())
        dialog.show()
        val id = context?.let { Constant.getData(it, Constant.USERID) }

        val map: ArrayMap<String?, Any?> = ArrayMap<String?, Any?>()
        map["user_id"] = id
        map["ordered_item_id"] = ordered_item_id
        map["item_qty"] = item_qty
        if (variations_id != "0") {
            map["variations_id"] = variations_id
        }
        if (options_id != "0") {
            map["options_id"] = options_id
        }
        map["table_id"] = 12
        map["restaurant_id"] = restaurantId
        map["branch_id"] = branchId

        context?.let {
            contactlessService?.addCartApi(it, map)?.observeForever {
                dialog.dismiss()
                it?.let { it1 ->
                    if (it1.success == true) {
                        Constant.intSaveData(
                            requireContext(),
                            Constant.ADDCARTCOUNt,
                            (Constant.intGetData(
                                requireContext(),
                                Constant.ADDCARTCOUNt
                            ) + 1)
                        )
                    }

                    if (Constant.intGetData(
                            requireContext(),
                            Constant.ADDCARTCOUNt
                        ) == 0
                    ) {
                        //                    (activity as HomeActivity)?.let {
                        //                        it.goneTextCount()
                        //                    }
                        listener?.goneTextCount()
                    } else {
                        //                    (activity as HomeActivity)?.let {
                        //                        it.visibleTextCount()
                        //                    }
                        listener?.visibleTextCount()
                    }
                    Toast.makeText(requireActivity(), it1.message, Toast.LENGTH_SHORT).show()
                }
            }
        }

    }

    override fun onResume() {
        super.onResume()
        binding?.shimmerFrameLayout?.startShimmerAnimation()
        main()
    }

    override fun onPause() {
        binding?.shimmerFrameLayout?.stopShimmerAnimation()
        super.onPause()
    }

    override fun onStart() {
        super.onStart()
    }


}