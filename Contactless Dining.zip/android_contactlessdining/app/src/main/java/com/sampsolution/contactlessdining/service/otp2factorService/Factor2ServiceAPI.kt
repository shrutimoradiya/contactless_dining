package com.sampsolution.contactlessdining.service.otp2factorService

import com.sampsolution.contactlessdining.model.otp2factorModel.BaseResponse
import com.sampsolution.contactlessdining.model.otp2factorModel.VerifyResponse
import retrofit2.Call
import retrofit2.http.*

interface Factor2ServiceAPI {

    companion object {
        private const val BASE_URL = "https://2factor.in/API/"
        const val API_BASE_URL = "${BASE_URL}V1/"
    }


    @GET("{api_key}/SMS/{phone_number}/AUTOGEN2/{otp_template_name}")
    fun get2FactorOtp(
        @Path("api_key") apiKey: String,
        @Path("phone_number") phoneNumber: String,
        @Path("otp_template_name") otpTemplateName: String
    ): Call<BaseResponse?>?


    @GET("{api_key}/SMS/VERIFY/{otp_session_id}/{otp_entered_by_user}")
    fun get2FactorVerifyOtp(
        @Path("api_key") apiKey: String,
        @Path("otp_session_id") otp_session_id: String,
        @Path("otp_entered_by_user") otp_entered_by_user: String
    ): Call<VerifyResponse?>?


}