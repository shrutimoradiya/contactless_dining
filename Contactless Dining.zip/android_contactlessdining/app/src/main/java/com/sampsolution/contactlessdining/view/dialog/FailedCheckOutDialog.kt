package com.sampsolution.contactlessdining.view.dialog

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.WindowManager
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.WindowInsetsControllerCompat
import com.google.android.material.bottomsheet.BottomSheetBehavior
import com.google.android.material.bottomsheet.BottomSheetDialog
import com.sampsolution.contactlessdining.R
import com.sampsolution.contactlessdining.databinding.DialogFailedCheckOutBinding

data class FailedCheckOutDialog(
    val context: AppCompatActivity,
    val s: String,
    val error: String?,
) : BottomSheetDialog(context) {
    private var dialogbinding: DialogFailedCheckOutBinding? = null
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        dialogbinding = DialogFailedCheckOutBinding.inflate(LayoutInflater.from(context))

        dialogbinding?.let { binding ->
            setContentView(binding.root)

            hideSystemUI()

            if (s == "payment") {
                binding.tv1.text = context.getString(R.string.error)
                binding.tvOrderNumber.text = error
                binding.tv2.text = context.getString(R.string.txt_error2)
                binding.btnDone.text = context.getString(R.string.ok)
            } else {
                binding.tv1.text = context.getString(R.string.failed)
                binding.tvOrderNumber.text =
                    context.getString(R.string.your_order_couldn_t_be_processed)
                binding.tv2.text = context.getString(R.string.please_try_again)
                binding.btnDone.text = context.getString(R.string.back_to_cart)
            }

            binding.btnDone.setOnClickListener {
                dismiss()
            }


        }

        setCanceledOnTouchOutside(true)
        val layoutParams = WindowManager.LayoutParams()
        layoutParams.copyFrom(window?.attributes)
        layoutParams.width = WindowManager.LayoutParams.MATCH_PARENT
        layoutParams.height = WindowManager.LayoutParams.WRAP_CONTENT
        behavior.state = BottomSheetBehavior.STATE_EXPANDED
        window?.attributes = layoutParams
//        window?.setBackgroundDrawable(ColorDrawable(android.graphics.Color.TRANSPARENT))
        (dialogbinding!!.root.parent as View).setBackgroundColor(
            context.resources.getColor(android.R.color.transparent)
        )
    }

//


    private fun hideSystemUI() {
        window?.let { WindowCompat.setDecorFitsSystemWindows(it, false) }
        window?.let {
            WindowInsetsControllerCompat(
                it,
                window!!.decorView.findViewById(android.R.id.content)
            ).let { controller ->
                controller.hide(WindowInsetsCompat.Type.systemBars())

                controller.systemBarsBehavior =
                    WindowInsetsControllerCompat.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
            }
        }
    }
}

