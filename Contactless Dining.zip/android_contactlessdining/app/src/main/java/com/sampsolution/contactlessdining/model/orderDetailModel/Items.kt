package com.sampsolution.contactlessdining.model.orderDetailModel

import com.google.gson.annotations.SerializedName

data class Items(
    @SerializedName("item_id"          ) var itemId          : Int?    = null,
    @SerializedName("item_name"        ) var itemName        : String? = null,
    @SerializedName("item_description" ) var itemDescription : String? = null,
    @SerializedName("item_type"        ) var itemType        : String? = null,
    @SerializedName("item_image"       ) var itemImage       : String? = null,
    @SerializedName("variations"       ) var variations      : String? = null,
    @SerializedName("options_price"    ) var optionsPrice    : String? = null,
    @SerializedName("item_qty"         ) var itemQty         : Int?    = null,
    @SerializedName("original_amount"  ) var originalAmount  : String? = null,
    @SerializedName("item_price"       ) var itemPrice       : String? = null,
)
