package com.sampsolution.contactlessdining.view.adapter

import android.content.Context
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.sampsolution.contactlessdining.R
import com.sampsolution.contactlessdining.databinding.ItemSubSizeBinding
import com.sampsolution.contactlessdining.model.menuModel.Options

data class SubSizeAdapter(
    var context: Context,
    val selectionType: String?,
    val list: ArrayList<Options>,
    val listener: SizeAdapter.OnClickListener,
) :
    RecyclerView.Adapter<SubSizeAdapter.TextModelViewHolder>() {

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): TextModelViewHolder {
        return TextModelViewHolder(
            ItemSubSizeBinding.inflate(
                LayoutInflater.from(
                    context
                )
            )
        )
    }

    override fun onBindViewHolder(holder: TextModelViewHolder, position: Int) {
        try {
            val data = list[position]

            holder.binding.tvSmall.text = data.optionName

            holder.binding.tvSmallPrize.text = "$${data.optionPrice}"

            if (data.isSelected) {
                holder.binding.ivSmallCheck.visibility = View.VISIBLE
                holder.binding.tvSmall.setTextColor(context.getColor(R.color.white))
                holder.binding.tvSmallPrize.setTextColor(context.getColor(R.color.white))
            } else {
                holder.binding.ivSmallCheck.visibility = View.GONE
                holder.binding.tvSmall.setTextColor(context.getColor(R.color.gray_txt))
                holder.binding.tvSmallPrize.setTextColor(context.getColor(R.color.gray_txt))
            }

            holder.binding.relMain1.setOnClickListener {
                if (selectionType == "single") {
                    for (temp in list) {
                        if (data.optionId == temp.optionId) {
                            data.isSelected = !data.isSelected
                        } else {
                            temp.isSelected = false
                        }
                    }
                } else {
                    data.isSelected = !data.isSelected
                }

                notifyDataSetChanged()
                listener.onCheckClick(data)
            }

        } catch (e: Exception) {
            e.printStackTrace()
        }
    }

    override fun getItemCount(): Int {
        return list.size
    }

    data class TextModelViewHolder(val binding: ItemSubSizeBinding) :
        RecyclerView.ViewHolder(binding.root)

}

