package com.sampsolution.contactlessdining.model.menuModel

import com.google.gson.annotations.SerializedName

data class Variations(
    @SerializedName("variation_id"   ) var variationId   : Int?               = null,
    @SerializedName("name"           ) var name          : String?            = null,
    @SerializedName("selection_type" ) var selectionType : String?            = null,
    @SerializedName("min"            ) var min           : Int?               = null,
    @SerializedName("max"            ) var max           : Int?               = null,
    @SerializedName("options"        ) var options       : ArrayList<Options> = arrayListOf()

)
