package com.sampsolution.contactlessdining.view.activity

import android.app.ProgressDialog
import android.content.Context
import android.content.Intent
import android.content.res.Configuration
import android.os.Bundle
import android.util.ArrayMap
import android.view.View
import android.widget.Toast
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.sampsolution.contactlessdining.databinding.ActivityScanMenuBinding
import com.sampsolution.contactlessdining.model.menuCategoryModel.Categories
import com.sampsolution.contactlessdining.utils.Constant
import com.sampsolution.contactlessdining.utils.LocaleManager
import com.sampsolution.contactlessdining.view.adapter.MenuNameAdapter
import com.sampsolution.contactlessdining.view.adapter.MenuScanAdapter
import com.sampsolution.contactlessdining.view.dialog.AddMenuItemDialog

class ScanMenuActivity : BaseActivity(), MenuNameAdapter.onClickListener {

    private val binding: ActivityScanMenuBinding by lazy {
        ActivityScanMenuBinding.inflate(
            layoutInflater
        )
    }

    private val list: ArrayList<Categories> = arrayListOf()
    private var restaurantId = 0
    private var branchId = 0
    private var qrCode = ""


    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(binding.root)

        qrCode = intent.getStringExtra("QRCODE").toString()

        binding.ivBack.setOnClickListener { onBackPressed() }

        binding.relEnd.setOnClickListener {
            val intent = Intent(this, HomeActivity::class.java)
            intent.putExtra("key", "cart")
            startActivity(intent)
            finish()
        }

        if (Constant.intGetData(
                this@ScanMenuActivity,
                Constant.ADDCARTCOUNt
            ) == 0
        ) {
            binding.tvCount.visibility = View.GONE
        } else {
            binding.tvCount.visibility = View.VISIBLE
            binding.tvCount.text =
                Constant.intGetData(
                    this@ScanMenuActivity,
                    Constant.ADDCARTCOUNt
                ).toString()
        }


        menuData(qrCode)

    }


    private fun menuData(id: String) {
        list.clear()
        val dialog = ProgressDialog(this)
        dialog.show()

        contactlessService?.menuCategoryApi(id)?.observeForever {
            dialog.dismiss()
            it?.let { it1 ->
                list.add(Categories(categoryName = "All", isSelected = true))
                it1.data?.let { it2 -> list.addAll(it2.categories) }
                val layoutManager1: RecyclerView.LayoutManager =
                    LinearLayoutManager(this, LinearLayoutManager.HORIZONTAL, false)
                binding.rvName.adapter = MenuNameAdapter(this, list, this)
                binding.rvName.layoutManager = layoutManager1
                restaurantId = it1.data?.restaurantId!!
                branchId = it1.data?.branchId!!
                binding.tvRestaurantName.text = it1.data!!.restaurantName

                for (temp in list) {
                    if (temp.categoryName == "All") {
                        conformation(it1.data?.restaurantId.toString(), "", branchId.toString())
                    }
                }
            }
        }

    }


    override fun onClick(position: Int, data: Categories) {
        for (temp in list) {
            temp.isSelected = false
        }

        list[position].isSelected = true
        binding?.rvName?.adapter?.notifyDataSetChanged()

        if (data.id == null) {
            conformation(restaurantId.toString(), "", branchId.toString())
        } else {
            conformation(restaurantId.toString(), data.id.toString(), branchId.toString())
        }
    }


    private fun conformation(restaurantId: String, categoryId: String, branchId: String) {

//        val dialog = ProgressDialog(requireContext())
//        dialog.show()

        contactlessService?.menuApi(restaurantId, categoryId, branchId)?.observeForever {
//            dialog.dismiss()
            it?.let { it1 ->
                if (it1.data == null) {
                    binding.relNoData.visibility = View.VISIBLE
                    binding.scoll.visibility = View.GONE
                } else {
                    binding.relNoData.visibility = View.GONE
                    binding.scoll.visibility = View.VISIBLE
                    binding.rvListBar.adapter =
                        it1.data?.let { it2 ->
                            MenuScanAdapter(this, it2.menus, object :
                                AddMenuItemDialog.OnOptionSelected {
                                override fun onItemClick(
                                    id: Int?,
                                    count: Int,
                                    variationsId: Int,
                                    optionsId: String,
                                ) {
                                    addCartApi(
                                        id.toString(), count.toString(),
                                        variationsId.toString(), optionsId
                                    )
                                }

                            })
                        }
                    binding.rvListBar.isNestedScrollingEnabled = false
                }
            }
        }

    }


    private fun addCartApi(
        ordered_item_id: String,
        item_qty: String,
        variations_id: String,
        options_id: String,
    ) {

        val dialog = ProgressDialog(this)
        dialog.show()
        val id = Constant.getData(this, Constant.USERID)

        val map: ArrayMap<String?, Any?> = ArrayMap<String?, Any?>()
        map["user_id"] = id
        map["ordered_item_id"] = ordered_item_id
        map["item_qty"] = item_qty
        if (variations_id != "0") {
            map["variations_id"] = variations_id
        }
        if (options_id != "0") {
            map["options_id"] = options_id
        }
        map["table_id"] = 12
        map["restaurant_id"] = restaurantId
        map["branch_id"] = branchId

        contactlessService?.addCartApi(this, map)?.observeForever {
            dialog.dismiss()
            it?.let { it1 ->
                if (it1.success == true) {
                    Constant.intSaveData(
                        this@ScanMenuActivity,
                        Constant.ADDCARTCOUNt,
                        (Constant.intGetData(
                            this@ScanMenuActivity,
                            Constant.ADDCARTCOUNt
                        ) + 1)
                    )
                }

                if (Constant.intGetData(
                        this@ScanMenuActivity,
                        Constant.ADDCARTCOUNt
                    ) == 0
                ) {
                    binding.tvCount.visibility = View.GONE
                } else {
                    binding.tvCount.visibility = View.VISIBLE
                    binding.tvCount.text =
                        Constant.intGetData(
                            this@ScanMenuActivity,
                            Constant.ADDCARTCOUNt
                        ).toString()
                }
                Toast.makeText(this, it1.message, Toast.LENGTH_SHORT).show()
            }
        }

    }

    private var localeManager: LocaleManager? = null

    override fun attachBaseContext(newBase: Context?) {
        localeManager = LocaleManager(newBase)
        super.attachBaseContext(localeManager!!.setLocale(newBase))
    }

    override fun onConfigurationChanged(newConfig: Configuration) {
        super.onConfigurationChanged(newConfig)
        localeManager!!.setLocale(this)
    }


}