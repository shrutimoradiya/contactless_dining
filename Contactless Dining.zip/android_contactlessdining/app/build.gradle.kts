plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
    id("com.google.gms.google-services")
}

android {
    namespace = "com.sampsolution.contactlessdining"
    compileSdk = 34

    defaultConfig {
        applicationId = "com.sampsolution.contactlessdining"
        minSdk = 24
        targetSdk = 34
        versionCode = 1
        versionName = "1.0"

        testInstrumentationRunner = "androidx.test.runner.AndroidJUnitRunner"
    }

    buildTypes {
        release {
            isMinifyEnabled = false
            proguardFiles(
                getDefaultProguardFile("proguard-android-optimize.txt"),
                "proguard-rules.pro"
            )
        }
    }
    buildFeatures {
        dataBinding = true
        viewBinding = true
        buildConfig = true
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_1_8
        targetCompatibility = JavaVersion.VERSION_1_8

        kotlinOptions {
            // Used for the sample app (Kotlin Serialization Library) not required for Checkouts SDK.
            freeCompilerArgs += "-Xopt-in=org.mylibrary.OptInAnnotation"
        }

    }
    kotlinOptions {
        jvmTarget = "1.8"
    }
}

dependencies {

    implementation("androidx.core:core-ktx:1.12.0")
    implementation("androidx.appcompat:appcompat:1.6.1")
    implementation("com.google.android.material:material:1.11.0")
    implementation("androidx.constraintlayout:constraintlayout:2.1.4")
    implementation("androidx.activity:activity:1.8.0")
    testImplementation("junit:junit:4.13.2")
    androidTestImplementation("androidx.test.ext:junit:1.1.5")
    androidTestImplementation("androidx.test.espresso:espresso-core:3.5.1")

    implementation("com.intuit.sdp:sdp-android:1.1.0")

    //countryCodePicker
    implementation("com.github.joielechong:countrycodepicker:2.4.2")

    //roundImage
    implementation("com.makeramen:roundedimageview:2.3.0")

    //QrScanner
    implementation("com.github.yuriy-budiyev:code-scanner:2.3.2")

//    // ShimmerView
    implementation("com.facebook.shimmer:shimmer:0.1.0@aar")

    // api
    implementation("com.squareup.retrofit2:retrofit:2.9.0")
    implementation("com.google.code.gson:gson:2.9.0")
    implementation("com.squareup.retrofit2:converter-gson:2.9.0")
    implementation("com.squareup.okhttp3:logging-interceptor:3.14.9")
    implementation("com.squareup.retrofit2:converter-scalars:2.9.0")

    //firebase
    implementation(platform("com.google.firebase:firebase-bom:32.7.2"))
    implementation("com.google.firebase:firebase-analytics")
    implementation("com.google.firebase:firebase-auth")

    //firebase push notification
    implementation ("com.google.firebase:firebase-messaging")


    implementation("com.github.bumptech.glide:glide:4.16.0")

    // location
    implementation("com.google.android.gms:play-services-maps:18.1.0")
    implementation("com.google.android.gms:play-services-location:20.0.0")
    implementation("com.google.android.gms:play-services-places:17.0.0")
    implementation("com.google.maps.android:android-maps-utils:0.5")

    //PayTabs sdk
    implementation ("com.paytabs:payment-sdk:6.5.6")

    //For Razorpay checkout SDK
    implementation ("com.razorpay:checkout:1.6.20")

    // PayPal Checkout SDK Libraries
    implementation ("com.paypal.checkout:android-sdk:1.2.1")

}