pluginManagement {
    repositories {
        google()
        mavenCentral()
        gradlePluginPortal()
        jcenter()
        maven { url = uri("https://jitpack.io") }
        maven {
            name = "GitHubPackages"
            /*  Configure path to the library hosted on GitHub Packages Registry
             *  Replace UserID with package owner userID and REPOSITORY with the repository name
             *  e.g. "https://maven.pkg.github.com/enefce/AndroidLibraryForGitHubPackagesDemo"*/

            url = uri("https://maven.pkg.github.com/vivekshindhe/TestingAndroidStandard")
            credentials {
                /** Create github.properties in root project folder file with
                 ** gpr.usr=GITHUB_USER_ID & gpr.key=PERSONAL_ACCESS_TOKEN
                 ** Or set env variable GPR_USER & GPR_API_KEY if not adding a properties file**/

                username = System.getenv("GPR_USER")?:""
                password = System.getenv("GPR_API_KEY")?:""
            }
        }
        maven {
            url =uri("https://oss.sonatype.org/content/repositories/snapshots/")
        }
        maven {
            url =uri("https://cardinalcommerceprod.jfrog.io/artifactory/android")
            credentials {
                // Be sure to add these non-sensitive credentials in order to retrieve dependencies from
                // the private repository.
                username ="paypal_sgerritz"
                password ="AKCp8jQ8tAahqpT5JjZ4FRP2mW7GMoFZ674kGqHmupTesKeAY2G8NcmPKLuTxTGkKjDLRzDUQ"
            }
        }
        mavenLocal()

    }
}
dependencyResolutionManagement {
    repositoriesMode.set(RepositoriesMode.FAIL_ON_PROJECT_REPOS)
    repositories {
        google()
        mavenCentral()
        jcenter()
        maven { url = uri("https://jitpack.io") }
        maven {
            name = "GitHubPackages"
            /*  Configure path to the library hosted on GitHub Packages Registry
             *  Replace UserID with package owner userID and REPOSITORY with the repository name
             *  e.g. "https://maven.pkg.github.com/enefce/AndroidLibraryForGitHubPackagesDemo"*/

            url = uri("https://maven.pkg.github.com/vivekshindhe/TestingAndroidStandard")
            credentials {
                /** Create github.properties in root project folder file with
                 ** gpr.usr=GITHUB_USER_ID & gpr.key=PERSONAL_ACCESS_TOKEN
                 ** Or set env variable GPR_USER & GPR_API_KEY if not adding a properties file**/

                username = System.getenv("GPR_USER")?:""
                password = System.getenv("GPR_API_KEY")?:""
            }
        }

        //paypal
        maven {
            url =uri("https://oss.sonatype.org/content/repositories/snapshots/")
        }
        maven {
            url =uri("https://cardinalcommerceprod.jfrog.io/artifactory/android")
            credentials {
                // Be sure to add these non-sensitive credentials in order to retrieve dependencies from
                // paypal.
                username ="paypal_sgerritz"
                password ="AKCp8jQ8tAahqpT5JjZ4FRP2mW7GMoFZ674kGqHmupTesKeAY2G8NcmPKLuTxTGkKjDLRzDUQ"
            }
        }
        mavenLocal()

    }

}

rootProject.name = "Contactless Dining"
include(":app")
